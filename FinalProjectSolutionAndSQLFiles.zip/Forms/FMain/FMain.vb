﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Class: IT-102-001 - VB.Net 2 
' Abstract: Capstone Horse project - Display, Add, Edit, and Delete 
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FMain


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FMain_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FMain_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Connect to the database.  End if connection fails.
            If OpenDatabaseConnectionSQLServer() = False Then Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

            ' End program
            Application.Exit()

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FMain_FormClosing
    ' Abstract: Close the connection to the database
    ' --------------------------------------------------------------------------------
    Private Sub FMain_Closing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        ' Try/Catch with WriteLog
        Try

            modDatabaseUtilities.CloseDatabaseConnection()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageHorses_Click
    ' Abstract: Show Manage the Horses form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageHorses_Click(sender As Object, e As EventArgs) Handles btnManageHorses.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHorses forms
            Dim frmAddHorses As FManageHorses

            ' Make am instance
            frmAddHorses = New FManageHorses

            ' Show modally
            frmAddHorses.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAddBuyers_Click
    ' Abstract: Show Add the Buyers form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageBuyers_Click(sender As Object, e As EventArgs) Handles btnManageBuyers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHorseBuyers forms
            Dim frmAddHorseBuyers As FManageHorseBuyers

            ' Make am instance
            frmAddHorseBuyers = New FManageHorseBuyers

            ' Show modally
            frmAddHorseBuyers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageSellers_Click
    ' Abstract: Show Manage the Sellers form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageSellers_Click(sender As Object, e As EventArgs) Handles btnManageSellers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHorseSellers forms
            Dim frmAddHorseSellers As FManageHorseSellers

            ' Make am instance
            frmAddHorseSellers = New FManageHorseSellers

            ' Show modally
            frmAddHorseSellers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageShoes_Click
    ' Abstract: Show Manage the Shoes form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageShoes_Click(sender As Object, e As EventArgs) Handles btnManageShoes.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageShoes forms
            Dim frmAddShoe As FManageShoes

            ' Make am instance
            frmAddShoe = New FManageShoes

            ' Show modally
            frmAddShoe.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignHorseShoes_Click
    ' Abstract: Show Assign the Horse Shoes form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignHorseShoes_Click(sender As Object, e As EventArgs) Handles btnAssignHorseShoes.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseShoes forms
            Dim frmAddHorseShoes As FAssignHorseShoes

            ' Make am instance
            frmAddHorseShoes = New FAssignHorseShoes

            ' Show modally
            frmAddHorseShoes.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageVaccinations_Click
    ' Abstract: Show Manage the Manage Vaccinations form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageVaccinations_Click(sender As Object, e As EventArgs) Handles btnManageVaccinations.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageVaccinations forms
            Dim frmAddVaccinations As FManageVaccinations

            ' Make am instance
            frmAddVaccinations = New FManageVaccinations

            ' Show modally
            frmAddVaccinations.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignHorseVaccinations_Click
    ' Abstract: Show Assign the Horse Vaccinations form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignHorseVaccinations_Click(sender As Object, e As EventArgs) Handles btnAssignHorseVaccinations.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseVaccinations forms
            Dim frmAddHorseVaccinations As FAssignHorseVaccinations

            ' Make am instance
            frmAddHorseVaccinations = New FAssignHorseVaccinations

            ' Show modally
            frmAddHorseVaccinations.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageWestNileTests_Click
    ' Abstract: Show Manage the WestNileTests form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageWestNileTests_Click(sender As Object, e As EventArgs) Handles btnManageWestNileTests.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageWestNileTests forms
            Dim frmAddWestNileTests As FManageWestNileTests

            ' Make am instance
            frmAddWestNileTests = New FManageWestNileTests

            ' Show modally
            frmAddWestNileTests.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignWestNileTests_Click
    ' Abstract: Show the Assign WestNile Tests form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignHorseWestNileTests_Click(sender As Object, e As EventArgs) Handles btnAssignHorseWestNileTests.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseWestNileTests forms
            Dim frmAddHorseWestNileTests As FAssignHorseWestNileTests

            ' Make am instance
            frmAddHorseWestNileTests = New FAssignHorseWestNileTests

            ' Show modally
            frmAddHorseWestNileTests.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageDewormers_Click
    ' Abstract: Show Manage the Dewormers form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageDewormers_Click(sender As Object, e As EventArgs) Handles btnManageDewormers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageDewormers forms
            Dim frmAddDewormers As FManageDewormers

            ' Make am instance
            frmAddDewormers = New FManageDewormers

            ' Show modally
            frmAddDewormers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignHorseDewormers_Click
    ' Abstract: Show the Assign Horse Dewormers form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignHorseDewormers_Click(sender As Object, e As EventArgs) Handles btnAssignHorseDewormers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseDewormers forms
            Dim frmAddHorseDewormers As FAssignHorseDewormers

            ' Make am instance
            frmAddHorseDewormers = New FAssignHorseDewormers

            ' Show modally
            frmAddHorseDewormers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageHealthCertificates_Click
    ' Abstract: Show Manage the Health Certificates form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageHealthCertificates_Click(sender As Object, e As EventArgs) Handles btnManageHealthCertificates.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHealthCertificates forms
            Dim frmAddHealthCertificates As FManageHealthCertificates

            ' Make am instance
            frmAddHealthCertificates = New FManageHealthCertificates

            ' Show modally
            frmAddHealthCertificates.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignHorseHealthCertificates_Click
    ' Abstract: Show the Assign Horse Health Certificates form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignHorseHealthCertificates_Click(sender As Object, e As EventArgs) Handles btnAssignHorseHealthCertificates.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseHealthCertificates forms
            Dim frmAddHorseHealthCertificates As FAssignHorseHealthCertificates

            ' Make am instance
            frmAddHorseHealthCertificates = New FAssignHorseHealthCertificates

            ' Show modally
            frmAddHorseHealthCertificates.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageFeedMiscExpenses_Click
    ' Abstract: Show Manage the FeedMiscExpenses form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageFeedMiscExpenses_Click(sender As Object, e As EventArgs) Handles btnManageFeedMiscExpenses.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageFeedMiscExpenses forms
            Dim frmAddFeedMiscExpenses As FManageFeedMiscExpenses

            ' Make am instance
            frmAddFeedMiscExpenses = New FManageFeedMiscExpenses

            ' Show modally
            frmAddFeedMiscExpenses.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageEquipment_Click
    ' Abstract: Show Manage the Equipment form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageEquipment_Click(sender As Object, e As EventArgs) Handles btnManageEquipment.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageEquipment forms
            Dim frmAddEquipment As FManageEquipment

            ' Make am instance
            frmAddEquipment = New FManageEquipment

            ' Show modally
            frmAddEquipment.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnManageMaintenance_Click
    ' Abstract: Show Manage the Maintenance form
    ' --------------------------------------------------------------------------------
    Private Sub btnManageMaintenance_Click(sender As Object, e As EventArgs) Handles btnManageMaintenance.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageMaintenance forms
            Dim frmAddMaintenance As FManageMaintenance

            ' Make am instance
            frmAddMaintenance = New FManageMaintenance

            ' Show modally
            frmAddMaintenance.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignEquipmentMaintenance_Click
    ' Abstract: Show the Assign Equipment Maintenance form
    ' --------------------------------------------------------------------------------
    Private Sub btnAssignEquipmentMaintenance_Click(sender As Object, e As EventArgs) Handles btnAssignEquipmentMaintenance.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignEquipmentMaintenance forms
            Dim frmAddEquipmentMaintenance As FAssignEquipmentMaintenance

            ' Make am instance
            frmAddEquipmentMaintenance = New FAssignEquipmentMaintenance

            ' Show modally
            frmAddEquipmentMaintenance.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnCloseTheApplication_Click
    ' Abstract: Close the form - Exit the Application
    ' --------------------------------------------------------------------------------
    Private Sub btnCloseTheApplication_Click(sender As Object, e As EventArgs) Handles btnCloseTheApplication.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

            ' Closes ALL forms
            Application.Exit()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageHorses_Click
    ' Abstract: Show the Manage Horses form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageHorses_Click(sender As Object, e As EventArgs) Handles mnuManageHorses.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHorses forms
            Dim frmAddHorses As FManageHorses

            ' Make am instance
            frmAddHorses = New FManageHorses

            ' Show modally
            frmAddHorses.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageBuyers_Click
    ' Abstract: Show the Manage Buyers form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageBuyers_Click(sender As Object, e As EventArgs) Handles mnuManageBuyers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for ManageHorseBuyers forms
            Dim frmAddHorseBuyers As FManageHorseBuyers

            ' Make am instance
            frmAddHorseBuyers = New FManageHorseBuyers

            ' Show modally
            frmAddHorseBuyers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageSellers_Click
    ' Abstract: Show the Manage Sellers form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageSellers_Click(sender As Object, e As EventArgs) Handles mnuManageSellers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHorseSellers forms
            Dim frmAddHorseSellers As FManageHorseSellers

            ' Make am instance
            frmAddHorseSellers = New FManageHorseSellers

            ' Show modally
            frmAddHorseSellers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageShoes_Click
    ' Abstract: Show the Manage Shoes form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageShoes_Click(sender As Object, e As EventArgs) Handles mnuManageShoes.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageShoes forms
            Dim frmAddShoe As FManageShoes

            ' Make am instance
            frmAddShoe = New FManageShoes

            ' Show modally
            frmAddShoe.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignHorseShoes_Click
    ' Abstract: Show the Assign Horse Shoes form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignHorseShoes_Click(sender As Object, e As EventArgs) Handles mnuAssignHorseShoes.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseShoes forms
            Dim frmAddHorseShoes As FAssignHorseShoes

            ' Make am instance
            frmAddHorseShoes = New FAssignHorseShoes

            ' Show modally
            frmAddHorseShoes.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageVaccinations_Click
    ' Abstract: Show the Manage Vaccinations form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageVaccinations_Click(sender As Object, e As EventArgs) Handles mnuManageVaccinations.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageVaccinations forms
            Dim frmAddVaccinations As FManageVaccinations

            ' Make am instance
            frmAddVaccinations = New FManageVaccinations

            ' Show modally
            frmAddVaccinations.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignHorseVaccinations_Click
    ' Abstract: Show the Assign Horse Vaccinations form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignHorseVaccinations_Click(sender As Object, e As EventArgs) Handles mnuAssignHorseVaccinations.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseVaccinations forms
            Dim frmAddHorseVaccinations As FAssignHorseVaccinations

            ' Make am instance
            frmAddHorseVaccinations = New FAssignHorseVaccinations

            ' Show modally
            frmAddHorseVaccinations.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageWestNileTests_Click
    ' Abstract: Show the Manage WestNile Tests form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageWestNileTests_Click(sender As Object, e As EventArgs) Handles mnuManageWestNileTests.Click
        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageWestNileTests forms
            Dim frmAddWestNileTests As FManageWestNileTests

            ' Make am instance
            frmAddWestNileTests = New FManageWestNileTests

            ' Show modally
            frmAddWestNileTests.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try
    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignWestNileTests_Click
    ' Abstract: Show the Assign WestNile Tests form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignWestNileTests_Click(sender As Object, e As EventArgs) Handles mnuAssignWestNileTests.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseWestNileTests forms
            Dim frmAddWestNileTests As FAssignHorseWestNileTests

            ' Make am instance
            frmAddWestNileTests = New FAssignHorseWestNileTests

            ' Show modally
            frmAddWestNileTests.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageDewormers_Click
    ' Abstract: Show the Manage Dewormers form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageDewormers_Click(sender As Object, e As EventArgs) Handles mnuManageDewormers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageDewormers forms
            Dim frmAddDewormers As FManageDewormers

            ' Make am instance
            frmAddDewormers = New FManageDewormers

            ' Show modally
            frmAddDewormers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignHorseDewormers_Click
    ' Abstract: Show the Assign Horse Dewormers form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignHorseDewormers_Click(sender As Object, e As EventArgs) Handles mnuAssignHorseDewormers.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseDewormers forms
            Dim frmAddHorseDewormers As FAssignHorseDewormers

            ' Make am instance
            frmAddHorseDewormers = New FAssignHorseDewormers

            ' Show modally
            frmAddHorseDewormers.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageHealthCertificates_Click
    ' Abstract: Show the Manage Health Certificates form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageHealthCertificates_Click(sender As Object, e As EventArgs) Handles mnuManageHealthCertificates.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageHealthCertificates forms
            Dim frmAddHealthCertificates As FManageHealthCertificates

            ' Make am instance
            frmAddHealthCertificates = New FManageHealthCertificates

            ' Show modally
            frmAddHealthCertificates.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignHorseHealthCertificates_Click
    ' Abstract: Show the Assign Horse Health Certificates form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignHorseHealthCertificates_Click(sender As Object, e As EventArgs) Handles mnuAssignHorseHealthCertificates.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAssignHorseHealthCertificates forms
            Dim frmAddHorseHealthCertificates As FAssignHorseHealthCertificates

            ' Make am instance
            frmAddHorseHealthCertificates = New FAssignHorseHealthCertificates

            ' Show modally
            frmAddHorseHealthCertificates.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageFeedMiscExpenses_Click
    ' Abstract: Show the Manage FeedMiscExpenses form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageFeedMiscExpenses_Click(sender As Object, e As EventArgs) Handles mnuManageFeedMiscExpenses.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageFeedMiscExpenses forms
            Dim frmAddFeedMiscExpenses As FManageFeedMiscExpenses

            ' Make am instance
            frmAddFeedMiscExpenses = New FManageFeedMiscExpenses

            ' Show modally
            frmAddFeedMiscExpenses.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageEquipment_Click
    ' Abstract: Show the Manage Equipment form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageEquipment_Click(sender As Object, e As EventArgs) Handles mnuManageEquipment.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageEquipment forms
            Dim frmAddEquipment As FManageEquipment

            ' Make am instance
            frmAddEquipment = New FManageEquipment

            ' Show modally
            frmAddEquipment.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuManageMaintenance_Click
    ' Abstract: Show the Manage Maintenance form
    ' --------------------------------------------------------------------------------
    Private Sub mnuManageMaintenance_Click(sender As Object, e As EventArgs) Handles mnuManageMaintenance.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FManageMaintenance forms
            Dim frmAddMaintenance As FManageMaintenance

            ' Make am instance
            frmAddMaintenance = New FManageMaintenance

            ' Show modally
            frmAddMaintenance.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAssignEquipmentMaintenance_Click
    ' Abstract: Show the Assign Equipment Maintenance form
    ' --------------------------------------------------------------------------------
    Private Sub mnuAssignEquipmentMaintenance_Click(sender As Object, e As EventArgs) Handles mnuAssignEquipmentMaintenance.Click

        ' Try/Catch with WriteLog
        Try

            ' Buy a plot of land zoned for FAddEquipmentMaintenance forms
            Dim frmAddEquipmentMaintenance As FAssignEquipmentMaintenance

            ' Make am instance
            frmAddEquipmentMaintenance = New FAssignEquipmentMaintenance

            ' Show modally
            frmAddEquipmentMaintenance.ShowDialog()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAssignEquipmentMaintenance_Click
    ' Abstract: Close the form - Exit the Application
    ' --------------------------------------------------------------------------------
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

            ' Closes ALL forms
            Application.Exit()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: mnuAbout_Click
    ' Abstract: Show the About message
    ' --------------------------------------------------------------------------------
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click

        ' Try/Catch with WriteLog
        Try

            Dim strMessage As String

            strMessage = "Hello Bob"

            MessageBox.Show(strMessage)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub

End Class
