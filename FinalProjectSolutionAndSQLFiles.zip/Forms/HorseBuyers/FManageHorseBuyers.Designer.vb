﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageHorseBuyers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblAddEditDelete = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lblHorseBuyers = New System.Windows.Forms.Label()
        Me.lstHorseBuyers = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvHorseBuyers = New System.Windows.Forms.DataGridView()
        Me.IntHorseBuyerIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrFullNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrAddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrStateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrZipCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecPurchasePriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteDatePurchasedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrHorseBuyerStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VHorseBuyersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLHorseBuyersDS = New CapstoneHorseApplication.CPDM_FoxLHorseBuyersDS()
        Me.VHorseBuyersTableAdapter = New CapstoneHorseApplication.CPDM_FoxLHorseBuyersDSTableAdapters.VHorseBuyersTableAdapter()
        CType(Me.dgvHorseBuyers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VHorseBuyersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLHorseBuyersDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblAddEditDelete
        '
        Me.lblAddEditDelete.AutoSize = True
        Me.lblAddEditDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblAddEditDelete.Location = New System.Drawing.Point(522, 51)
        Me.lblAddEditDelete.Name = "lblAddEditDelete"
        Me.lblAddEditDelete.Size = New System.Drawing.Size(315, 36)
        Me.lblAddEditDelete.TabIndex = 12
        Me.lblAddEditDelete.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(325, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse status " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "of ""InActive"" and may be unde" & _
    "leted any time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(711, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 10
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(754, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(418, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'lblHorseBuyers
        '
        Me.lblHorseBuyers.AutoSize = True
        Me.lblHorseBuyers.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHorseBuyers.Location = New System.Drawing.Point(25, 17)
        Me.lblHorseBuyers.Name = "lblHorseBuyers"
        Me.lblHorseBuyers.Size = New System.Drawing.Size(124, 24)
        Me.lblHorseBuyers.TabIndex = 9
        Me.lblHorseBuyers.Text = "HorseBuyers:"
        '
        'lstHorseBuyers
        '
        Me.lstHorseBuyers.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstHorseBuyers.FormattingEnabled = True
        Me.lstHorseBuyers.ItemHeight = 22
        Me.lstHorseBuyers.Location = New System.Drawing.Point(27, 40)
        Me.lstHorseBuyers.Name = "lstHorseBuyers"
        Me.lstHorseBuyers.ScrollAlwaysVisible = True
        Me.lstHorseBuyers.Size = New System.Drawing.Size(308, 224)
        Me.lstHorseBuyers.Sorted = True
        Me.lstHorseBuyers.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvHorseBuyers
        '
        Me.dgvHorseBuyers.AllowUserToAddRows = False
        Me.dgvHorseBuyers.AllowUserToDeleteRows = False
        Me.dgvHorseBuyers.AutoGenerateColumns = False
        Me.dgvHorseBuyers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHorseBuyers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntHorseBuyerIDDataGridViewTextBoxColumn, Me.StrFullNameDataGridViewTextBoxColumn, Me.StrAddressDataGridViewTextBoxColumn, Me.StrCityDataGridViewTextBoxColumn, Me.StrStateDataGridViewTextBoxColumn, Me.StrZipCodeDataGridViewTextBoxColumn, Me.DecPurchasePriceDataGridViewTextBoxColumn, Me.DteDatePurchasedDataGridViewTextBoxColumn, Me.StrHorseBuyerStatusDataGridViewTextBoxColumn})
        Me.dgvHorseBuyers.DataSource = Me.VHorseBuyersBindingSource
        Me.dgvHorseBuyers.Location = New System.Drawing.Point(28, 312)
        Me.dgvHorseBuyers.Name = "dgvHorseBuyers"
        Me.dgvHorseBuyers.ReadOnly = True
        Me.dgvHorseBuyers.RowTemplate.Height = 24
        Me.dgvHorseBuyers.Size = New System.Drawing.Size(1087, 345)
        Me.dgvHorseBuyers.TabIndex = 13
        '
        'IntHorseBuyerIDDataGridViewTextBoxColumn
        '
        Me.IntHorseBuyerIDDataGridViewTextBoxColumn.DataPropertyName = "intHorseBuyerID"
        Me.IntHorseBuyerIDDataGridViewTextBoxColumn.HeaderText = "intHorseBuyerID"
        Me.IntHorseBuyerIDDataGridViewTextBoxColumn.Name = "IntHorseBuyerIDDataGridViewTextBoxColumn"
        Me.IntHorseBuyerIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrFullNameDataGridViewTextBoxColumn
        '
        Me.StrFullNameDataGridViewTextBoxColumn.DataPropertyName = "strFullName"
        Me.StrFullNameDataGridViewTextBoxColumn.HeaderText = "strFullName"
        Me.StrFullNameDataGridViewTextBoxColumn.Name = "StrFullNameDataGridViewTextBoxColumn"
        Me.StrFullNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrAddressDataGridViewTextBoxColumn
        '
        Me.StrAddressDataGridViewTextBoxColumn.DataPropertyName = "strAddress"
        Me.StrAddressDataGridViewTextBoxColumn.HeaderText = "strAddress"
        Me.StrAddressDataGridViewTextBoxColumn.Name = "StrAddressDataGridViewTextBoxColumn"
        Me.StrAddressDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCityDataGridViewTextBoxColumn
        '
        Me.StrCityDataGridViewTextBoxColumn.DataPropertyName = "strCity"
        Me.StrCityDataGridViewTextBoxColumn.HeaderText = "strCity"
        Me.StrCityDataGridViewTextBoxColumn.Name = "StrCityDataGridViewTextBoxColumn"
        Me.StrCityDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrStateDataGridViewTextBoxColumn
        '
        Me.StrStateDataGridViewTextBoxColumn.DataPropertyName = "strState"
        Me.StrStateDataGridViewTextBoxColumn.HeaderText = "strState"
        Me.StrStateDataGridViewTextBoxColumn.Name = "StrStateDataGridViewTextBoxColumn"
        Me.StrStateDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrZipCodeDataGridViewTextBoxColumn
        '
        Me.StrZipCodeDataGridViewTextBoxColumn.DataPropertyName = "strZipCode"
        Me.StrZipCodeDataGridViewTextBoxColumn.HeaderText = "strZipCode"
        Me.StrZipCodeDataGridViewTextBoxColumn.Name = "StrZipCodeDataGridViewTextBoxColumn"
        Me.StrZipCodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecPurchasePriceDataGridViewTextBoxColumn
        '
        Me.DecPurchasePriceDataGridViewTextBoxColumn.DataPropertyName = "decPurchasePrice"
        Me.DecPurchasePriceDataGridViewTextBoxColumn.HeaderText = "decPurchasePrice"
        Me.DecPurchasePriceDataGridViewTextBoxColumn.Name = "DecPurchasePriceDataGridViewTextBoxColumn"
        Me.DecPurchasePriceDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteDatePurchasedDataGridViewTextBoxColumn
        '
        Me.DteDatePurchasedDataGridViewTextBoxColumn.DataPropertyName = "dteDatePurchased"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.HeaderText = "dteDatePurchased"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.Name = "DteDatePurchasedDataGridViewTextBoxColumn"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrHorseBuyerStatusDataGridViewTextBoxColumn
        '
        Me.StrHorseBuyerStatusDataGridViewTextBoxColumn.DataPropertyName = "strHorseBuyerStatus"
        Me.StrHorseBuyerStatusDataGridViewTextBoxColumn.HeaderText = "strHorseBuyerStatus"
        Me.StrHorseBuyerStatusDataGridViewTextBoxColumn.Name = "StrHorseBuyerStatusDataGridViewTextBoxColumn"
        Me.StrHorseBuyerStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VHorseBuyersBindingSource
        '
        Me.VHorseBuyersBindingSource.DataMember = "VHorseBuyers"
        Me.VHorseBuyersBindingSource.DataSource = Me.CPDM_FoxLHorseBuyersDS
        '
        'CPDM_FoxLHorseBuyersDS
        '
        Me.CPDM_FoxLHorseBuyersDS.DataSetName = "CPDM_FoxLHorseBuyersDS"
        Me.CPDM_FoxLHorseBuyersDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VHorseBuyersTableAdapter
        '
        Me.VHorseBuyersTableAdapter.ClearBeforeFill = True
        '
        'FManageHorseBuyers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1142, 683)
        Me.Controls.Add(Me.dgvHorseBuyers)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.lblAddEditDelete)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblHorseBuyers)
        Me.Controls.Add(Me.lstHorseBuyers)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageHorseBuyers"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Horse Buyers & View the Data"
        CType(Me.dgvHorseBuyers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VHorseBuyersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLHorseBuyersDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblAddEditDelete As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lblHorseBuyers As System.Windows.Forms.Label
    Friend WithEvents lstHorseBuyers As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvHorseBuyers As System.Windows.Forms.DataGridView
    Friend WithEvents CPDM_FoxLHorseBuyersDS As CapstoneHorseApplication.CPDM_FoxLHorseBuyersDS
    Friend WithEvents VHorseBuyersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VHorseBuyersTableAdapter As CapstoneHorseApplication.CPDM_FoxLHorseBuyersDSTableAdapters.VHorseBuyersTableAdapter
    Friend WithEvents IntHorseBuyerIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrFullNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrAddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCityDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrStateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrZipCodeDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecPurchasePriceDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteDatePurchasedDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrHorseBuyerStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
