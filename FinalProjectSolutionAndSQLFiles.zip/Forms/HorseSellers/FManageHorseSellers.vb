﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse project- Manage Horse Sellers (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Imports System.Data.SqlClient


Public Class FManageHorseSellers

    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadHorseSellersList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the Horse Sellers list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseSellersList
    ' Abstract: Load the Horse Sellers list.
    ' --------------------------------------------------------------------------------
    Private Function LoadHorseSellersList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveHorseSellers"

            Else

                strSourceTable = "VInActiveHorseSellers"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intHorseSellerID", _
                                                        "strFullName", _
                                                        lstHorseSellers)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add Horse Seller form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewHorseSellerInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddHorseSeller forms
            Dim frmAddHorseSeller As FAddHorseSeller

            ' Make an instance
            frmAddHorseSeller = New FAddHorseSeller

            ' Show modally
            frmAddHorseSeller.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddHorseSeller.GetResult() = True Then

                ' Get the new Horse Seller values
                liNewHorseSellerInformation = frmAddHorseSeller.GetNewHorseSellerInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstHorseSellers.Items.Add(liNewHorseSellerInformation)

                ' ... which we can use to select it
                lstHorseSellers.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected Horse Seller.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedHorseSellerID As Integer
            Dim liSelectedHorseSeller As CListItem
            Dim frmEditHorseSeller As FEditHorseSeller
            Dim liNewHorseSellerInformation As CListItem
            Dim intIndex As Integer

            ' Is a Horse Seller selected?
            If lstHorseSellers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Seller to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the Horse Seller to edit ID
                liSelectedHorseSeller = lstHorseSellers.SelectedItem
                intSelectedHorseSellerID = liSelectedHorseSeller.GetID

                ' Create instance
                frmEditHorseSeller = New FEditHorseSeller

                ' Set the form values
                frmEditHorseSeller.SetHorseSellerID(intSelectedHorseSellerID)

                ' Show it modally   
                frmEditHorseSeller.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditHorseSeller.GetResult() = True Then

                    ' Get the new Horse Seller values
                    liNewHorseSellerInformation = frmEditHorseSeller.GetNewHorseSellerInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstHorseSellers.Items.RemoveAt(lstHorseSellers.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstHorseSellers.Items.Add(liNewHorseSellerInformation)

                    ' ... which we can use to select it
                    lstHorseSellers.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected Horse Seller.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteHorseSeller()

            Else

                ' No, undelete
                UndeleteHorseSeller()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHorseSeller
    ' Abstract: Delete the currently selected Seller.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteHorseSeller()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorseSeller As CListItem
            Dim intSelectedHorseSellerID As Integer
            Dim strSelectedHorseSellerName As String
            Dim intSelectedHorseSellerIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Horse Seller selected?
            If lstHorseSellers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Seller to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Horse ID, name and list index
                liSelectedHorseSeller = lstHorseSellers.SelectedItem
                intSelectedHorseSellerID = liSelectedHorseSeller.GetID
                strSelectedHorseSellerName = liSelectedHorseSeller.GetName
                intSelectedHorseSellerIndex = lstHorseSellers.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Horse Seller: " & strSelectedHorseSellerName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Horse Seller (use ID for database command)
                    blnResult = DeleteHorseSellerFromDatabase(intSelectedHorseSellerID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Horse Seller from the list
                        lstHorseSellers.Items.RemoveAt(intSelectedHorseSellerIndex)

                        ' Select the next Horse Seller in the list
                        HighlightNextItemInList(lstHorseSellers, intSelectedHorseSellerIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHorseSeller
    ' Abstract: Undelete the currently selected Seller.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteHorseSeller()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorseSeller As CListItem
            Dim intSelectedHorseSellerID As Integer
            Dim intSelectedHorseSellerIndex As Integer
            Dim blnResult As Boolean

            ' Is a Horse Seller selected?
            If lstHorseSellers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Seller to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Horse Seller ID and list index
                liSelectedHorseSeller = lstHorseSellers.SelectedItem
                intSelectedHorseSellerID = liSelectedHorseSeller.GetID
                intSelectedHorseSellerIndex = lstHorseSellers.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Horse Seller (use ID for database command)
                blnResult = UndeleteHorseSellerFromDatabase(intSelectedHorseSellerID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Horse Seller from the list
                    lstHorseSellers.Items.RemoveAt(intSelectedHorseSellerIndex)

                    ' Select the next Horse Seller in the list
                    HighlightNextItemInList(lstHorseSellers, intSelectedHorseSellerIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horse Sellers.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Horses list
            LoadHorseSellersList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VHorseSellersTableAdapter.Fill(Me.CPDM_FoxLHorseSellersDS.VHorseSellers)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FManageHorses_Load
    ' Abstract: Loads the DataSet and populates the dataGridView on form load.
    '           I could not use this without getting a cartesian product when I clicked
    '           the button. But it made a nice place to store the code for the button.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageHorseSellers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLHorseSellersDS.VHorseSellers' table. 
    '    Me.VHorseSellersTableAdapter.Fill(Me.CPDM_FoxLHorseSellersDS.VHorseSellers)

    'End Sub
End Class