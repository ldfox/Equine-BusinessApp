﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FEditFeedMiscExpense
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDateDewormedFormat = New System.Windows.Forms.Label()
        Me.lblRequired = New System.Windows.Forms.Label()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.txtDatePurchased = New System.Windows.Forms.TextBox()
        Me.txtExpenseCost = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblComments = New System.Windows.Forms.Label()
        Me.lblDatePurchased = New System.Windows.Forms.Label()
        Me.lblExpenseCost = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblDateDewormedFormat
        '
        Me.lblDateDewormedFormat.AutoSize = True
        Me.lblDateDewormedFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateDewormedFormat.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblDateDewormedFormat.Location = New System.Drawing.Point(87, 128)
        Me.lblDateDewormedFormat.Name = "lblDateDewormedFormat"
        Me.lblDateDewormedFormat.Size = New System.Drawing.Size(84, 17)
        Me.lblDateDewormedFormat.TabIndex = 8
        Me.lblDateDewormedFormat.Text = "yyyy-mm-dd"
        '
        'lblRequired
        '
        Me.lblRequired.AutoSize = True
        Me.lblRequired.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequired.Location = New System.Drawing.Point(224, 172)
        Me.lblRequired.Name = "lblRequired"
        Me.lblRequired.Size = New System.Drawing.Size(117, 18)
        Me.lblRequired.TabIndex = 6
        Me.lblRequired.Text = "*=Required Field"
        '
        'txtComments
        '
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(228, 143)
        Me.txtComments.MaxLength = 50
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(261, 28)
        Me.txtComments.TabIndex = 3
        '
        'txtDatePurchased
        '
        Me.txtDatePurchased.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDatePurchased.Location = New System.Drawing.Point(228, 106)
        Me.txtDatePurchased.Name = "txtDatePurchased"
        Me.txtDatePurchased.Size = New System.Drawing.Size(261, 28)
        Me.txtDatePurchased.TabIndex = 2
        '
        'txtExpenseCost
        '
        Me.txtExpenseCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtExpenseCost.Location = New System.Drawing.Point(228, 69)
        Me.txtExpenseCost.Name = "txtExpenseCost"
        Me.txtExpenseCost.Size = New System.Drawing.Size(261, 28)
        Me.txtExpenseCost.TabIndex = 1
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(295, 203)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(168, 39)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(60, 203)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(168, 39)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(228, 32)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(261, 28)
        Me.txtName.TabIndex = 0
        '
        'lblComments
        '
        Me.lblComments.AutoSize = True
        Me.lblComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComments.Location = New System.Drawing.Point(33, 146)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(106, 24)
        Me.lblComments.TabIndex = 7
        Me.lblComments.Text = "Comments:"
        '
        'lblDatePurchased
        '
        Me.lblDatePurchased.AutoSize = True
        Me.lblDatePurchased.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDatePurchased.Location = New System.Drawing.Point(33, 109)
        Me.lblDatePurchased.Name = "lblDatePurchased"
        Me.lblDatePurchased.Size = New System.Drawing.Size(156, 24)
        Me.lblDatePurchased.TabIndex = 9
        Me.lblDatePurchased.Text = "Date Purchased:*"
        '
        'lblExpenseCost
        '
        Me.lblExpenseCost.AutoSize = True
        Me.lblExpenseCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExpenseCost.Location = New System.Drawing.Point(33, 72)
        Me.lblExpenseCost.Name = "lblExpenseCost"
        Me.lblExpenseCost.Size = New System.Drawing.Size(133, 24)
        Me.lblExpenseCost.TabIndex = 10
        Me.lblExpenseCost.Text = "Expense Cost:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(33, 35)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(73, 24)
        Me.lblName.TabIndex = 11
        Me.lblName.Text = "Name:*"
        '
        'FEditFeedMiscExpense
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 268)
        Me.Controls.Add(Me.lblDateDewormedFormat)
        Me.Controls.Add(Me.lblRequired)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.txtDatePurchased)
        Me.Controls.Add(Me.txtExpenseCost)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblComments)
        Me.Controls.Add(Me.lblDatePurchased)
        Me.Controls.Add(Me.lblExpenseCost)
        Me.Controls.Add(Me.lblName)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FEditFeedMiscExpense"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Edit Feed Misc. Expense"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDateDewormedFormat As System.Windows.Forms.Label
    Friend WithEvents lblRequired As System.Windows.Forms.Label
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents txtDatePurchased As System.Windows.Forms.TextBox
    Friend WithEvents txtExpenseCost As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents lblDatePurchased As System.Windows.Forms.Label
    Friend WithEvents lblExpenseCost As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
End Class
