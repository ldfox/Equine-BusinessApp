﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Horse Shoes
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignHorseShoes


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignHorseShoes_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignHorseShoes_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveHorses", "intHorseID", "strName", cmbHorses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseShoes
    ' Abstract: Load the selected and available Shoe lists for the current Horse.
    ' --------------------------------------------------------------------------------
    Private Sub LoadHorseShoes()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorse As CListItem
            Dim intHorseID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Horse selected
            If cmbHorses.SelectedIndex >= 0 Then

                ' Get the selected Horse ID
                liSelectedHorse = cmbHorses.SelectedItem
                intHorseID = liSelectedHorse.GetID

                ' Selected Shoes
                ModDatabaseUtilities.LoadListWithShoesFromDatabase2(intHorseID, lstSelectedShoes, True)

                ' Available Shoes
                ModDatabaseUtilities.LoadListWithShoesFromDatabase2(intHorseID, lstAvailableShoes, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableShoes.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableShoes.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedShoes.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedShoes.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all Shoes to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intIndex As Integer

            ' Is a Shoe selected?
            If lstAvailableShoes.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Shoe IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableShoes.SelectedItem


                ' Add the Shoes from lstAvailableShoes 
                'If AddAllAvailableShoesFromDatabaseMSAccess(intHorseID) = True Then
                If AddAllAvailableShoesToHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableShoes.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedShoes from lstAvailableShoes
                        lstSelectedShoes.Items.Add(lstAvailableShoes.Items(0))

                        ' Remove from lstAvailableShoes
                        lstAvailableShoes.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedShoes then ...
                    If lstSelectedShoes.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedShoes.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Shoe to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intShoeID As Integer
            Dim intIndex As Integer

            ' Is a Shoe selected?
            If lstAvailableShoes.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Shoe IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableShoes.SelectedItem
                intShoeID = liSelectedItem.GetID

                ' Add the Shoe
                'If AddShoeToHorseInDatabaseMSAccess(intHorseID, intShoeID) = True Then
                If AddShoeToHorseInDatabase2(intHorseID, intShoeID) = True Then

                    ' Add to selected Shoes
                    intIndex = lstSelectedShoes.Items.Add(lstAvailableShoes.SelectedItem)
                    lstSelectedShoes.SelectedIndex = intIndex

                    ' Remove from available Shoes
                    intIndex = lstAvailableShoes.SelectedIndex
                    lstAvailableShoes.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableShoes, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected Shoe from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intShoeID As Integer
            Dim intIndex As Integer

            If lstSelectedShoes.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Shoe IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedShoes.SelectedItem
                intShoeID = liSelectedItem.GetID

                ' Remove the Shoe
                'If RemoveShoeFromHorseInDatabaseMSAccess(intHorseID, intShoeID) = True Then
                If RemoveShoeFromHorseInDatabase2(intHorseID, intShoeID) = True Then

                    ' Add to available Shoes
                    intIndex = lstAvailableShoes.Items.Add(lstSelectedShoes.SelectedItem)
                    lstAvailableShoes.SelectedIndex = intIndex

                    ' Remove from selected Shoes
                    intIndex = lstSelectedShoes.SelectedIndex
                    lstSelectedShoes.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedShoes, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the Shoes from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intShoeID As Integer
            Dim intIndex As Integer

            If lstSelectedShoes.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Shoe IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedShoes.SelectedItem
                intShoeID = liSelectedItem.GetID

                ' Remove the Shoe
                'If RemoveAllShoesFromHorseInDatabaseMSAccess(intHorseID) = True Then
                If RemoveAllSelectedShoesFromHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedShoes.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableShoes from lstSelectedShoes
                        lstAvailableShoes.Items.Add(lstSelectedShoes.Items(0))

                        ' Remove from lstSelectedShoes
                        lstSelectedShoes.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedShoes then ...
                    If lstAvailableShoes.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableShoes.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbHorses_SelectedIndexChanged
    ' Abstract: Load the selected and available Shoe lists for the current Horse.
    ' -------------------------------------------------------------------------
    Private Sub cmbHorses_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbHorses.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadHorseShoes()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class