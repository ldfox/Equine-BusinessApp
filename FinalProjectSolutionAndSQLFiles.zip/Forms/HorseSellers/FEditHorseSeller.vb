﻿' -------------------------------------------------------------------------------------
' Name: FEditHorseSellers
' Abstract: Capstone Horse project - Edit Horse Sellers (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditHorseSeller


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHorseSellerID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetHorseSellerID
    ' Abstract: What Horse Seller are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetHorseSellerID(ByVal intHorseSellerID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' Horse Seller ID
            f_intHorseSellerID = intHorseSellerID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditHorse_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditHorseSeller_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtHorseSeller As udtHorseSellerType

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("TStates", "intStateID", "strState", cmbState)

            ' Make a suitcase instace
            udtHorseSeller = New udtHorseSellerType

            ' Set the ID
            udtHorseSeller.intHorseSellerID = f_intHorseSellerID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetHorseSellerInformationFromDatabase(udtHorseSeller) = True Then

                With udtHorseSeller

                    txtFullName.Text = .strFullName
                    txtAddress.Text = .strAddress
                    txtCity.Text = .strCity
                    SelectItemInListFromID(cmbState, .intStateID)
                    txtZipCode.Text = .strZipCode
                    txtSellingPrice.Text = .decSellingPrice.ToString("c")
                    txtSellingPrice.Text = .decSellingPrice.ToString("c2")    ' Currency with 2 decimal points
                    txtSellingPrice.Text = FormatCurrency(.decSellingPrice)

                    If .dteDateSold <> "1800/01/01" Then

                        txtDateSold.Text = .dteDateSold.ToString("yyyy/MM/dd")

                    End If

                End With

            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for Horse Seller to edit." & vbNewLine & _
                                "The form will now close.", "Edit Horse Seller Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Horse Seller to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Horse Seller to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Full Name
            If txtFullName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Zip Code
            If txtZipCode.Text <> "" Then

                ' Is valid format?
                If IsValidZipCode(txtZipCode.Text) = False Then

                    strErrorMessage &= "-Zip Code is an invalid format" & vbNewLine
                    blnIsValidData = False

                End If

            End If

            ' Selling Price
            If txtSellingPrice.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtSellingPrice.Text) = False Then

                    strErrorMessage &= "-Selling Price is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Date Sold
            If txtDateSold.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDateSold.Text) = False Then

                    strErrorMessage &= "-Date Sold is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtHorseSeller As New udtHorseSellerType

            ' Load it up with data from the form
            udtHorseSeller = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditHorseSellerInDatabase2(udtHorseSeller)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHorseSellerType

        Dim udtHorseSeller As New udtHorseSellerType

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedStateID As Integer
            Dim liSelectedState As CListItem
            Dim strSellingPrice As String

            ' Load up with data from the form
            ' ID
            udtHorseSeller.intHorseSellerID = f_intHorseSellerID

            'Name 
            udtHorseSeller.strFullName = txtFullName.Text

            ' Address
            udtHorseSeller.strAddress = txtAddress.Text

            ' City
            udtHorseSeller.strCity = txtCity.Text

            ' State
            liSelectedState = cmbState.SelectedItem
            intSelectedStateID = liSelectedState.GetID
            udtHorseSeller.intStateID = intSelectedStateID

            ' Zip Code
            udtHorseSeller.strZipCode = txtZipCode.Text

            ' Selling Price
            strSellingPrice = txtSellingPrice.Text
            strSellingPrice = strSellingPrice.Replace("$", "")
            strSellingPrice = strSellingPrice.Replace(",", "")
            udtHorseSeller.decSellingPrice = Val(strSellingPrice)

            ' Date Sold
            ' Boundary check - if textbox is empty
            If txtDateSold.Text = "" Then

                ' Then insert date
                udtHorseSeller.dteDateSold = "1800/01/01"

            Else

                ' Else txtDateSold has a value
                udtHorseSeller.dteDateSold = txtDateSold.Text

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHorseSeller

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHorseSellerInformation
    ' Abstract: Get the new Horse Seller information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHorseSellerInformation() As CListItem

        Dim liHorseSeller As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strFullName As String

            ' Full Name
            strFullName = txtFullName.Text

            'Make an instance of CListItem
            liHorseSeller = New CListItem(f_intHorseSellerID, strFullName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHorseSeller

    End Function

End Class