﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Horse WestNileTests
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignHorseWestNileTests


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignHorseWestNileTests_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignHorseWestNileTests_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveHorses", "intHorseID", "strName", cmbHorses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseWestNileTests
    ' Abstract: Load the selected and available WestNileTest lists for the current Horse.
    ' --------------------------------------------------------------------------------
    Private Sub LoadHorseWestNileTests()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorse As CListItem
            Dim intHorseID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Horse selected
            If cmbHorses.SelectedIndex >= 0 Then

                ' Get the selected Horse ID
                liSelectedHorse = cmbHorses.SelectedItem
                intHorseID = liSelectedHorse.GetID

                ' Selected WestNileTests
                ModDatabaseUtilities.LoadListWithWestNileTestsFromDatabase2(intHorseID, lstSelectedWestNileTests, True)

                ' Available WestNileTests
                ModDatabaseUtilities.LoadListWithWestNileTestsFromDatabase2(intHorseID, lstAvailableWestNileTests, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableWestNileTests.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableWestNileTests.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedWestNileTests.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedWestNileTests.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all WestNileTests to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intIndex As Integer

            ' Is a WestNileTest selected?
            If lstAvailableWestNileTests.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and WestNileTest IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableWestNileTests.SelectedItem


                ' Add the WestNileTests from lstAvailableWestNileTests 
                'If AddAllAvailableWestNileTestsFromDatabaseMSAccess(intHorseID) = True Then
                If AddAllAvailableWestNileTestsToHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableWestNileTests.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedWestNileTests from lstAvailableWestNileTests
                        lstSelectedWestNileTests.Items.Add(lstAvailableWestNileTests.Items(0))

                        ' Remove from lstAvailableWestNileTests
                        lstAvailableWestNileTests.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedWestNileTests then ...
                    If lstSelectedWestNileTests.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedWestNileTests.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a WestNileTest to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intWestNileTestID As Integer
            Dim intIndex As Integer

            ' Is a WestNileTest selected?
            If lstAvailableWestNileTests.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and WestNileTest IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableWestNileTests.SelectedItem
                intWestNileTestID = liSelectedItem.GetID

                ' Add the WestNileTest
                'If AddWestNileTestToHorseInDatabaseMSAccess(intHorseID, intWestNileTestID) = True Then
                If AddWestNileTestToHorseInDatabase2(intHorseID, intWestNileTestID) = True Then

                    ' Add to selected WestNileTests
                    intIndex = lstSelectedWestNileTests.Items.Add(lstAvailableWestNileTests.SelectedItem)
                    lstSelectedWestNileTests.SelectedIndex = intIndex

                    ' Remove from available WestNileTests
                    intIndex = lstAvailableWestNileTests.SelectedIndex
                    lstAvailableWestNileTests.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableWestNileTests, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected WestNileTest from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intWestNileTestID As Integer
            Dim intIndex As Integer

            If lstSelectedWestNileTests.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and WestNileTest IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedWestNileTests.SelectedItem
                intWestNileTestID = liSelectedItem.GetID

                ' Remove the WestNileTest
                'If RemoveWestNileTestFromHorseInDatabaseMSAccess(intHorseID, intWestNileTestID) = True Then
                If RemoveWestNileTestFromHorseInDatabase2(intHorseID, intWestNileTestID) = True Then

                    ' Add to available WestNileTests
                    intIndex = lstAvailableWestNileTests.Items.Add(lstSelectedWestNileTests.SelectedItem)
                    lstAvailableWestNileTests.SelectedIndex = intIndex

                    ' Remove from selected WestNileTests
                    intIndex = lstSelectedWestNileTests.SelectedIndex
                    lstSelectedWestNileTests.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedWestNileTests, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the WestNileTests from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intWestNileTestID As Integer
            Dim intIndex As Integer

            If lstSelectedWestNileTests.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and WestNileTest IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedWestNileTests.SelectedItem
                intWestNileTestID = liSelectedItem.GetID

                ' Remove the WestNileTest
                'If RemoveAllWestNileTestsFromHorseInDatabaseMSAccess(intHorseID) = True Then
                If RemoveAllSelectedWestNileTestsFromHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedWestNileTests.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableWestNileTests from lstSelectedWestNileTests
                        lstAvailableWestNileTests.Items.Add(lstSelectedWestNileTests.Items(0))

                        ' Remove from lstSelectedWestNileTests
                        lstSelectedWestNileTests.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedWestNileTests then ...
                    If lstAvailableWestNileTests.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableWestNileTests.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbHorses_SelectedIndexChanged
    ' Abstract: Load the selected and available WestNileTest lists for the current Horse.
    ' -------------------------------------------------------------------------
    Private Sub cmbHorses_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbHorses.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadHorseWestNileTests()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class