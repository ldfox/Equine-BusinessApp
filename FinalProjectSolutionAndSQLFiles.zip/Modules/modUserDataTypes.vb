﻿' ------------------------------------------------------------------------------------
' Module: modUserDataTypes
' Abstract: Capstone Horse project - Suitcases for traveling with data.
' ------------------------------------------------------------------------------------

' ------------------------------------------------------------------------------------
' Options
' ------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Module modUserDataTypes

    ' Structures are like suitcases.
    ' It's a lot easier to carry one suitcase instead of a whole bunch of loose items.
    ' Same with passing data to a procedure.  Instead of having 4+ variables just use
    ' a structure.

    ' HorseBuyers
    Public Structure udtHorseBuyerType
        Dim intHorseBuyerID As Integer
        Dim strFullName As String
        Dim strAddress As String
        Dim strCity As String
        Dim intStateID As Integer
        Dim strZipCode As String
        Dim decPurchasePrice As Decimal
        Dim dteDatePurchased As Date
        Dim intHorseBuyerStatusID As Integer

    End Structure

    ' HorseSellers
    Public Structure udtHorseSellerType

        Dim intHorseSellerID As Integer
        Dim strFullName As String
        Dim strAddress As String
        Dim strCity As String
        Dim intStateID As Integer
        Dim strZipCode As String
        Dim decSellingPrice As Decimal
        Dim dteDateSold As Date
        Dim intHorseSellerStatusID As Integer

    End Structure

    ' Horses 
    Public Structure udtHorseType

        Dim intHorseID As Integer
        Dim strName As String
        Dim intBreedID As Integer
        Dim strRegistration As String
        Dim intColorID As Integer
        Dim intSexID As Integer
        Dim strHeight As String
        Dim intHorseBuyerID As Integer
        Dim intHorseSellerID As Integer
        Dim strComments As String
        Dim intHorseStatusID As Integer

    End Structure

    ' Shoes
    Public Structure udtShoeType
        Dim intShoeID As Integer
        Dim strName As String
        Dim dteShod As Date
        Dim strTrimAngle As String
        Dim decFarrierCost As Decimal
        Dim strComments As String
        Dim intShoeStatusID As Integer

    End Structure

    ' Vaccinations
    Public Structure udtVaccinationType
        Dim intVaccinationID As Integer
        Dim strName As String
        Dim decVaccinationCost As Decimal
        Dim dteVaccinationDate As Date
        Dim strComments As String
        Dim intVaccinationStatusID As Integer

    End Structure

    ' WestNileTest
    Public Structure udtWestNileTestType
        Dim intWestNileTestID As Integer
        Dim strName As String
        Dim dteWestNileTestDate As Date
        Dim decWestNileTestCost As Decimal
        Dim strComments As String
        Dim intWestNileTestStatusID As Integer

    End Structure

    ' Dewormers
    Public Structure udtDewormerType
        Dim intDewormerID As Integer
        Dim strName As String
        Dim dteDewormerDate As Date
        Dim decDewormerCost As Decimal
        Dim intDewormerStatusID As Integer

    End Structure

    ' HealthCertificates
    Public Structure udtHealthCertificateType
        Dim intHealthCertificateID As Integer
        Dim strName As String
        Dim dteHealthCertificateDate As Date
        Dim decHealthCertificateCost As Decimal
        Dim strComments As String
        Dim intHealthCertificateStatusID As Integer

    End Structure

    ' FeedMiscExpense
    Public Structure udtFeedMiscExpenseType
        Dim intFeedMiscExpenseID As Integer
        Dim strName As String
        Dim decExpenseCost As Decimal
        Dim dteDatePurchased As Date
        Dim strComments As String
        Dim intFeedMiscExpenseStatusID As Integer

    End Structure

    ' Equipment
    Public Structure udtEquipmentType
        Dim intEquipmentID As Integer
        Dim strName As String
        Dim dtePurchaseDate As Date
        Dim decCost As Decimal
        Dim strComments As String
        Dim intEquipmentStatusID As Integer

    End Structure

    ' Maintenance
    Public Structure udtMaintenanceType
        Dim intMaintenanceID As Integer
        Dim strName As String
        Dim dteMaintenanceDate As Date
        Dim decMaintenanceCost As Decimal
        Dim strComments As String
        Dim intMaintenanceStatusID As Integer

    End Structure

End Module
