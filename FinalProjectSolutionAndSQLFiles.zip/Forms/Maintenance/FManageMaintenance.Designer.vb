﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageMaintenance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvMaintenance = New System.Windows.Forms.DataGridView()
        Me.IntMaintenanceIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteMaintenanceDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecMaintenanceCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCommentsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrMaintenanceStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VMaintenanceBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLMaintenanceDS = New CapstoneHorseApplication.CPDM_FoxLMaintenanceDS()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lbllblMaintenance = New System.Windows.Forms.Label()
        Me.lstMaintenance = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.VMaintenanceTableAdapter = New CapstoneHorseApplication.CPDM_FoxLMaintenanceDSTableAdapters.VMaintenanceTableAdapter()
        CType(Me.dgvMaintenance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VMaintenanceBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLMaintenanceDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvMaintenance
        '
        Me.dgvMaintenance.AllowUserToAddRows = False
        Me.dgvMaintenance.AllowUserToDeleteRows = False
        Me.dgvMaintenance.AutoGenerateColumns = False
        Me.dgvMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMaintenance.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntMaintenanceIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.DteMaintenanceDateDataGridViewTextBoxColumn, Me.DecMaintenanceCostDataGridViewTextBoxColumn, Me.StrCommentsDataGridViewTextBoxColumn, Me.StrMaintenanceStatusDataGridViewTextBoxColumn})
        Me.dgvMaintenance.DataSource = Me.VMaintenanceBindingSource
        Me.dgvMaintenance.Location = New System.Drawing.Point(26, 310)
        Me.dgvMaintenance.Name = "dgvMaintenance"
        Me.dgvMaintenance.ReadOnly = True
        Me.dgvMaintenance.RowTemplate.Height = 24
        Me.dgvMaintenance.Size = New System.Drawing.Size(967, 348)
        Me.dgvMaintenance.TabIndex = 6
        '
        'IntMaintenanceIDDataGridViewTextBoxColumn
        '
        Me.IntMaintenanceIDDataGridViewTextBoxColumn.DataPropertyName = "intMaintenanceID"
        Me.IntMaintenanceIDDataGridViewTextBoxColumn.HeaderText = "intMaintenanceID"
        Me.IntMaintenanceIDDataGridViewTextBoxColumn.Name = "IntMaintenanceIDDataGridViewTextBoxColumn"
        Me.IntMaintenanceIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteMaintenanceDateDataGridViewTextBoxColumn
        '
        Me.DteMaintenanceDateDataGridViewTextBoxColumn.DataPropertyName = "dteMaintenanceDate"
        Me.DteMaintenanceDateDataGridViewTextBoxColumn.HeaderText = "dteMaintenanceDate"
        Me.DteMaintenanceDateDataGridViewTextBoxColumn.Name = "DteMaintenanceDateDataGridViewTextBoxColumn"
        Me.DteMaintenanceDateDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecMaintenanceCostDataGridViewTextBoxColumn
        '
        Me.DecMaintenanceCostDataGridViewTextBoxColumn.DataPropertyName = "decMaintenanceCost"
        Me.DecMaintenanceCostDataGridViewTextBoxColumn.HeaderText = "decMaintenanceCost"
        Me.DecMaintenanceCostDataGridViewTextBoxColumn.Name = "DecMaintenanceCostDataGridViewTextBoxColumn"
        Me.DecMaintenanceCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCommentsDataGridViewTextBoxColumn
        '
        Me.StrCommentsDataGridViewTextBoxColumn.DataPropertyName = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.HeaderText = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.Name = "StrCommentsDataGridViewTextBoxColumn"
        Me.StrCommentsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrMaintenanceStatusDataGridViewTextBoxColumn
        '
        Me.StrMaintenanceStatusDataGridViewTextBoxColumn.DataPropertyName = "strMaintenanceStatus"
        Me.StrMaintenanceStatusDataGridViewTextBoxColumn.HeaderText = "strMaintenanceStatus"
        Me.StrMaintenanceStatusDataGridViewTextBoxColumn.Name = "StrMaintenanceStatusDataGridViewTextBoxColumn"
        Me.StrMaintenanceStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VMaintenanceBindingSource
        '
        Me.VMaintenanceBindingSource.DataMember = "VMaintenance"
        Me.VMaintenanceBindingSource.DataSource = Me.CPDM_FoxLMaintenanceDS
        '
        'CPDM_FoxLMaintenanceDS
        '
        Me.CPDM_FoxLMaintenanceDS.DataSetName = "CPDM_FoxLMaintenanceDS"
        Me.CPDM_FoxLMaintenanceDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(522, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(315, 36)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(291, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "status of 2 and may be undeleted any" & _
    " time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(522, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 10
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(702, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(366, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'lbllblMaintenance
        '
        Me.lbllblMaintenance.AutoSize = True
        Me.lbllblMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllblMaintenance.Location = New System.Drawing.Point(25, 17)
        Me.lbllblMaintenance.Name = "lbllblMaintenance"
        Me.lbllblMaintenance.Size = New System.Drawing.Size(124, 24)
        Me.lbllblMaintenance.TabIndex = 9
        Me.lbllblMaintenance.Text = "Maintenance:"
        '
        'lstMaintenance
        '
        Me.lstMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstMaintenance.FormattingEnabled = True
        Me.lstMaintenance.ItemHeight = 22
        Me.lstMaintenance.Location = New System.Drawing.Point(27, 40)
        Me.lstMaintenance.Name = "lstMaintenance"
        Me.lstMaintenance.ScrollAlwaysVisible = True
        Me.lstMaintenance.Size = New System.Drawing.Size(308, 224)
        Me.lstMaintenance.Sorted = True
        Me.lstMaintenance.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'VMaintenanceTableAdapter
        '
        Me.VMaintenanceTableAdapter.ClearBeforeFill = True
        '
        'FManageMaintenance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1018, 683)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.dgvMaintenance)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lbllblMaintenance)
        Me.Controls.Add(Me.lstMaintenance)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageMaintenance"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Maintenance & View the Data"
        CType(Me.dgvMaintenance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VMaintenanceBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLMaintenanceDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvMaintenance As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lbllblMaintenance As System.Windows.Forms.Label
    Friend WithEvents lstMaintenance As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents CPDM_FoxLMaintenanceDS As CapstoneHorseApplication.CPDM_FoxLMaintenanceDS
    Friend WithEvents VMaintenanceBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VMaintenanceTableAdapter As CapstoneHorseApplication.CPDM_FoxLMaintenanceDSTableAdapters.VMaintenanceTableAdapter
    Friend WithEvents IntMaintenanceIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteMaintenanceDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecMaintenanceCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCommentsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrMaintenanceStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
