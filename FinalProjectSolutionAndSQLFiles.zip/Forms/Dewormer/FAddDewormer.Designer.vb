﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAddDewormer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDateDewormedFormat = New System.Windows.Forms.Label()
        Me.lblRequired = New System.Windows.Forms.Label()
        Me.txtDewormerDate = New System.Windows.Forms.TextBox()
        Me.txtDewormerCost = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblDewormerDate = New System.Windows.Forms.Label()
        Me.lblDewormerCost = New System.Windows.Forms.Label()
        Me.lblDewormerName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblDateDewormedFormat
        '
        Me.lblDateDewormedFormat.AutoSize = True
        Me.lblDateDewormedFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateDewormedFormat.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblDateDewormedFormat.Location = New System.Drawing.Point(95, 92)
        Me.lblDateDewormedFormat.Name = "lblDateDewormedFormat"
        Me.lblDateDewormedFormat.Size = New System.Drawing.Size(84, 17)
        Me.lblDateDewormedFormat.TabIndex = 7
        Me.lblDateDewormedFormat.Text = "yyyy-mm-dd"
        '
        'lblRequired
        '
        Me.lblRequired.AutoSize = True
        Me.lblRequired.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequired.Location = New System.Drawing.Point(224, 136)
        Me.lblRequired.Name = "lblRequired"
        Me.lblRequired.Size = New System.Drawing.Size(117, 18)
        Me.lblRequired.TabIndex = 5
        Me.lblRequired.Text = "*=Required Field"
        '
        'txtDewormerDate
        '
        Me.txtDewormerDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDewormerDate.Location = New System.Drawing.Point(228, 69)
        Me.txtDewormerDate.Name = "txtDewormerDate"
        Me.txtDewormerDate.Size = New System.Drawing.Size(261, 28)
        Me.txtDewormerDate.TabIndex = 1
        '
        'txtDewormerCost
        '
        Me.txtDewormerCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDewormerCost.Location = New System.Drawing.Point(228, 106)
        Me.txtDewormerCost.Name = "txtDewormerCost"
        Me.txtDewormerCost.Size = New System.Drawing.Size(261, 28)
        Me.txtDewormerCost.TabIndex = 2
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(295, 168)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(168, 39)
        Me.btnCancel.TabIndex = 4
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(60, 168)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(168, 39)
        Me.btnOK.TabIndex = 3
        Me.btnOK.Text = "&OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(228, 32)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(261, 28)
        Me.txtName.TabIndex = 0
        '
        'lblDewormerDate
        '
        Me.lblDewormerDate.AutoSize = True
        Me.lblDewormerDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDewormerDate.Location = New System.Drawing.Point(33, 72)
        Me.lblDewormerDate.Name = "lblDewormerDate"
        Me.lblDewormerDate.Size = New System.Drawing.Size(153, 24)
        Me.lblDewormerDate.TabIndex = 8
        Me.lblDewormerDate.Text = "Dewormer Date:*"
        '
        'lblDewormerCost
        '
        Me.lblDewormerCost.AutoSize = True
        Me.lblDewormerCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDewormerCost.Location = New System.Drawing.Point(33, 109)
        Me.lblDewormerCost.Name = "lblDewormerCost"
        Me.lblDewormerCost.Size = New System.Drawing.Size(145, 24)
        Me.lblDewormerCost.TabIndex = 6
        Me.lblDewormerCost.Text = "Dewormer Cost:"
        '
        'lblDewormerName
        '
        Me.lblDewormerName.AutoSize = True
        Me.lblDewormerName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDewormerName.Location = New System.Drawing.Point(33, 35)
        Me.lblDewormerName.Name = "lblDewormerName"
        Me.lblDewormerName.Size = New System.Drawing.Size(166, 24)
        Me.lblDewormerName.TabIndex = 9
        Me.lblDewormerName.Text = "Dewormer Name:*"
        '
        'FAddDewormer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 235)
        Me.Controls.Add(Me.lblDateDewormedFormat)
        Me.Controls.Add(Me.lblRequired)
        Me.Controls.Add(Me.txtDewormerDate)
        Me.Controls.Add(Me.txtDewormerCost)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblDewormerDate)
        Me.Controls.Add(Me.lblDewormerCost)
        Me.Controls.Add(Me.lblDewormerName)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAddDewormer"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add Dewormer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDateDewormedFormat As System.Windows.Forms.Label
    Friend WithEvents lblRequired As System.Windows.Forms.Label
    Friend WithEvents txtDewormerDate As System.Windows.Forms.TextBox
    Friend WithEvents txtDewormerCost As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblDewormerDate As System.Windows.Forms.Label
    Friend WithEvents lblDewormerCost As System.Windows.Forms.Label
    Friend WithEvents lblDewormerName As System.Windows.Forms.Label
End Class
