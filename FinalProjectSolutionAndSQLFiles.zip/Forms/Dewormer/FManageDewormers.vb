﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageDewormers
' Abstract: Capstone Horse project- Manage the horses Dewormers (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageDewormers


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadDewormersList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the Dewormers list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadDewormersList
    ' Abstract: Load the horse Dewormers list.
    ' --------------------------------------------------------------------------------
    Private Function LoadDewormersList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveDewormers"

            Else

                strSourceTable = "VInActiveDewormers"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intDewormerID", _
                                                        "strName", _
                                                        lstDewormers)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse Dewormer form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewDewormerInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddDewormer forms
            Dim frmAddDewormer As FAddDewormer

            ' Make an instance
            frmAddDewormer = New FAddDewormer

            ' Show modally
            frmAddDewormer.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddDewormer.GetResult() = True Then

                ' Get the new Dewormer values
                liNewDewormerInformation = frmAddDewormer.GetNewDewormerInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstDewormers.Items.Add(liNewDewormerInformation)

                ' ... which we can use to select it
                lstDewormers.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse Dewormer.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedDewormerID As Integer
            Dim liSelectedDewormer As CListItem
            Dim frmEditDewormer As FEditDewormer
            Dim liNewDewormerInformation As CListItem
            Dim intIndex As Integer

            ' Is a Dewormer selected?
            If lstDewormers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Dewormer to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the Dewormer to edit ID
                liSelectedDewormer = lstDewormers.SelectedItem
                intSelectedDewormerID = liSelectedDewormer.GetID

                ' Create instance
                frmEditDewormer = New FEditDewormer

                ' Set the form values
                frmEditDewormer.SetDewormerID(intSelectedDewormerID)

                ' Show it modally   
                frmEditDewormer.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditDewormer.GetResult() = True Then

                    ' Get the new Dewormer values
                    liNewDewormerInformation = frmEditDewormer.GetNewDewormerInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstDewormers.Items.RemoveAt(lstDewormers.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstDewormers.Items.Add(liNewDewormerInformation)

                    ' ... which we can use to select it
                    lstDewormers.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse Dewormer.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteDewormer()

            Else

                ' No, undelete
                UndeleteDewormer()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteDewormer
    ' Abstract: Delete the currently selected Dewormer.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteDewormer()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedDewormer As CListItem
            Dim intSelectedDewormerID As Integer
            Dim strSelectedDewormerName As String
            Dim intSelectedDewormerIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Dewormer selected?
            If lstDewormers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Dewormer to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Dewormer ID, name and list index
                liSelectedDewormer = lstDewormers.SelectedItem
                intSelectedDewormerID = liSelectedDewormer.GetID
                strSelectedDewormerName = liSelectedDewormer.GetName
                intSelectedDewormerIndex = lstDewormers.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Dewormer: " & strSelectedDewormerName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Dewormer (use ID for database command)
                    blnResult = DeleteDewormerFromDatabase(intSelectedDewormerID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Dewormer from the list
                        lstDewormers.Items.RemoveAt(intSelectedDewormerIndex)

                        ' Select the next Dewormer in the list
                        HighlightNextItemInList(lstDewormers, intSelectedDewormerIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteDewormer
    ' Abstract: Undelete the currently selected Dewormer.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteDewormer()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedDewormer As CListItem
            Dim intSelectedDewormerID As Integer
            Dim intSelectedDewormerIndex As Integer
            Dim blnResult As Boolean

            ' Is a Dewormer selected?
            If lstDewormers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Dewormer to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Dewormer ID and list index
                liSelectedDewormer = lstDewormers.SelectedItem
                intSelectedDewormerID = liSelectedDewormer.GetID
                intSelectedDewormerIndex = lstDewormers.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Dewormer (use ID for database command)
                blnResult = UndeleteDewormerFromDatabase(intSelectedDewormerID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Dewormer from the list
                    lstDewormers.Items.RemoveAt(intSelectedDewormerIndex)

                    ' Select the next Dewormer in the list
                    HighlightNextItemInList(lstDewormers, intSelectedDewormerIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Dewormers list
            LoadDewormersList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VDewormersTableAdapter.Fill(Me.CPDM_FoxLDewormersDS.VDewormers)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageDewormers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLDewormersDS.VDewormers' table.
    '    Me.VDewormersTableAdapter.Fill(Me.CPDM_FoxLDewormersDS.VDewormers)

    'End Sub

End Class