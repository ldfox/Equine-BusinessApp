﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FAddMaintenance
' Abstract: Capstone Horse Project - Manage Maintenance (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions


Public Class FAddMaintenance


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intMaintenanceID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddMaintenance_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddMaintenance_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Maintenance to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Maintenance to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Maintenance Date
            If txtMaintenanceDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Maintenance Date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtMaintenanceDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtMaintenanceDate.Text) = False Then

                    strErrorMessage &= "-Maintenance Date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Maintenance Cost
            If txtMaintenanceCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtMaintenanceCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewMaintenance As New udtMaintenanceType

            ' Get values from form
            udtNewMaintenance = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddMaintenanceToDatabase2(udtNewMaintenance)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Maintenance ID that's currently in the suitcase
                f_intMaintenanceID = udtNewMaintenance.intMaintenanceID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtMaintenanceType

        Dim udtMaintenance As New udtMaintenanceType

        ' Try/Catch with WriteLog
        Try

            Dim strMaintenanceCost As String

            ' Load up with data from the form
            'Name 
            udtMaintenance.strName = txtName.Text

            ' Maintenance Date
            ' Boundary check - if textbox is empty
            If txtMaintenanceDate.Text = "" Then

                ' Then insert date
                udtMaintenance.dteMaintenanceDate = "1800/01/01"

            Else

                ' Else txtDateShod has a value
                udtMaintenance.dteMaintenanceDate = txtMaintenanceDate.Text

            End If

            ' Maintenance Cost - Remove dollar signs and commas
            strMaintenanceCost = txtMaintenanceCost.Text
            strMaintenanceCost = strMaintenanceCost.Replace("$", "")
            strMaintenanceCost = strMaintenanceCost.Replace(",", "")
            udtMaintenance.decMaintenanceCost = Val(strMaintenanceCost)

            ' Comments
            udtMaintenance.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtMaintenance

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewMaintenanceInformation
    ' Abstract: Get the new Maintenance information
    ' --------------------------------------------------------------------------------
    Public Function GetNewMaintenanceInformation() As CListItem

        Dim liMaintenance As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liMaintenance = New CListItem(f_intMaintenanceID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liMaintenance

    End Function

End Class