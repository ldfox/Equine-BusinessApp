﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Horse Vaccinations
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignHorseVaccinations



    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignHorseVaccinations_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignHorseVaccinations_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveHorses", "intHorseID", "strName", cmbHorses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseVaccinations
    ' Abstract: Load the selected and available Vaccination lists for the current Horse.
    ' --------------------------------------------------------------------------------
    Private Sub LoadHorseVaccinations()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorse As CListItem
            Dim intHorseID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Horse selected
            If cmbHorses.SelectedIndex >= 0 Then

                ' Get the selected Horse ID
                liSelectedHorse = cmbHorses.SelectedItem
                intHorseID = liSelectedHorse.GetID

                ' Selected Vaccinations
                ModDatabaseUtilities.LoadListWithVaccinationsFromDatabase2(intHorseID, lstSelectedVaccinations, True)

                ' Available Vaccinations
                ModDatabaseUtilities.LoadListWithVaccinationsFromDatabase2(intHorseID, lstAvailableVaccinations, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableVaccinations.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableVaccinations.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedVaccinations.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedVaccinations.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all Vaccinations to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intIndex As Integer

            ' Is a Vaccination selected?
            If lstAvailableVaccinations.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Vaccination IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableVaccinations.SelectedItem


                ' Add the Vaccinations from lstAvailableVaccinations 
                'If AddAllAvailableVaccinationsFromDatabaseMSAccess(intHorseID) = True Then
                If AddAllAvailableVaccinationsToHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableVaccinations.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedVaccinations from lstAvailableVaccinations
                        lstSelectedVaccinations.Items.Add(lstAvailableVaccinations.Items(0))

                        ' Remove from lstAvailableVaccinations
                        lstAvailableVaccinations.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedVaccinations then ...
                    If lstSelectedVaccinations.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedVaccinations.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Vaccination to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intVaccinationID As Integer
            Dim intIndex As Integer

            ' Is a Vaccination selected?
            If lstAvailableVaccinations.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Vaccination IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableVaccinations.SelectedItem
                intVaccinationID = liSelectedItem.GetID

                ' Add the Vaccination
                'If AddVaccinationToHorseInDatabaseMSAccess(intHorseID, intVaccinationID) = True Then
                If AddVaccinationToHorseInDatabase2(intHorseID, intVaccinationID) = True Then

                    ' Add to selected Vaccinations
                    intIndex = lstSelectedVaccinations.Items.Add(lstAvailableVaccinations.SelectedItem)
                    lstSelectedVaccinations.SelectedIndex = intIndex

                    ' Remove from available Vaccinations
                    intIndex = lstAvailableVaccinations.SelectedIndex
                    lstAvailableVaccinations.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableVaccinations, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected Vaccination from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intVaccinationID As Integer
            Dim intIndex As Integer

            If lstSelectedVaccinations.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Vaccination IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedVaccinations.SelectedItem
                intVaccinationID = liSelectedItem.GetID

                ' Remove the Vaccination
                'If RemoveVaccinationFromHorseInDatabaseMSAccess(intHorseID, intVaccinationID) = True Then
                If RemoveVaccinationFromHorseInDatabase2(intHorseID, intVaccinationID) = True Then

                    ' Add to available Vaccinations
                    intIndex = lstAvailableVaccinations.Items.Add(lstSelectedVaccinations.SelectedItem)
                    lstAvailableVaccinations.SelectedIndex = intIndex

                    ' Remove from selected Vaccinations
                    intIndex = lstSelectedVaccinations.SelectedIndex
                    lstSelectedVaccinations.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedVaccinations, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the Vaccinations from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intVaccinationID As Integer
            Dim intIndex As Integer

            If lstSelectedVaccinations.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Vaccination IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedVaccinations.SelectedItem
                intVaccinationID = liSelectedItem.GetID

                ' Remove the Vaccination
                'If RemoveAllVaccinationsFromHorseInDatabaseMSAccess(intHorseID) = True Then
                If RemoveAllSelectedVaccinationsFromHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedVaccinations.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableVaccinations from lstSelectedVaccinations
                        lstAvailableVaccinations.Items.Add(lstSelectedVaccinations.Items(0))

                        ' Remove from lstSelectedVaccinations
                        lstSelectedVaccinations.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedVaccinations then ...
                    If lstAvailableVaccinations.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableVaccinations.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbHorses_SelectedIndexChanged
    ' Abstract: Load the selected and available Vaccination lists for the current Horse.
    ' -------------------------------------------------------------------------
    Private Sub cmbHorses_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbHorses.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadHorseVaccinations()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class