﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FAddEquipment
' Abstract: Capstone Horse Project - Manage Equipment (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddEquipment


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intEquipmentID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddEquipment_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddEquipment_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Equipment to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Equipment to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Purchase Date
            If txtPurchaseDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Purchase Date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtPurchaseDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtPurchaseDate.Text) = False Then

                    strErrorMessage &= "-Purchase Date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Cost
            If txtCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewEquipment As New udtEquipmentType

            ' Get values from form
            udtNewEquipment = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddEquipmentToDatabase2(udtNewEquipment)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Equipment ID that's currently in the suitcase
                f_intEquipmentID = udtNewEquipment.intEquipmentID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtEquipmentType

        Dim udtEquipment As New udtEquipmentType

        ' Try/Catch with WriteLog
        Try

            Dim strEquipmentCost As String

            ' Load up with data from the form
            'Name 
            udtEquipment.strName = txtName.Text

            ' Purchase Date
            ' Boundary check - if textbox is empty
            If txtPurchaseDate.Text = "" Then

                ' Then insert date
                udtEquipment.dtePurchaseDate = "1800/01/01"

            Else

                ' Else txtDateShod has a value
                udtEquipment.dtePurchaseDate = txtPurchaseDate.Text

            End If

            ' Cost - Remove dollar signs and commas
            strEquipmentCost = txtCost.Text
            strEquipmentCost = strEquipmentCost.Replace("$", "")
            strEquipmentCost = strEquipmentCost.Replace(",", "")
            udtEquipment.decCost = Val(strEquipmentCost)

            ' Comments
            udtEquipment.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtEquipment

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewEquipmentInformation
    ' Abstract: Get the new Equipment information
    ' --------------------------------------------------------------------------------
    Public Function GetNewEquipmentInformation() As CListItem

        Dim liEquipment As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liEquipment = New CListItem(f_intEquipmentID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liEquipment

    End Function

End Class