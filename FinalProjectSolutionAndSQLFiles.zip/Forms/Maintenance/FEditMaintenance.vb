﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditMaintenance
' Abstract: Capstone Horse project - Edit Maintenance (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditMaintenance


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intMaintenanceID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetMaintenanceID
    ' Abstract: What Maintenance are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetMaintenanceID(ByVal intMaintenanceID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' Maintenance ID
            f_intMaintenanceID = intMaintenanceID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditMaintenance_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditMaintenance_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtMaintenance As udtMaintenanceType

            ' Make a suitcase instace
            udtMaintenance = New udtMaintenanceType

            ' Set the ID
            udtMaintenance.intMaintenanceID = f_intMaintenanceID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetMaintenanceInformationFromDatabase(udtMaintenance) = True Then

                With udtMaintenance

                    ' Name
                    txtName.Text = .strName

                    ' Maintenance Date
                    If .dteMaintenanceDate <> "1800/01/01" Then

                        txtMaintenanceDate.Text = .dteMaintenanceDate.ToString("yyyy/MM/dd")

                    End If

                    ' Maintenance Cost
                    txtMaintenanceCost.Text = .decMaintenanceCost.ToString("c")
                    txtMaintenanceCost.Text = .decMaintenanceCost.ToString("c2")  ' Currency with 2 decimal points
                    txtMaintenanceCost.Text = FormatCurrency(.decMaintenanceCost)

                    ' Comments
                    txtComments.Text = .strComments

                End With
            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for Maintenance to edit." & vbNewLine & _
                                "The form will now close.", "Edit Maintenance Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Maintenance to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Maintenance to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Maintenance Date
            If txtMaintenanceDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Maintenance Date date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtMaintenanceDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtMaintenanceDate.Text) = False Then

                    strErrorMessage &= "-Maintenance Date date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Maintenance Cost
            If txtMaintenanceCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtMaintenanceCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtMaintenance As New udtMaintenanceType

            ' Load it up with data from the form
            udtMaintenance = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditMaintenanceInDatabase2(udtMaintenance)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtMaintenanceType

        Dim udtMaintenance As New udtMaintenanceType

        ' Try/Catch with WriteLog
        Try

            Dim strMaintenanceCost As String

            ' Load up with data from the form
            ' ID
            udtMaintenance.intMaintenanceID = f_intMaintenanceID

            'Name 
            udtMaintenance.strName = txtName.Text

            ' Maintenance Date
            ' Boundary check - if textbox is empty
            If txtMaintenanceDate.Text = "" Then

                ' Then insert date
                udtMaintenance.dteMaintenanceDate = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtMaintenance.dteMaintenanceDate = txtMaintenanceDate.Text

            End If

            ' Maintenance Cost - Remove dollar signs and commas
            strMaintenanceCost = txtMaintenanceCost.Text
            strMaintenanceCost = strMaintenanceCost.Replace("$", "")
            strMaintenanceCost = strMaintenanceCost.Replace(",", "")
            udtMaintenance.decMaintenanceCost = Val(strMaintenanceCost)

            ' Comments
            udtMaintenance.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtMaintenance

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewMaintenanceInformation
    ' Abstract: Get the new Maintenance information
    ' --------------------------------------------------------------------------------
    Public Function GetNewMaintenanceInformation() As CListItem

        Dim liMaintenance As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liMaintenance = New CListItem(f_intMaintenanceID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liMaintenance

    End Function

End Class