﻿' Name: FAddHorseSeller
' Abstract: Capstone Horse Project - Manage Horse Seller (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddHorseSeller


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHorseSellerID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddHorseSeller_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddHorseSeller_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("TStates", "intStateID", "strState", cmbState)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Horse Sellerto the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Horse Seller to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Full Name
            If txtFullName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Zip Code
            If txtZipCode.Text <> "" Then

                ' Is valid format?
                If IsValidZipCode(txtZipCode.Text) = False Then

                    strErrorMessage &= "-Zip Code is an invalid format" & vbNewLine
                    blnIsValidData = False

                End If

            End If

            ' Selling Price
            If txtSellingPrice.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtSellingPrice.Text) = False Then

                    strErrorMessage &= "-Selling Price is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Date Sold
            If txtDateSold.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDateSold.Text) = False Then

                    strErrorMessage &= "-Date Sold is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewHorseSeller As New udtHorseSellerType

            ' Get values from form
            udtNewHorseSeller = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddHorseSellerToDatabase2(udtNewHorseSeller)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Horse Seller ID that's currently in the suitcase
                f_intHorseSellerID = udtNewHorseSeller.intHorseSellerID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHorseSellerType

        Dim udtHorseSeller As New udtHorseSellerType

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedStateID As Integer
            Dim liSelectedState As CListItem
            Dim strSellingPrice As String

            ' Load up with data from the form

            'Name 
            udtHorseSeller.strFullName = txtFullName.Text

            ' Address
            udtHorseSeller.strAddress = txtAddress.Text

            ' City
            udtHorseSeller.strCity = txtCity.Text

            ' State
            liSelectedState = cmbState.SelectedItem
            intSelectedStateID = liSelectedState.GetID
            udtHorseSeller.intStateID = intSelectedStateID

            ' Zip Code
            udtHorseSeller.strZipCode = txtZipCode.Text

            ' Selling Price
            strSellingPrice = txtSellingPrice.Text
            strSellingPrice = strSellingPrice.Replace("$", "")
            strSellingPrice = strSellingPrice.Replace(",", "")
            udtHorseSeller.decSellingPrice = Val(strSellingPrice)

            ' Date Sold
            ' Boundary check - if textbox is empty
            If txtDateSold.Text = "" Then

                ' Then insert date
                udtHorseSeller.dteDateSold = "1800/01/01"

            Else

                ' Else txtDateSold has a value
                udtHorseSeller.dteDateSold = txtDateSold.Text

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHorseSeller

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHorseSellerInformation
    ' Abstract: Get the new Horse Seller information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHorseSellerInformation() As CListItem

        Dim liHorseSeller As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strFullName As String

            ' Full Name
            strFullName = txtFullName.Text

            'Make an instance of CListItem
            liHorseSeller = New CListItem(f_intHorseSellerID, strFullName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHorseSeller

    End Function

End Class