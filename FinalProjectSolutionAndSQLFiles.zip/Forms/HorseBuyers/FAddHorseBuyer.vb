﻿' Name: FAddHorseBuyer
' Abstract: Capstone Horse Project - Manage Horse Buyer (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddHorseBuyer


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHorseBuyerID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddHorseBuyer_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddHorseBuyer_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            modDatabaseUtilities.LoadComboBoxFromDatabase("TStates", "intStateID", "strState", cmbState)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Horse to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Horse Buyer to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Full Name
            If txtFullName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Zip Code
            If txtZipCode.Text <> "" Then

                ' Is valid format?
                If IsValidZipCode(txtZipCode.Text) = False Then

                    strErrorMessage &= "-Zip Code is an invalid format" & vbNewLine
                    blnIsValidData = False

                End If

            End If

            ' Purchase Price
            If txtPurchasePrice.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtPurchasePrice.Text) = False Then

                    strErrorMessage &= "-Purchase Price is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Date Of Purchase
            If txtDatePurchased.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDatePurchased.Text) = False Then

                    strErrorMessage &= "-Date Purchased is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewHorseBuyer As New udtHorseBuyerType

            ' Get values from form
            udtNewHorseBuyer = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddHorseBuyerToDatabase2(udtNewHorseBuyer)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Horse Buyer ID that's currently in the suitcase
                f_intHorseBuyerID = udtNewHorseBuyer.intHorseBuyerID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHorseBuyerType

        Dim udtHorseBuyer As New udtHorseBuyerType

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedStateID As Integer
            Dim liSelectedState As CListItem
            Dim strPurchasePrice As String

            ' Load up with data from the form

            'Name 
            udtHorseBuyer.strFullName = txtFullName.Text

            ' Address
            udtHorseBuyer.strAddress = txtAddress.Text

            ' City
            udtHorseBuyer.strCity = txtCity.Text

            ' State
            liSelectedState = cmbState.SelectedItem
            intSelectedStateID = liSelectedState.GetID
            udtHorseBuyer.intStateID = intSelectedStateID

            ' Zip Code
            udtHorseBuyer.strZipCode = txtZipCode.Text

            ' Purchase Price
            strPurchasePrice = txtPurchasePrice.Text
            strPurchasePrice = strPurchasePrice.Replace("$", "")
            strPurchasePrice = strPurchasePrice.Replace(",", "")
            udtHorseBuyer.decPurchasePrice = Val(strPurchasePrice)

            ' Date Purchased
            ' Boundary check - if textbox is empty
            If txtDatePurchased.Text = "" Then

                ' Then insert date
                udtHorseBuyer.dteDatePurchased = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtHorseBuyer.dteDatePurchased = txtDatePurchased.Text

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHorseBuyer

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHorseBuyerInformation
    ' Abstract: Get the new Horse Buyer information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHorseBuyerInformation() As CListItem

        Dim liHorseBuyer As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strFullName As String

            ' Full Name
            strFullName = txtFullName.Text

            'Make an instance of CListItem
            liHorseBuyer = New CListItem(f_intHorseBuyerID, strFullName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHorseBuyer

    End Function

End Class