﻿' ------------------------------------------------------------------------------------
' Module: modConstants
' Abstract: Capstone Horse project - Constants - usually matched to PK value in the database.
' ------------------------------------------------------------------------------------

' ------------------------------------------------------------------------------------
' Options
' ------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Module modConstants

    Public Const intHORSEBUYER_STATUS_ACTIVE As Integer = 1
    Public Const intHORSEBUYER_STATUS_INACTIVE As Integer = 2

    Public Const intHORSESELLER_STATUS_ACTIVE As Integer = 1
    Public Const intHORSESELLER_STATUS_INACTIVE As Integer = 2

    Public Const intHORSE_STATUS_ACTIVE As Integer = 1
    Public Const intHORSE_STATUS_INACTIVE As Integer = 2

    Public Const intSHOE_STATUS_ACTIVE As Integer = 1
    Public Const intSHOE_STATUS_INACTIVE As Integer = 2

    Public Const intVACCINATION_STATUS_ACTIVE As Integer = 1
    Public Const intVACCINATION_STATUS_INACTIVE As Integer = 2

    Public Const intWESTNILETEST_STATUS_ACTIVE As Integer = 1
    Public Const intWESTNILETEST_STATUS_INACTIVE As Integer = 2

    Public Const intDEWORMER_STATUS_ACTIVE As Integer = 1
    Public Const intDEWORMER_STATUS_INACTIVE As Integer = 2

    Public Const intHEALTHCERTIFICATE_STATUS_ACTIVE As Integer = 1
    Public Const intHEALTHCERTIFICATE_STATUS_INACTIVE As Integer = 2

    Public Const intFEEDMISCEXPENSE_STATUS_ACTIVE As Integer = 1
    Public Const intFEEDMISCEXPENSE_STATUS_INACTIVE As Integer = 2

    Public Const intEQUIPMENT_STATUS_ACTIVE As Integer = 1
    Public Const intEQUIPMENT_STATUS_INACTIVE As Integer = 2

    Public Const intMAINTENANCE_STATUS_ACTIVE As Integer = 1
    Public Const intMAINTENANCE_STATUS_INACTIVE As Integer = 2

End Module
