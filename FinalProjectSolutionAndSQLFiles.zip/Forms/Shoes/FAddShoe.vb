﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FAddShoe
' Abstract: Capstone Horse Project - Manage Shoe (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddShoe


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intShoeID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddShoe_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddShoe_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Shoe to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Shoe to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Date Shod
            If txtDateShod.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Date Shod can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtDateShod.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDateShod.Text) = False Then

                    strErrorMessage &= "-Date Shod is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Trim Angle
            If txtTrimAngle.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Trim Angle can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Farrier Cost
            If txtFarrierCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtFarrierCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewShoe As New udtShoeType

            ' Get values from form
            udtNewShoe = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddShoeToDatabase2(udtNewShoe)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Shoe ID that's currently in the suitcase
                f_intShoeID = udtNewShoe.intShoeID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtShoeType

        Dim udtShoe As New udtShoeType

        ' Try/Catch with WriteLog
        Try

            Dim strFarrierCost As String

            ' Load up with data from the form
            'Name 
            udtShoe.strName = txtName.Text

            ' Date Shod
            ' Boundary check - if textbox is empty
            If txtDateShod.Text = "" Then

                ' Then insert date
                udtShoe.dteShod = "1800/01/01"

            Else

                ' Else txtDateShod has a value
                udtShoe.dteShod = txtDateShod.Text

            End If

            ' Trim Angle
            udtShoe.strTrimAngle = txtTrimAngle.Text

            ' Farrier Cost - Remove dollar signs and commas
            strFarrierCost = txtFarrierCost.Text
            strFarrierCost = strFarrierCost.Replace("$", "")
            strFarrierCost = strFarrierCost.Replace(",", "")
            udtShoe.decFarrierCost = Val(strFarrierCost)

            ' Comments
            udtShoe.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtShoe

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewShoeInformation
    ' Abstract: Get the new Shoe information
    ' --------------------------------------------------------------------------------
    Public Function GetNewShoeInformation() As CListItem

        Dim liShoe As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liShoe = New CListItem(f_intShoeID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liShoe

    End Function

End Class