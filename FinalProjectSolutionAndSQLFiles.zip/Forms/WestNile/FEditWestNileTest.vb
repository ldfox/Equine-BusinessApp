﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditWestNileTest
' Abstract: Capstone Horse project - Edit horse WestNileTests (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditWestNileTest


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intWestNileTestID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetWestNileTestID
    ' Abstract: What WestNileTest are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetWestNileTestID(ByVal intWestNileTestID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' WestNileTest ID
            f_intWestNileTestID = intWestNileTestID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditWestNileTest_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditWestNileTest_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtWestNileTest As udtWestNileTestType

            ' Make a suitcase instace
            udtWestNileTest = New udtWestNileTestType

            ' Set the ID  *** Always set the ID ***
            udtWestNileTest.intWestNileTestID = f_intWestNileTestID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetWestNileTestInformationFromDatabase(udtWestNileTest) = True Then

                With udtWestNileTest

                    ' Name
                    txtName.Text = .strName

                    ' WestNile Test Date
                    If .dteWestNileTestDate <> "1800/01/01" Then

                        txtWestNileTestDate.Text = .dteWestNileTestDate.ToString("yyyy/MM/dd")

                    End If

                    ' WestNile Test Cost
                    txtWestNileTestCost.Text = .decWestNileTestCost.ToString("c")
                    txtWestNileTestCost.Text = .decWestNileTestCost.ToString("c2")  ' Currency with 2 decimal points
                    txtWestNileTestCost.Text = FormatCurrency(.decWestNileTestCost)

                    ' Comments
                    txtComments.Text = .strComments

                End With
            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for WestNileTest to edit." & vbNewLine & _
                                "The form will now close.", "Edit WestNileTest Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the WestNileTest to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add WestNileTest to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' WestNile Test Date
            If txtWestNileTestDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-WestNile test date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtWestNileTestDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtWestNileTestDate.Text) = False Then

                    strErrorMessage &= "-WestNile test date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtWestNileTest As New udtWestNileTestType

            ' Load it up with data from the form
            udtWestNileTest = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditWestNileTestInDatabase2(udtWestNileTest)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtWestNileTestType

        Dim udtWestNileTest As New udtWestNileTestType

        ' Try/Catch with WriteLog
        Try

            Dim strWestNileTestCost As String

            ' Load up with data from the form
            ' ID
            udtWestNileTest.intWestNileTestID = f_intWestNileTestID

            'Name 
            udtWestNileTest.strName = txtName.Text

            ' WestNile Test Date
            ' Boundary check - if textbox is empty
            If txtWestNileTestDate.Text = "" Then

                ' Then insert date
                udtWestNileTest.dteWestNileTestDate = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtWestNileTest.dteWestNileTestDate = txtWestNileTestDate.Text

            End If

            ' WestNile Test Cost - Remove dollar signs and commas
            strWestNileTestCost = txtWestNileTestCost.Text
            strWestNileTestCost = strWestNileTestCost.Replace("$", "")
            strWestNileTestCost = strWestNileTestCost.Replace(",", "")
            udtWestNileTest.decWestNileTestCost = Val(strWestNileTestCost)

            ' Comments
            udtWestNileTest.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtWestNileTest

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewWestNileTestInformation
    ' Abstract: Get the new WestNileTest information
    ' --------------------------------------------------------------------------------
    Public Function GetNewWestNileTestInformation() As CListItem

        Dim liWestNileTest As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liWestNileTest = New CListItem(f_intWestNileTestID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liWestNileTest

    End Function

End Class