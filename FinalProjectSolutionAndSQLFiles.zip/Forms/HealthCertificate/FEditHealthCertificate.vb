﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditHealthCertificate
' Abstract: Capstone Horse project - Edit horse HealthCertificates (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditHealthCertificate


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHealthCertificateID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetHealthCertificateID
    ' Abstract: What HealthCertificate are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetHealthCertificateID(ByVal intHealthCertificateID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' HealthCertificate ID
            f_intHealthCertificateID = intHealthCertificateID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditHealthCertificate_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditHealthCertificate_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtHealthCertificate As udtHealthCertificateType

            ' Make a suitcase instace
            udtHealthCertificate = New udtHealthCertificateType

            ' Set the ID  *** Always set the ID ***
            udtHealthCertificate.intHealthCertificateID = f_intHealthCertificateID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetHealthCertificateInformationFromDatabase(udtHealthCertificate) = True Then

                With udtHealthCertificate

                    ' Name
                    txtName.Text = .strName

                    ' Health Certificate Date
                    If .dteHealthCertificateDate <> "1800/01/01" Then

                        txtHealthCertificateDate.Text = .dteHealthCertificateDate.ToString("yyyy/MM/dd")

                    End If

                    ' Health Certificate Cost
                    txtHealthCertificateCost.Text = .decHealthCertificateCost.ToString("c")
                    txtHealthCertificateCost.Text = .decHealthCertificateCost.ToString("c2")  ' Currency with 2 decimal points
                    txtHealthCertificateCost.Text = FormatCurrency(.decHealthCertificateCost)

                    ' Comments
                    txtComments.Text = .strComments

                End With
            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for HealthCertificate to edit." & vbNewLine & _
                                "The form will now close.", "Edit HealthCertificate Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the HealthCertificate to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add HealthCertificate to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Health Certificate Date
            If txtHealthCertificateDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Health Certificate date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtHealthCertificateDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtHealthCertificateDate.Text) = False Then

                    strErrorMessage &= "-Health Certificate date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtHealthCertificate As New udtHealthCertificateType

            ' Load it up with data from the form
            udtHealthCertificate = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditHealthCertificateInDatabase2(udtHealthCertificate)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHealthCertificateType

        Dim udtHealthCertificate As New udtHealthCertificateType

        ' Try/Catch with WriteLog
        Try

            Dim strHealthCertificateCost As String

            ' Load up with data from the form
            ' ID
            udtHealthCertificate.intHealthCertificateID = f_intHealthCertificateID

            'Name 
            udtHealthCertificate.strName = txtName.Text

            ' WestNile Test Date
            ' Boundary check - if textbox is empty
            If txtHealthCertificateDate.Text = "" Then

                ' Then insert date
                udtHealthCertificate.dteHealthCertificateDate = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtHealthCertificate.dteHealthCertificateDate = txtHealthCertificateDate.Text

            End If

            ' Health Certificate Cost - Remove dollar signs and commas
            strHealthCertificateCost = txtHealthCertificateCost.Text
            strHealthCertificateCost = strHealthCertificateCost.Replace("$", "")
            strHealthCertificateCost = strHealthCertificateCost.Replace(",", "")
            udtHealthCertificate.decHealthCertificateCost = Val(strHealthCertificateCost)

            ' Comments
            udtHealthCertificate.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHealthCertificate

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHealthCertificateInformation
    ' Abstract: Get the new HealthCertificate information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHealthCertificateInformation() As CListItem

        Dim liHealthCertificate As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liHealthCertificate = New CListItem(f_intHealthCertificateID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHealthCertificate

    End Function

End Class