﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Horse Dewormers
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignHorseDewormers



    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignHorseDewormers_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignHorseDewormers_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveHorses", "intHorseID", "strName", cmbHorses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseDewormers
    ' Abstract: Load the selected and available Dewormer lists for the current Horse.
    ' --------------------------------------------------------------------------------
    Private Sub LoadHorseDewormers()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorse As CListItem
            Dim intHorseID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Horse selected
            If cmbHorses.SelectedIndex >= 0 Then

                ' Get the selected Horse ID
                liSelectedHorse = cmbHorses.SelectedItem
                intHorseID = liSelectedHorse.GetID

                ' Selected Dewormers
                ModDatabaseUtilities.LoadListWithDewormersFromDatabase2(intHorseID, lstSelectedDewormers, True)

                ' Available Dewormers
                ModDatabaseUtilities.LoadListWithDewormersFromDatabase2(intHorseID, lstAvailableDewormers, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableDewormers.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableDewormers.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedDewormers.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedDewormers.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all Dewormers to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intIndex As Integer

            ' Is a Dewormer selected?
            If lstAvailableDewormers.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Dewormer IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableDewormers.SelectedItem


                ' Add the Dewormers from lstAvailableDewormers 
                'If AddAllAvailableDewormersFromDatabaseMSAccess(intHorseID) = True Then
                If AddAllAvailableDewormersToHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableDewormers.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedDewormers from lstAvailableDewormers
                        lstSelectedDewormers.Items.Add(lstAvailableDewormers.Items(0))

                        ' Remove from lstAvailableDewormers
                        lstAvailableDewormers.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedDewormers then ...
                    If lstSelectedDewormers.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedDewormers.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Dewormer to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intDewormerID As Integer
            Dim intIndex As Integer

            ' Is a Dewormer selected?
            If lstAvailableDewormers.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Dewormer IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableDewormers.SelectedItem
                intDewormerID = liSelectedItem.GetID

                ' Add the Dewormer
                'If AddDewormerToHorseInDatabaseMSAccess(intHorseID, intDewormerID) = True Then
                If AddDewormerToHorseInDatabase2(intHorseID, intDewormerID) = True Then

                    ' Add to selected Dewormers
                    intIndex = lstSelectedDewormers.Items.Add(lstAvailableDewormers.SelectedItem)
                    lstSelectedDewormers.SelectedIndex = intIndex

                    ' Remove from available Dewormers
                    intIndex = lstAvailableDewormers.SelectedIndex
                    lstAvailableDewormers.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableDewormers, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected Dewormer from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intDewormerID As Integer
            Dim intIndex As Integer

            If lstSelectedDewormers.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Dewormer IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedDewormers.SelectedItem
                intDewormerID = liSelectedItem.GetID

                ' Remove the Dewormer
                'If RemoveDewormerFromHorseInDatabaseMSAccess(intHorseID, intDewormerID) = True Then
                If RemoveDewormerFromHorseInDatabase2(intHorseID, intDewormerID) = True Then

                    ' Add to available Dewormers
                    intIndex = lstAvailableDewormers.Items.Add(lstSelectedDewormers.SelectedItem)
                    lstAvailableDewormers.SelectedIndex = intIndex

                    ' Remove from selected Dewormers
                    intIndex = lstSelectedDewormers.SelectedIndex
                    lstSelectedDewormers.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedDewormers, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the Dewormers from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intDewormerID As Integer
            Dim intIndex As Integer

            If lstSelectedDewormers.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and Dewormer IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedDewormers.SelectedItem
                intDewormerID = liSelectedItem.GetID

                ' Remove the Dewormer
                'If RemoveAllDewormersFromHorseInDatabaseMSAccess(intHorseID) = True Then
                If RemoveAllSelectedDewormersFromHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedDewormers.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableDewormers from lstSelectedDewormers
                        lstAvailableDewormers.Items.Add(lstSelectedDewormers.Items(0))

                        ' Remove from lstSelectedDewormers
                        lstSelectedDewormers.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedDewormers then ...
                    If lstAvailableDewormers.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableDewormers.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbHorses_SelectedIndexChanged
    ' Abstract: Load the selected and available Dewormer lists for the current Horse.
    ' -------------------------------------------------------------------------
    Private Sub cmbHorses_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbHorses.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadHorseDewormers()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class