﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAddHorse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblBreed = New System.Windows.Forms.Label()
        Me.lblRegistered = New System.Windows.Forms.Label()
        Me.lblColor = New System.Windows.Forms.Label()
        Me.lblSex = New System.Windows.Forms.Label()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.lblBuyer = New System.Windows.Forms.Label()
        Me.lblSeller = New System.Windows.Forms.Label()
        Me.lblComments = New System.Windows.Forms.Label()
        Me.cmbBreed = New System.Windows.Forms.ComboBox()
        Me.cmbColor = New System.Windows.Forms.ComboBox()
        Me.cmbSex = New System.Windows.Forms.ComboBox()
        Me.cmbBuyer = New System.Windows.Forms.ComboBox()
        Me.cmbSeller = New System.Windows.Forms.ComboBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtHeight = New System.Windows.Forms.TextBox()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblRequired = New System.Windows.Forms.Label()
        Me.cmbRegistration = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(27, 24)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(73, 24)
        Me.lblName.TabIndex = 20
        Me.lblName.Text = "Name:*"
        '
        'lblBreed
        '
        Me.lblBreed.AutoSize = True
        Me.lblBreed.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBreed.Location = New System.Drawing.Point(27, 62)
        Me.lblBreed.Name = "lblBreed"
        Me.lblBreed.Size = New System.Drawing.Size(66, 24)
        Me.lblBreed.TabIndex = 19
        Me.lblBreed.Text = "Breed:"
        '
        'lblRegistered
        '
        Me.lblRegistered.AutoSize = True
        Me.lblRegistered.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRegistered.Location = New System.Drawing.Point(27, 100)
        Me.lblRegistered.Name = "lblRegistered"
        Me.lblRegistered.Size = New System.Drawing.Size(106, 24)
        Me.lblRegistered.TabIndex = 18
        Me.lblRegistered.Text = "Registered:"
        '
        'lblColor
        '
        Me.lblColor.AutoSize = True
        Me.lblColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblColor.Location = New System.Drawing.Point(27, 138)
        Me.lblColor.Name = "lblColor"
        Me.lblColor.Size = New System.Drawing.Size(60, 24)
        Me.lblColor.TabIndex = 17
        Me.lblColor.Text = "Color:"
        '
        'lblSex
        '
        Me.lblSex.AutoSize = True
        Me.lblSex.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSex.Location = New System.Drawing.Point(27, 176)
        Me.lblSex.Name = "lblSex"
        Me.lblSex.Size = New System.Drawing.Size(48, 24)
        Me.lblSex.TabIndex = 16
        Me.lblSex.Text = "Sex:"
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeight.Location = New System.Drawing.Point(27, 214)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(70, 24)
        Me.lblHeight.TabIndex = 15
        Me.lblHeight.Text = "Height:"
        '
        'lblBuyer
        '
        Me.lblBuyer.AutoSize = True
        Me.lblBuyer.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBuyer.Location = New System.Drawing.Point(27, 252)
        Me.lblBuyer.Name = "lblBuyer"
        Me.lblBuyer.Size = New System.Drawing.Size(64, 24)
        Me.lblBuyer.TabIndex = 14
        Me.lblBuyer.Text = "Buyer:"
        '
        'lblSeller
        '
        Me.lblSeller.AutoSize = True
        Me.lblSeller.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeller.Location = New System.Drawing.Point(27, 290)
        Me.lblSeller.Name = "lblSeller"
        Me.lblSeller.Size = New System.Drawing.Size(63, 24)
        Me.lblSeller.TabIndex = 13
        Me.lblSeller.Text = "Seller:"
        '
        'lblComments
        '
        Me.lblComments.AutoSize = True
        Me.lblComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComments.Location = New System.Drawing.Point(27, 328)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(106, 24)
        Me.lblComments.TabIndex = 12
        Me.lblComments.Text = "Comments:"
        '
        'cmbBreed
        '
        Me.cmbBreed.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbBreed.FormattingEnabled = True
        Me.cmbBreed.Location = New System.Drawing.Point(179, 60)
        Me.cmbBreed.Name = "cmbBreed"
        Me.cmbBreed.Size = New System.Drawing.Size(261, 30)
        Me.cmbBreed.TabIndex = 1
        '
        'cmbColor
        '
        Me.cmbColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbColor.FormattingEnabled = True
        Me.cmbColor.Location = New System.Drawing.Point(179, 136)
        Me.cmbColor.Name = "cmbColor"
        Me.cmbColor.Size = New System.Drawing.Size(261, 30)
        Me.cmbColor.TabIndex = 3
        '
        'cmbSex
        '
        Me.cmbSex.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSex.FormattingEnabled = True
        Me.cmbSex.Location = New System.Drawing.Point(179, 174)
        Me.cmbSex.Name = "cmbSex"
        Me.cmbSex.Size = New System.Drawing.Size(261, 30)
        Me.cmbSex.TabIndex = 4
        '
        'cmbBuyer
        '
        Me.cmbBuyer.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbBuyer.FormattingEnabled = True
        Me.cmbBuyer.Location = New System.Drawing.Point(179, 248)
        Me.cmbBuyer.Name = "cmbBuyer"
        Me.cmbBuyer.Size = New System.Drawing.Size(261, 30)
        Me.cmbBuyer.TabIndex = 6
        '
        'cmbSeller
        '
        Me.cmbSeller.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSeller.FormattingEnabled = True
        Me.cmbSeller.Location = New System.Drawing.Point(179, 286)
        Me.cmbSeller.Name = "cmbSeller"
        Me.cmbSeller.Size = New System.Drawing.Size(261, 30)
        Me.cmbSeller.TabIndex = 7
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(179, 24)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(261, 28)
        Me.txtName.TabIndex = 0
        '
        'txtHeight
        '
        Me.txtHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHeight.Location = New System.Drawing.Point(179, 212)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(261, 28)
        Me.txtHeight.TabIndex = 5
        '
        'txtComments
        '
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(179, 324)
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(261, 28)
        Me.txtComments.TabIndex = 8
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(51, 401)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(145, 35)
        Me.btnOK.TabIndex = 9
        Me.btnOK.Text = "&OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(268, 401)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(145, 35)
        Me.btnCancel.TabIndex = 10
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'lblRequired
        '
        Me.lblRequired.AutoSize = True
        Me.lblRequired.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequired.Location = New System.Drawing.Point(176, 355)
        Me.lblRequired.Name = "lblRequired"
        Me.lblRequired.Size = New System.Drawing.Size(117, 18)
        Me.lblRequired.TabIndex = 11
        Me.lblRequired.Text = "*=Required Field"
        '
        'cmbRegistration
        '
        Me.cmbRegistration.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbRegistration.FormattingEnabled = True
        Me.cmbRegistration.Items.AddRange(New Object() {"Yes", "No"})
        Me.cmbRegistration.Location = New System.Drawing.Point(179, 98)
        Me.cmbRegistration.Name = "cmbRegistration"
        Me.cmbRegistration.Size = New System.Drawing.Size(261, 30)
        Me.cmbRegistration.TabIndex = 2
        '
        'FAddHorse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(466, 460)
        Me.Controls.Add(Me.cmbRegistration)
        Me.Controls.Add(Me.lblRequired)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.txtHeight)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.cmbSeller)
        Me.Controls.Add(Me.cmbBuyer)
        Me.Controls.Add(Me.cmbSex)
        Me.Controls.Add(Me.cmbColor)
        Me.Controls.Add(Me.cmbBreed)
        Me.Controls.Add(Me.lblComments)
        Me.Controls.Add(Me.lblSeller)
        Me.Controls.Add(Me.lblBuyer)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.lblSex)
        Me.Controls.Add(Me.lblColor)
        Me.Controls.Add(Me.lblRegistered)
        Me.Controls.Add(Me.lblBreed)
        Me.Controls.Add(Me.lblName)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAddHorse"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add Horse"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblBreed As System.Windows.Forms.Label
    Friend WithEvents lblRegistered As System.Windows.Forms.Label
    Friend WithEvents lblColor As System.Windows.Forms.Label
    Friend WithEvents lblSex As System.Windows.Forms.Label
    Friend WithEvents lblHeight As System.Windows.Forms.Label
    Friend WithEvents lblBuyer As System.Windows.Forms.Label
    Friend WithEvents lblSeller As System.Windows.Forms.Label
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents cmbBreed As System.Windows.Forms.ComboBox
    Friend WithEvents cmbColor As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSex As System.Windows.Forms.ComboBox
    Friend WithEvents cmbBuyer As System.Windows.Forms.ComboBox
    Friend WithEvents cmbSeller As System.Windows.Forms.ComboBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtHeight As System.Windows.Forms.TextBox
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents lblRequired As System.Windows.Forms.Label
    Friend WithEvents cmbRegistration As System.Windows.Forms.ComboBox
End Class
