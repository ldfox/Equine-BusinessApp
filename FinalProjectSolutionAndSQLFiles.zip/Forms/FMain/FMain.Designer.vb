﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageHorses = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageBuyers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageSellers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageShoes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignHorseShoes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageVaccinations = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignHorseVaccinations = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageWestNileTests = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignWestNileTests = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageDewormers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignHorseDewormers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageHealthCertificates = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignHorseHealthCertificates = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageFeedMiscExpenses = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageEquipment = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuManageMaintenance = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAssignEquipmentMaintenance = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.grpManageAssignHorses = New System.Windows.Forms.GroupBox()
        Me.btnManageSellers = New System.Windows.Forms.Button()
        Me.btnManageBuyers = New System.Windows.Forms.Button()
        Me.btnManageHorses = New System.Windows.Forms.Button()
        Me.grpManageAssignHorseShoes = New System.Windows.Forms.GroupBox()
        Me.btnAssignHorseShoes = New System.Windows.Forms.Button()
        Me.btnManageShoes = New System.Windows.Forms.Button()
        Me.grpManageAssignHorseVaccinations = New System.Windows.Forms.GroupBox()
        Me.btnAssignHorseVaccinations = New System.Windows.Forms.Button()
        Me.btnManageVaccinations = New System.Windows.Forms.Button()
        Me.grpManageAssignHorseWestNileTests = New System.Windows.Forms.GroupBox()
        Me.btnAssignHorseWestNileTests = New System.Windows.Forms.Button()
        Me.btnManageWestNileTests = New System.Windows.Forms.Button()
        Me.grpManageAssignHorseDewormers = New System.Windows.Forms.GroupBox()
        Me.btnAssignHorseDewormers = New System.Windows.Forms.Button()
        Me.btnManageDewormers = New System.Windows.Forms.Button()
        Me.grpManageAssignHorseHealthCertificates = New System.Windows.Forms.GroupBox()
        Me.btnAssignHorseHealthCertificates = New System.Windows.Forms.Button()
        Me.btnManageHealthCertificates = New System.Windows.Forms.Button()
        Me.grpManageAssignEquipmentMaintenance = New System.Windows.Forms.GroupBox()
        Me.btnAssignEquipmentMaintenance = New System.Windows.Forms.Button()
        Me.btnManageMaintenance = New System.Windows.Forms.Button()
        Me.btnManageEquipment = New System.Windows.Forms.Button()
        Me.grpManageFeedMiscExpenses = New System.Windows.Forms.GroupBox()
        Me.btnManageFeedMiscExpenses = New System.Windows.Forms.Button()
        Me.btnCloseTheApplication = New System.Windows.Forms.Button()
        Me.lblFMainInformation = New System.Windows.Forms.Label()
        Me.MenuStrip2.SuspendLayout()
        Me.grpManageAssignHorses.SuspendLayout()
        Me.grpManageAssignHorseShoes.SuspendLayout()
        Me.grpManageAssignHorseVaccinations.SuspendLayout()
        Me.grpManageAssignHorseWestNileTests.SuspendLayout()
        Me.grpManageAssignHorseDewormers.SuspendLayout()
        Me.grpManageAssignHorseHealthCertificates.SuspendLayout()
        Me.grpManageAssignEquipmentMaintenance.SuspendLayout()
        Me.grpManageFeedMiscExpenses.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 28)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1228, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip2.Size = New System.Drawing.Size(1228, 28)
        Me.MenuStrip2.TabIndex = 0
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(44, 24)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(102, 24)
        Me.mnuExit.Text = "&Exit"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuManageHorses, Me.mnuManageBuyers, Me.mnuManageSellers, Me.mnuManageShoes, Me.mnuAssignHorseShoes, Me.mnuManageVaccinations, Me.mnuAssignHorseVaccinations, Me.mnuManageWestNileTests, Me.mnuAssignWestNileTests, Me.mnuManageDewormers, Me.mnuAssignHorseDewormers, Me.mnuManageHealthCertificates, Me.mnuAssignHorseHealthCertificates, Me.mnuManageFeedMiscExpenses, Me.mnuManageEquipment, Me.mnuManageMaintenance, Me.mnuAssignEquipmentMaintenance})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(57, 24)
        Me.ToolsToolStripMenuItem.Text = "&Tools"
        '
        'mnuManageHorses
        '
        Me.mnuManageHorses.Name = "mnuManageHorses"
        Me.mnuManageHorses.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageHorses.Text = "Manage Horses"
        '
        'mnuManageBuyers
        '
        Me.mnuManageBuyers.Name = "mnuManageBuyers"
        Me.mnuManageBuyers.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageBuyers.Text = "Manage Buyers"
        '
        'mnuManageSellers
        '
        Me.mnuManageSellers.Name = "mnuManageSellers"
        Me.mnuManageSellers.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageSellers.Text = "Manage Sellers"
        '
        'mnuManageShoes
        '
        Me.mnuManageShoes.Name = "mnuManageShoes"
        Me.mnuManageShoes.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageShoes.Text = "Manage Shoes"
        '
        'mnuAssignHorseShoes
        '
        Me.mnuAssignHorseShoes.Name = "mnuAssignHorseShoes"
        Me.mnuAssignHorseShoes.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignHorseShoes.Text = "Assign Horse Shoes"
        '
        'mnuManageVaccinations
        '
        Me.mnuManageVaccinations.Name = "mnuManageVaccinations"
        Me.mnuManageVaccinations.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageVaccinations.Text = "Manage Vaccinations"
        '
        'mnuAssignHorseVaccinations
        '
        Me.mnuAssignHorseVaccinations.Name = "mnuAssignHorseVaccinations"
        Me.mnuAssignHorseVaccinations.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignHorseVaccinations.Text = "Assign Horse Vaccinations"
        '
        'mnuManageWestNileTests
        '
        Me.mnuManageWestNileTests.Name = "mnuManageWestNileTests"
        Me.mnuManageWestNileTests.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageWestNileTests.Text = "Manage WestNile Tests"
        '
        'mnuAssignWestNileTests
        '
        Me.mnuAssignWestNileTests.Name = "mnuAssignWestNileTests"
        Me.mnuAssignWestNileTests.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignWestNileTests.Text = "Assign Horse WestNile Tests"
        '
        'mnuManageDewormers
        '
        Me.mnuManageDewormers.Name = "mnuManageDewormers"
        Me.mnuManageDewormers.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageDewormers.Text = "Manage Dewormers"
        '
        'mnuAssignHorseDewormers
        '
        Me.mnuAssignHorseDewormers.Name = "mnuAssignHorseDewormers"
        Me.mnuAssignHorseDewormers.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignHorseDewormers.Text = "Assign Horse Dewormers"
        '
        'mnuManageHealthCertificates
        '
        Me.mnuManageHealthCertificates.Name = "mnuManageHealthCertificates"
        Me.mnuManageHealthCertificates.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageHealthCertificates.Text = "Manage Health Certificates"
        '
        'mnuAssignHorseHealthCertificates
        '
        Me.mnuAssignHorseHealthCertificates.Name = "mnuAssignHorseHealthCertificates"
        Me.mnuAssignHorseHealthCertificates.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignHorseHealthCertificates.Text = "Assign Horse Health Certificates"
        '
        'mnuManageFeedMiscExpenses
        '
        Me.mnuManageFeedMiscExpenses.Name = "mnuManageFeedMiscExpenses"
        Me.mnuManageFeedMiscExpenses.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageFeedMiscExpenses.Text = "Manage Feed&&Misc Expenses"
        '
        'mnuManageEquipment
        '
        Me.mnuManageEquipment.Name = "mnuManageEquipment"
        Me.mnuManageEquipment.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageEquipment.Text = "Manage Equipment"
        '
        'mnuManageMaintenance
        '
        Me.mnuManageMaintenance.Name = "mnuManageMaintenance"
        Me.mnuManageMaintenance.Size = New System.Drawing.Size(290, 24)
        Me.mnuManageMaintenance.Text = "Manage Maintenance"
        '
        'mnuAssignEquipmentMaintenance
        '
        Me.mnuAssignEquipmentMaintenance.Name = "mnuAssignEquipmentMaintenance"
        Me.mnuAssignEquipmentMaintenance.Size = New System.Drawing.Size(290, 24)
        Me.mnuAssignEquipmentMaintenance.Text = "Assign Equipment Maintenance"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAbout})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(53, 24)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Size = New System.Drawing.Size(119, 24)
        Me.mnuAbout.Text = "About"
        '
        'grpManageAssignHorses
        '
        Me.grpManageAssignHorses.Controls.Add(Me.btnManageSellers)
        Me.grpManageAssignHorses.Controls.Add(Me.btnManageBuyers)
        Me.grpManageAssignHorses.Controls.Add(Me.btnManageHorses)
        Me.grpManageAssignHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpManageAssignHorses.Location = New System.Drawing.Point(21, 33)
        Me.grpManageAssignHorses.Name = "grpManageAssignHorses"
        Me.grpManageAssignHorses.Size = New System.Drawing.Size(382, 232)
        Me.grpManageAssignHorses.TabIndex = 1
        Me.grpManageAssignHorses.TabStop = False
        Me.grpManageAssignHorses.Text = "Manage/Assign Horses Buyers Sellers"
        '
        'btnManageSellers
        '
        Me.btnManageSellers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageSellers.Location = New System.Drawing.Point(19, 167)
        Me.btnManageSellers.Name = "btnManageSellers"
        Me.btnManageSellers.Size = New System.Drawing.Size(344, 40)
        Me.btnManageSellers.TabIndex = 2
        Me.btnManageSellers.Text = "Manage Sellers"
        Me.btnManageSellers.UseVisualStyleBackColor = True
        '
        'btnManageBuyers
        '
        Me.btnManageBuyers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageBuyers.Location = New System.Drawing.Point(19, 102)
        Me.btnManageBuyers.Name = "btnManageBuyers"
        Me.btnManageBuyers.Size = New System.Drawing.Size(344, 40)
        Me.btnManageBuyers.TabIndex = 1
        Me.btnManageBuyers.Text = "Manage Buyers"
        Me.btnManageBuyers.UseVisualStyleBackColor = True
        '
        'btnManageHorses
        '
        Me.btnManageHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageHorses.Location = New System.Drawing.Point(19, 35)
        Me.btnManageHorses.Name = "btnManageHorses"
        Me.btnManageHorses.Size = New System.Drawing.Size(344, 40)
        Me.btnManageHorses.TabIndex = 0
        Me.btnManageHorses.Text = "Manage Horses"
        Me.btnManageHorses.UseVisualStyleBackColor = True
        '
        'grpManageAssignHorseShoes
        '
        Me.grpManageAssignHorseShoes.Controls.Add(Me.btnAssignHorseShoes)
        Me.grpManageAssignHorseShoes.Controls.Add(Me.btnManageShoes)
        Me.grpManageAssignHorseShoes.Location = New System.Drawing.Point(420, 33)
        Me.grpManageAssignHorseShoes.Name = "grpManageAssignHorseShoes"
        Me.grpManageAssignHorseShoes.Size = New System.Drawing.Size(382, 169)
        Me.grpManageAssignHorseShoes.TabIndex = 2
        Me.grpManageAssignHorseShoes.TabStop = False
        Me.grpManageAssignHorseShoes.Text = "Manage/Assign Horse Shoes"
        '
        'btnAssignHorseShoes
        '
        Me.btnAssignHorseShoes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignHorseShoes.Location = New System.Drawing.Point(19, 102)
        Me.btnAssignHorseShoes.Name = "btnAssignHorseShoes"
        Me.btnAssignHorseShoes.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignHorseShoes.TabIndex = 2
        Me.btnAssignHorseShoes.Text = "Assign Horse Shoes"
        Me.btnAssignHorseShoes.UseVisualStyleBackColor = True
        '
        'btnManageShoes
        '
        Me.btnManageShoes.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageShoes.Location = New System.Drawing.Point(20, 35)
        Me.btnManageShoes.Name = "btnManageShoes"
        Me.btnManageShoes.Size = New System.Drawing.Size(344, 40)
        Me.btnManageShoes.TabIndex = 1
        Me.btnManageShoes.Text = "Manage Shoes"
        Me.btnManageShoes.UseVisualStyleBackColor = True
        '
        'grpManageAssignHorseVaccinations
        '
        Me.grpManageAssignHorseVaccinations.Controls.Add(Me.btnAssignHorseVaccinations)
        Me.grpManageAssignHorseVaccinations.Controls.Add(Me.btnManageVaccinations)
        Me.grpManageAssignHorseVaccinations.Location = New System.Drawing.Point(821, 33)
        Me.grpManageAssignHorseVaccinations.Name = "grpManageAssignHorseVaccinations"
        Me.grpManageAssignHorseVaccinations.Size = New System.Drawing.Size(382, 169)
        Me.grpManageAssignHorseVaccinations.TabIndex = 3
        Me.grpManageAssignHorseVaccinations.TabStop = False
        Me.grpManageAssignHorseVaccinations.Text = "Manage/Assign Horse Vaccinations"
        '
        'btnAssignHorseVaccinations
        '
        Me.btnAssignHorseVaccinations.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignHorseVaccinations.Location = New System.Drawing.Point(19, 100)
        Me.btnAssignHorseVaccinations.Name = "btnAssignHorseVaccinations"
        Me.btnAssignHorseVaccinations.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignHorseVaccinations.TabIndex = 1
        Me.btnAssignHorseVaccinations.Text = "Assign Horse Vaccinations"
        Me.btnAssignHorseVaccinations.UseVisualStyleBackColor = True
        '
        'btnManageVaccinations
        '
        Me.btnManageVaccinations.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageVaccinations.Location = New System.Drawing.Point(19, 35)
        Me.btnManageVaccinations.Name = "btnManageVaccinations"
        Me.btnManageVaccinations.Size = New System.Drawing.Size(344, 40)
        Me.btnManageVaccinations.TabIndex = 0
        Me.btnManageVaccinations.Text = "Manage Vaccinations"
        Me.btnManageVaccinations.UseVisualStyleBackColor = True
        '
        'grpManageAssignHorseWestNileTests
        '
        Me.grpManageAssignHorseWestNileTests.Controls.Add(Me.btnAssignHorseWestNileTests)
        Me.grpManageAssignHorseWestNileTests.Controls.Add(Me.btnManageWestNileTests)
        Me.grpManageAssignHorseWestNileTests.Location = New System.Drawing.Point(420, 208)
        Me.grpManageAssignHorseWestNileTests.Name = "grpManageAssignHorseWestNileTests"
        Me.grpManageAssignHorseWestNileTests.Size = New System.Drawing.Size(382, 169)
        Me.grpManageAssignHorseWestNileTests.TabIndex = 4
        Me.grpManageAssignHorseWestNileTests.TabStop = False
        Me.grpManageAssignHorseWestNileTests.Text = "Manage/Assign Horse WestNile Tests"
        '
        'btnAssignHorseWestNileTests
        '
        Me.btnAssignHorseWestNileTests.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignHorseWestNileTests.Location = New System.Drawing.Point(19, 103)
        Me.btnAssignHorseWestNileTests.Name = "btnAssignHorseWestNileTests"
        Me.btnAssignHorseWestNileTests.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignHorseWestNileTests.TabIndex = 2
        Me.btnAssignHorseWestNileTests.Text = "Assign Horse WestNile Tests"
        Me.btnAssignHorseWestNileTests.UseVisualStyleBackColor = True
        '
        'btnManageWestNileTests
        '
        Me.btnManageWestNileTests.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageWestNileTests.Location = New System.Drawing.Point(19, 38)
        Me.btnManageWestNileTests.Name = "btnManageWestNileTests"
        Me.btnManageWestNileTests.Size = New System.Drawing.Size(344, 40)
        Me.btnManageWestNileTests.TabIndex = 1
        Me.btnManageWestNileTests.Text = "Manage WestNile Tests"
        Me.btnManageWestNileTests.UseVisualStyleBackColor = True
        '
        'grpManageAssignHorseDewormers
        '
        Me.grpManageAssignHorseDewormers.Controls.Add(Me.btnAssignHorseDewormers)
        Me.grpManageAssignHorseDewormers.Controls.Add(Me.btnManageDewormers)
        Me.grpManageAssignHorseDewormers.Location = New System.Drawing.Point(821, 208)
        Me.grpManageAssignHorseDewormers.Name = "grpManageAssignHorseDewormers"
        Me.grpManageAssignHorseDewormers.Size = New System.Drawing.Size(382, 169)
        Me.grpManageAssignHorseDewormers.TabIndex = 5
        Me.grpManageAssignHorseDewormers.TabStop = False
        Me.grpManageAssignHorseDewormers.Text = "Manage/Assign Horse Dewormers"
        '
        'btnAssignHorseDewormers
        '
        Me.btnAssignHorseDewormers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignHorseDewormers.Location = New System.Drawing.Point(19, 102)
        Me.btnAssignHorseDewormers.Name = "btnAssignHorseDewormers"
        Me.btnAssignHorseDewormers.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignHorseDewormers.TabIndex = 2
        Me.btnAssignHorseDewormers.Text = "Assign Horse Dewormers"
        Me.btnAssignHorseDewormers.UseVisualStyleBackColor = True
        '
        'btnManageDewormers
        '
        Me.btnManageDewormers.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageDewormers.Location = New System.Drawing.Point(20, 35)
        Me.btnManageDewormers.Name = "btnManageDewormers"
        Me.btnManageDewormers.Size = New System.Drawing.Size(344, 40)
        Me.btnManageDewormers.TabIndex = 1
        Me.btnManageDewormers.Text = "Manage Dewormers"
        Me.btnManageDewormers.UseVisualStyleBackColor = True
        '
        'grpManageAssignHorseHealthCertificates
        '
        Me.grpManageAssignHorseHealthCertificates.Controls.Add(Me.btnAssignHorseHealthCertificates)
        Me.grpManageAssignHorseHealthCertificates.Controls.Add(Me.btnManageHealthCertificates)
        Me.grpManageAssignHorseHealthCertificates.Location = New System.Drawing.Point(821, 383)
        Me.grpManageAssignHorseHealthCertificates.Name = "grpManageAssignHorseHealthCertificates"
        Me.grpManageAssignHorseHealthCertificates.Size = New System.Drawing.Size(382, 169)
        Me.grpManageAssignHorseHealthCertificates.TabIndex = 6
        Me.grpManageAssignHorseHealthCertificates.TabStop = False
        Me.grpManageAssignHorseHealthCertificates.Text = "Manage/Assign Horse Health Certificates"
        '
        'btnAssignHorseHealthCertificates
        '
        Me.btnAssignHorseHealthCertificates.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignHorseHealthCertificates.Location = New System.Drawing.Point(19, 100)
        Me.btnAssignHorseHealthCertificates.Name = "btnAssignHorseHealthCertificates"
        Me.btnAssignHorseHealthCertificates.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignHorseHealthCertificates.TabIndex = 2
        Me.btnAssignHorseHealthCertificates.Text = "Assign Horse Health Certificates"
        Me.btnAssignHorseHealthCertificates.UseVisualStyleBackColor = True
        '
        'btnManageHealthCertificates
        '
        Me.btnManageHealthCertificates.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageHealthCertificates.Location = New System.Drawing.Point(19, 35)
        Me.btnManageHealthCertificates.Name = "btnManageHealthCertificates"
        Me.btnManageHealthCertificates.Size = New System.Drawing.Size(344, 40)
        Me.btnManageHealthCertificates.TabIndex = 1
        Me.btnManageHealthCertificates.Text = "Manage Health Certificates"
        Me.btnManageHealthCertificates.UseVisualStyleBackColor = True
        '
        'grpManageAssignEquipmentMaintenance
        '
        Me.grpManageAssignEquipmentMaintenance.Controls.Add(Me.btnAssignEquipmentMaintenance)
        Me.grpManageAssignEquipmentMaintenance.Controls.Add(Me.btnManageMaintenance)
        Me.grpManageAssignEquipmentMaintenance.Controls.Add(Me.btnManageEquipment)
        Me.grpManageAssignEquipmentMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpManageAssignEquipmentMaintenance.Location = New System.Drawing.Point(21, 272)
        Me.grpManageAssignEquipmentMaintenance.Name = "grpManageAssignEquipmentMaintenance"
        Me.grpManageAssignEquipmentMaintenance.Size = New System.Drawing.Size(382, 232)
        Me.grpManageAssignEquipmentMaintenance.TabIndex = 8
        Me.grpManageAssignEquipmentMaintenance.TabStop = False
        Me.grpManageAssignEquipmentMaintenance.Text = "Manage/Assign Equipment Maintenance"
        '
        'btnAssignEquipmentMaintenance
        '
        Me.btnAssignEquipmentMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignEquipmentMaintenance.Location = New System.Drawing.Point(19, 167)
        Me.btnAssignEquipmentMaintenance.Name = "btnAssignEquipmentMaintenance"
        Me.btnAssignEquipmentMaintenance.Size = New System.Drawing.Size(344, 40)
        Me.btnAssignEquipmentMaintenance.TabIndex = 2
        Me.btnAssignEquipmentMaintenance.Text = "Assign Equipment Maintenance"
        Me.btnAssignEquipmentMaintenance.UseVisualStyleBackColor = True
        '
        'btnManageMaintenance
        '
        Me.btnManageMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageMaintenance.Location = New System.Drawing.Point(20, 100)
        Me.btnManageMaintenance.Name = "btnManageMaintenance"
        Me.btnManageMaintenance.Size = New System.Drawing.Size(344, 40)
        Me.btnManageMaintenance.TabIndex = 1
        Me.btnManageMaintenance.Text = "Manage Maintenance"
        Me.btnManageMaintenance.UseVisualStyleBackColor = True
        '
        'btnManageEquipment
        '
        Me.btnManageEquipment.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageEquipment.Location = New System.Drawing.Point(20, 33)
        Me.btnManageEquipment.Name = "btnManageEquipment"
        Me.btnManageEquipment.Size = New System.Drawing.Size(344, 40)
        Me.btnManageEquipment.TabIndex = 0
        Me.btnManageEquipment.Text = "Manage Equipment"
        Me.btnManageEquipment.UseVisualStyleBackColor = True
        '
        'grpManageFeedMiscExpenses
        '
        Me.grpManageFeedMiscExpenses.Controls.Add(Me.btnManageFeedMiscExpenses)
        Me.grpManageFeedMiscExpenses.Location = New System.Drawing.Point(420, 383)
        Me.grpManageFeedMiscExpenses.Name = "grpManageFeedMiscExpenses"
        Me.grpManageFeedMiscExpenses.Size = New System.Drawing.Size(382, 97)
        Me.grpManageFeedMiscExpenses.TabIndex = 7
        Me.grpManageFeedMiscExpenses.TabStop = False
        Me.grpManageFeedMiscExpenses.Text = "Manage Feed/Misc Expenses"
        '
        'btnManageFeedMiscExpenses
        '
        Me.btnManageFeedMiscExpenses.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageFeedMiscExpenses.Location = New System.Drawing.Point(19, 32)
        Me.btnManageFeedMiscExpenses.Name = "btnManageFeedMiscExpenses"
        Me.btnManageFeedMiscExpenses.Size = New System.Drawing.Size(344, 40)
        Me.btnManageFeedMiscExpenses.TabIndex = 0
        Me.btnManageFeedMiscExpenses.Text = "Manage Feed &&Misc Expenses"
        Me.btnManageFeedMiscExpenses.UseVisualStyleBackColor = True
        '
        'btnCloseTheApplication
        '
        Me.btnCloseTheApplication.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseTheApplication.Location = New System.Drawing.Point(439, 539)
        Me.btnCloseTheApplication.Name = "btnCloseTheApplication"
        Me.btnCloseTheApplication.Size = New System.Drawing.Size(344, 61)
        Me.btnCloseTheApplication.TabIndex = 10
        Me.btnCloseTheApplication.Text = "Close the Application"
        Me.btnCloseTheApplication.UseVisualStyleBackColor = True
        '
        'lblFMainInformation
        '
        Me.lblFMainInformation.AutoSize = True
        Me.lblFMainInformation.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblFMainInformation.Location = New System.Drawing.Point(55, 526)
        Me.lblFMainInformation.Name = "lblFMainInformation"
        Me.lblFMainInformation.Size = New System.Drawing.Size(299, 54)
        Me.lblFMainInformation.TabIndex = 11
        Me.lblFMainInformation.Text = "Enter information by clicking the desired " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & """Manage"" button and assign it to a pa" & _
    "rticular " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "horse by clicking the ""Assign"" button."
        '
        'FMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1228, 628)
        Me.Controls.Add(Me.lblFMainInformation)
        Me.Controls.Add(Me.btnCloseTheApplication)
        Me.Controls.Add(Me.grpManageFeedMiscExpenses)
        Me.Controls.Add(Me.grpManageAssignEquipmentMaintenance)
        Me.Controls.Add(Me.grpManageAssignHorseHealthCertificates)
        Me.Controls.Add(Me.grpManageAssignHorseDewormers)
        Me.Controls.Add(Me.grpManageAssignHorseWestNileTests)
        Me.Controls.Add(Me.grpManageAssignHorseVaccinations)
        Me.Controls.Add(Me.grpManageAssignHorseShoes)
        Me.Controls.Add(Me.grpManageAssignHorses)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Capstone Horse Project"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.grpManageAssignHorses.ResumeLayout(False)
        Me.grpManageAssignHorseShoes.ResumeLayout(False)
        Me.grpManageAssignHorseVaccinations.ResumeLayout(False)
        Me.grpManageAssignHorseWestNileTests.ResumeLayout(False)
        Me.grpManageAssignHorseDewormers.ResumeLayout(False)
        Me.grpManageAssignHorseHealthCertificates.ResumeLayout(False)
        Me.grpManageAssignEquipmentMaintenance.ResumeLayout(False)
        Me.grpManageFeedMiscExpenses.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents grpManageAssignHorses As System.Windows.Forms.GroupBox
    Friend WithEvents btnManageSellers As System.Windows.Forms.Button
    Friend WithEvents btnManageBuyers As System.Windows.Forms.Button
    Friend WithEvents btnManageHorses As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignHorseShoes As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignHorseShoes As System.Windows.Forms.Button
    Friend WithEvents btnManageShoes As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignHorseVaccinations As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignHorseVaccinations As System.Windows.Forms.Button
    Friend WithEvents btnManageVaccinations As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignHorseWestNileTests As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignHorseWestNileTests As System.Windows.Forms.Button
    Friend WithEvents btnManageWestNileTests As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignHorseDewormers As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignHorseDewormers As System.Windows.Forms.Button
    Friend WithEvents btnManageDewormers As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignHorseHealthCertificates As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignHorseHealthCertificates As System.Windows.Forms.Button
    Friend WithEvents btnManageHealthCertificates As System.Windows.Forms.Button
    Friend WithEvents grpManageAssignEquipmentMaintenance As System.Windows.Forms.GroupBox
    Friend WithEvents btnAssignEquipmentMaintenance As System.Windows.Forms.Button
    Friend WithEvents btnManageMaintenance As System.Windows.Forms.Button
    Friend WithEvents btnManageEquipment As System.Windows.Forms.Button
    Friend WithEvents grpManageFeedMiscExpenses As System.Windows.Forms.GroupBox
    Friend WithEvents btnManageFeedMiscExpenses As System.Windows.Forms.Button
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageHorses As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageBuyers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageSellers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageShoes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageVaccinations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageWestNileTests As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageDewormers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageHealthCertificates As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageFeedMiscExpenses As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageEquipment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuManageMaintenance As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssignEquipmentMaintenance As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnCloseTheApplication As System.Windows.Forms.Button
    Friend WithEvents mnuAssignWestNileTests As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssignHorseDewormers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssignHorseHealthCertificates As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssignHorseShoes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAssignHorseVaccinations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblFMainInformation As System.Windows.Forms.Label

End Class
