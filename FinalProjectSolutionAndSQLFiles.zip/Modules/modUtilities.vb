﻿' -------------------------------------------------------------------------
' Module: modUtilities
' Author: Patrick Callahan
' Abstract: General purpose utilities
' Comment: I want to thank Pat for the write log and the help in building the rest.
'
' Revision        Owner   Changes:
' 2013/04/07      P.C.    For Book
' -------------------------------------------------------------------------

' -------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------
Option Explicit On


' -------------------------------------------------------------------------
' Imports
' -------------------------------------------------------------------------
Imports System
Imports System.IO
Imports System.Text.RegularExpressions


Public Module modUtilities

    ' -------------------------------------------------------------------------
    '  Module constants
    ' -------------------------------------------------------------------------
    ' What log file should we use
    Private Const strLOG_FILE_EXTENSION As String = ".Log"

    ' -------------------------------------------------------------------------
    '  Module variables
    ' -------------------------------------------------------------------------
    Private m_strOldLogFilePath As String           ' Name of the last log file opened
    Private m_fsLogFile As FileStream = Nothing     ' File handle of the last log file opened


#Region "TrimAllFormTextBoxes"
    ' -------------------------------------------------------------------------
    ' Name: TrimAllFormTextBoxes
    ' Abstract: Trim all the textboxes on the form.
    ' -------------------------------------------------------------------------
    Public Sub TrimAllFormTextBoxes(frmTarget As Form)

        Try

            ' Even more shizzle way ... but still not the best
            Dim intIndex As Integer
            Dim ctlCurrentControl As Control
            Dim txtCurrentTextBox As TextBox

            For intIndex = 0 To frmTarget.Controls.Count - 1

                ' Get the next control from the list of all controls on the from
                ctlCurrentControl = frmTarget.Controls.Item(intIndex)

                ' Is it a textbox
                If TypeOf (ctlCurrentControl) Is TextBox Then

                    ' Yes, explicit cast to textbox so ...
                    txtCurrentTextBox = ctlCurrentControl

                    ' we can acces the text property and trim
                    txtCurrentTextBox.Text = txtCurrentTextBox.Text.Trim

                End If

            Next
        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub
#End Region



#Region "IsValid ZipCode, PhoneNumber, Salary, Date and Email"
    ' -------------------------------------------------------------------------
    ' Name: IsValidZipCode
    ' Abstract: Use regular expressions to validate the zip code:
    '           5 digits or 5 plus 4 digits
    '           ##### or #####-####
    ' -------------------------------------------------------------------------
    Public Function IsValidZipCode(ByVal strZipCode As String) As Boolean

        Dim blnIsValidZipCode As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strStart As String = "^"
            Dim strStop As String = "$"
            ' \ is the escape character in regular expressions
            Dim strPattern1 As String
            Dim strPattern2 As String

            ' #####
            strPattern1 = strStart & "\d{5}" & strStop

            ' #####-####
            strPattern2 = strStart & "\d{5}" & "\-" & "\d{4}" & strStop

            ' Does it match any of the formats?
            If Regex.IsMatch(strZipCode, strPattern1) = True Or _
               Regex.IsMatch(strZipCode, strPattern2) = True Then

                ' Yes
                blnIsValidZipCode = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnIsValidZipCode

    End Function



    ' -------------------------------------------------------------------------
    ' Name: IsValidPhoneNumber
    ' Abstract: Is valid phone number.  Valid formats are:
    '           ###-#### or ###-###-#### or (###)-###-####
    ' -------------------------------------------------------------------------
    Public Function IsValidPhoneNumber(ByVal strHomePhoneNumber As String) As Boolean

        Dim blnIsValidHomePhoneNumber As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strStart As String = "^"
            Dim strStop As String = "$"
            ' \ is the escape character in regular expressions
            Dim strPattern1 As String
            Dim strPattern2 As String
            Dim strPattern3 As String

            ' #####
            strPattern1 = strStart & "\d{3}" & "\-" & "\d{4}" & strStop

            ' #####-####
            strPattern2 = strStart & "\d{3}" & "\-" & "\d{3}" & "\-" & "\d{4}" & strStop

            ' (###)-###-####
            strPattern3 = strStart & "\(\d{3}\)" & "\d{3}" & "\-" & "\d{4}" & strStop

            ' Does it match any of the formats?
            If Regex.IsMatch(strHomePhoneNumber, strPattern1) = True Or _
               Regex.IsMatch(strHomePhoneNumber, strPattern2) = True Or _
               Regex.IsMatch(strHomePhoneNumber, strPattern3) = True Then

                ' Yes
                blnIsValidHomePhoneNumber = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnIsValidHomePhoneNumber

    End Function



    ' -------------------------------------------------------------------------
    ' Name: IsValidSalary
    ' Abstract: Use regular expressions to validate the Salary:
    '           Without commas, with optional decimal or same with commas every 3
    '           digits - ###.## or ###,###.##
    ' -------------------------------------------------------------------------
    Public Function IsValidSalary(ByVal strSalary As String) As Boolean

        Dim blnIsValidSalary As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strStart As String = "^"
            Dim strOptionalPlusOrMinus As String = "[\+\-]?"
            Dim strOptionalDollarSign As String = "\$?"
            Dim strOptionalDecimal As String = "(\.\d{2})?"
            Dim strStop As String = "$"
            ' \ is the escape character in regular expressions
            Dim strPattern1 As String
            Dim strPattern2 As String

            ' Without commas, but with optional decimal
            strPattern1 = strStart & strOptionalPlusOrMinus & strOptionalDollarSign & "\d+" & strOptionalDecimal & strStop

            ' With commas every 3 digits and with optional decimal
            strPattern2 = strStart & strOptionalPlusOrMinus & strOptionalDollarSign & "\d{1,3}(,\d{1,3})*" & strOptionalDecimal & strStop

            ' Does it match any of the formats?
            If Regex.IsMatch(strSalary, strPattern1) = True Or _
               Regex.IsMatch(strSalary, strPattern2) = True Then

                ' Yes
                blnIsValidSalary = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnIsValidSalary

    End Function



    ' -------------------------------------------------------------------------
    ' Name: IsValidDate
    ' Abstract: Is it a valid date with format: yyyy/mm/dd
    ' -------------------------------------------------------------------------
    Public Function IsValidDate(ByVal strDate As String) As Boolean

        Dim blnIsValidDateOfBirth As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strStart As String = "^"
            Dim strStop As String = "$"
            ' \ is the escape character in regular expressions
            Dim strPattern As String

            ' #####
            strPattern = strStart & "\d{4}" & "[\/\-]?" & "\d{2}" & "[\/\-]?" & "\d{2}" & strStop

            ' Does it match any of the formats?
            If Regex.IsMatch(strDate, strPattern) = True Then

                ' Yes
                blnIsValidDateOfBirth = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnIsValidDateOfBirth

    End Function



    ' -------------------------------------------------------------------------
    ' Name: IsValidEmailAddress
    ' Abstract: Use regular expressions to validate the email address:
    '           1:letter, N:letters/numbers/dot/dash,
    '           1:@,
    '           1:letter, N:letters/numbers/dot/dash, 1:dot, 2-6:letters
    ' -------------------------------------------------------------------------
    Public Function IsValidEmailAddress(ByVal strEmailAddress As String) As Boolean

        Dim blnIsValidEmailAddress As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strStart As String = "^"
            Dim strDash = "\-"
            Dim strStop As String = "$"
            ' \ is the escape character in regular expressions
            Dim strPattern As String


            ' 1:letter, N:letters/numbers/dot/dash,
            ' 1:@,
            ' 1:letter, N:letters/numbers/dot/dash, 1:dot, 2-6:letters
            strPattern = strStart _
                            & "[a-zA-Z][a-zA-Z0-9\.\-]*" _
                            & "@" _
                            & "[a-zA-Z][a-zA-Z0-9\.\-]*\.[a-zA-Z]{2,6}" _
                        & strStop

            ' Does it match any of the formats?
            If Regex.IsMatch(strEmailAddress, strPattern) = True Then

                ' Yes
                blnIsValidEmailAddress = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnIsValidEmailAddress

    End Function
#End Region



#Region "SetBusyCursor"
    ' -------------------------------------------------------------------------
    ' Name: SetBusyCursor
    ' Abstract: Enable/Disable the form and set the cursor to normal or busy.
    ' -------------------------------------------------------------------------
    Public Sub SetBusyCursor(ByRef frmForm As Form, ByVal blnBusy As Boolean)

        ' Try/Catch with WriteLog
        Try

            ' Busy? 
            If blnBusy = True Then

                ' Yes
                frmForm.Cursor = Cursors.WaitCursor
                frmForm.Enabled = False

            Else

                ' No
                frmForm.Cursor = Cursors.Default
                frmForm.Enabled = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

    End Sub
#End Region



#Region "HighlightNextItemInList"
    ' --------------------------------------------------------------------------------
    ' Name: HighlightNextItemInList
    ' Abstract: Highlight next item in list
    ' --------------------------------------------------------------------------------
    Public Sub HighlightNextItemInList(ByRef lstTarget As ListBox, ByVal intSelectedIndex As Integer)

        ' Try/Catch with WriteLog
        Try

            ' Anything in the list
            If lstTarget.Items.Count > 0 Then

                ' Yes, did we delete the last item?
                If intSelectedIndex > lstTarget.Items.Count - 1 Then

                    ' Yes, move back one
                    intSelectedIndex = lstTarget.Items.Count - 1

                End If

                ' Select it
                lstTarget.SelectedIndex = intSelectedIndex

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

    End Sub
#End Region



#Region "SelectItemInListFromID"
    ' --------------------------------------------------------------------------------
    ' Name: SelectItemInListFromID
    ' Abstract: Get Selected Item in List from ID
    ' --------------------------------------------------------------------------------
    Public Sub SelectItemInListFromID(ByRef cmbTarget As ComboBox, ByVal intIDToSelect As Integer)

        ' Try/Catch with WriteLog
        Try

            Dim intIndex As Integer
            Dim liCurrentItem As CListItem

            ' Loop through list Items
            For intIndex = 0 To cmbTarget.Items.Count - 1

                ' Get current Item using index
                liCurrentItem = cmbTarget.Items(intIndex)

                ' Does the current Item ID match
                If liCurrentItem.GetID = intIDToSelect Then

                    ' Yes, so set Combobox equal to intIndex
                    cmbTarget.SelectedIndex = intIndex

                    ' We found a match stop searching and exit loop
                    Exit For

                End If

            Next

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

    End Sub
#End Region



#Region "WriteLog"
    ' -------------------------------------------------------------------------
    ' Name: WriteLog
    ' Abstract: Overload withd blnDisplay set to true
    ' -------------------------------------------------------------------------
    Public Sub WriteLog(ByVal excErrorToLog As Exception, _
               Optional ByVal blnDisplayWarning As Boolean = True)

        Try

            WriteLog(excErrorToLog.ToString(), blnDisplayWarning)

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), _
                            Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: WriteLog
    ' Abstract: Write a message to the error log.
    ' -------------------------------------------------------------------------
    Public Sub WriteLog(ByVal strMessageToLog As String, _
               Optional ByVal blnDisplayWarning As Boolean = True)

        Try

            Dim fsLogFile As FileStream = Nothing
            Dim encConvertToByteArray As New System.Text.UTF8Encoding

            ' Warn the user?
            If blnDisplayWarning = True Then

                ' Yes( ProductName is set in AssemblyInfo )
                MessageBox.Show(strMessageToLog, Application.ProductName, _
                                MessageBoxButtons.OK, MessageBoxIcon.Warning)

            End If

            ' Append a date/time stamp
            strMessageToLog = (DateTime.Now).ToString("yyyy/MM/dd HH:mm:ss") _
                              & " - " & strMessageToLog & vbNewLine & _
                              vbNewLine

            ' Get a free file handle
            fsLogFile = GetLogFile()

            ' Is the file OK?
            If Not fsLogFile Is Nothing Then

                ' Yes, Log it
                fsLogFile.Write(encConvertToByteArray.GetBytes(strMessageToLog), _
                                0, strMessageToLog.Length)

                ' Flush the buffer so we can immediately see results in file.  Very important.
                ' Otherwise we have to wait for flush which might be when application closes
                ' or we get another error.  Waiting for the application to close may not be
                ' a good idea if the application is in a production environment (e.g. a web
                '  app running on a remote server)
                fsLogFile.Flush()

            End If

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), _
                            Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: DeleteOldFiles
    ' Abstract: Delete any files older than 10 days.
    ' -------------------------------------------------------------------------
    Private Sub DeleteOldFiles()

        Try

            Dim strLogFilePath As String = ""
            Dim dirLogDirectory As DirectoryInfo = Nothing
            Dim dtmFileCreated As DateTime = Now
            Dim intDaysOld As Integer = 0

            ' Path
            strLogFilePath = Application.StartupPath & "\Log\"

            ' Look for any files
            dirLogDirectory = New DirectoryInfo(strLogFilePath)

            ' Are there any?
            For Each finLogFile As FileInfo _
                In dirLogDirectory.GetFiles("*" & strLOG_FILE_EXTENSION)

                ' When was the file created?
                dtmFileCreated = finLogFile.CreationTime

                ' How old is the file?
                intDaysOld = (dtmFileCreated.Subtract(DateTime.Now)).Days

                ' Is the file older than 10 days?
                If intDaysOld > 10 Then

                    ' Yes.  Delete it.
                    finLogFile.Delete()

                End If

            Next

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), _
                            Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

    End Sub


    ' -------------------------------------------------------------------------
    ' Name: GetLogFile
    ' Abstract: Open the log file for writing.  Use today's date as part of
    '           the file name.  Each day a new log file will be created.
    '           Makes debug easier.
    '           Use a filestream object so we can specify file read share
    '           during the open call.
    ' -------------------------------------------------------------------------
    Private Function GetLogFile() As FileStream

        Try
            Dim strToday As String = (DateTime.Now).ToString("yyyyMMdd")
            Dim strLogFilePath As String = ""

            ' Log everything in a log directory off of the current application directory
            strLogFilePath = Application.StartupPath & _
                             "\Log\" & strToday & strLOG_FILE_EXTENSION

            ' Is this a new day?
            If m_strOldLogFilePath <> strLogFilePath Then

                ' Save the log file name
                m_strOldLogFilePath = strLogFilePath

                ' Does the log directory exist?
                If Directory.Exists(Application.StartupPath & "\Log") = False Then

                    ' No, so create it
                    Directory.CreateDirectory(Application.StartupPath & "\Log")

                End If

                ' Close old log file( if there is one )
                If Not m_fsLogFile Is Nothing Then m_fsLogFile.Close()

                ' Delete old log files
                DeleteOldFiles()

                ' Does the file exist?
                If File.Exists(strLogFilePath) = False Then

                    ' No, create with shared read access so it can be read while application has it open
                    m_fsLogFile = New FileStream(strLogFilePath, FileMode.Create, _
                                                 FileAccess.Write, FileShare.Read)

                Else

                    ' Yes, append with shared read access so it can be read while application has it open
                    m_fsLogFile = New FileStream(strLogFilePath, FileMode.Append, _
                                                 FileAccess.Write, FileShare.Read)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            MessageBox.Show("Error:" & vbNewLine & excError.ToString(), _
                            Application.ProductName, _
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)

        End Try

        ' Return result
        Return m_fsLogFile

    End Function
#End Region

End Module
