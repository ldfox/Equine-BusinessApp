﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageDewormers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvDewormers = New System.Windows.Forms.DataGridView()
        Me.IntDewormerIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteDewormerDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecDewormerCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrDewormerStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VDewormersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLDewormersDS = New CapstoneHorseApplication.CPDM_FoxLDewormersDS()
        Me.lblAddEditDelete = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lblDewormers = New System.Windows.Forms.Label()
        Me.lstDewormers = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.VDewormersTableAdapter = New CapstoneHorseApplication.CPDM_FoxLDewormersDSTableAdapters.VDewormersTableAdapter()
        CType(Me.dgvDewormers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VDewormersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLDewormersDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.BackColor = System.Drawing.SystemColors.Menu
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvDewormers
        '
        Me.dgvDewormers.AllowUserToAddRows = False
        Me.dgvDewormers.AllowUserToDeleteRows = False
        Me.dgvDewormers.AutoGenerateColumns = False
        Me.dgvDewormers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDewormers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntDewormerIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.DteDewormerDateDataGridViewTextBoxColumn, Me.DecDewormerCostDataGridViewTextBoxColumn, Me.StrDewormerStatusDataGridViewTextBoxColumn})
        Me.dgvDewormers.DataSource = Me.VDewormersBindingSource
        Me.dgvDewormers.Location = New System.Drawing.Point(26, 309)
        Me.dgvDewormers.Name = "dgvDewormers"
        Me.dgvDewormers.ReadOnly = True
        Me.dgvDewormers.RowTemplate.Height = 24
        Me.dgvDewormers.Size = New System.Drawing.Size(966, 350)
        Me.dgvDewormers.TabIndex = 6
        '
        'IntDewormerIDDataGridViewTextBoxColumn
        '
        Me.IntDewormerIDDataGridViewTextBoxColumn.DataPropertyName = "intDewormerID"
        Me.IntDewormerIDDataGridViewTextBoxColumn.HeaderText = "intDewormerID"
        Me.IntDewormerIDDataGridViewTextBoxColumn.Name = "IntDewormerIDDataGridViewTextBoxColumn"
        Me.IntDewormerIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteDewormerDateDataGridViewTextBoxColumn
        '
        Me.DteDewormerDateDataGridViewTextBoxColumn.DataPropertyName = "dteDewormerDate"
        Me.DteDewormerDateDataGridViewTextBoxColumn.HeaderText = "dteDewormerDate"
        Me.DteDewormerDateDataGridViewTextBoxColumn.Name = "DteDewormerDateDataGridViewTextBoxColumn"
        Me.DteDewormerDateDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecDewormerCostDataGridViewTextBoxColumn
        '
        Me.DecDewormerCostDataGridViewTextBoxColumn.DataPropertyName = "decDewormerCost"
        Me.DecDewormerCostDataGridViewTextBoxColumn.HeaderText = "decDewormerCost"
        Me.DecDewormerCostDataGridViewTextBoxColumn.Name = "DecDewormerCostDataGridViewTextBoxColumn"
        Me.DecDewormerCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrDewormerStatusDataGridViewTextBoxColumn
        '
        Me.StrDewormerStatusDataGridViewTextBoxColumn.DataPropertyName = "strDewormerStatus"
        Me.StrDewormerStatusDataGridViewTextBoxColumn.HeaderText = "strDewormerStatus"
        Me.StrDewormerStatusDataGridViewTextBoxColumn.Name = "StrDewormerStatusDataGridViewTextBoxColumn"
        Me.StrDewormerStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VDewormersBindingSource
        '
        Me.VDewormersBindingSource.DataMember = "VDewormers"
        Me.VDewormersBindingSource.DataSource = Me.CPDM_FoxLDewormersDS
        '
        'CPDM_FoxLDewormersDS
        '
        Me.CPDM_FoxLDewormersDS.DataSetName = "CPDM_FoxLDewormersDS"
        Me.CPDM_FoxLDewormersDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblAddEditDelete
        '
        Me.lblAddEditDelete.AutoSize = True
        Me.lblAddEditDelete.BackColor = System.Drawing.SystemColors.Control
        Me.lblAddEditDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblAddEditDelete.Location = New System.Drawing.Point(522, 51)
        Me.lblAddEditDelete.Name = "lblAddEditDelete"
        Me.lblAddEditDelete.Size = New System.Drawing.Size(315, 36)
        Me.lblAddEditDelete.TabIndex = 12
        Me.lblAddEditDelete.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.BackColor = System.Drawing.SystemColors.Control
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(291, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "status of 2 and may be undeleted any" & _
    " time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.BackColor = System.Drawing.SystemColors.Control
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(522, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 10
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.BackColor = System.Drawing.SystemColors.Control
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(702, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.SystemColors.Control
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(366, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.BackColor = System.Drawing.SystemColors.Control
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = False
        '
        'lblDewormers
        '
        Me.lblDewormers.AutoSize = True
        Me.lblDewormers.BackColor = System.Drawing.SystemColors.Control
        Me.lblDewormers.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDewormers.Location = New System.Drawing.Point(25, 17)
        Me.lblDewormers.Name = "lblDewormers"
        Me.lblDewormers.Size = New System.Drawing.Size(112, 24)
        Me.lblDewormers.TabIndex = 9
        Me.lblDewormers.Text = "Dewormers:"
        '
        'lstDewormers
        '
        Me.lstDewormers.BackColor = System.Drawing.SystemColors.Control
        Me.lstDewormers.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstDewormers.FormattingEnabled = True
        Me.lstDewormers.ItemHeight = 22
        Me.lstDewormers.Location = New System.Drawing.Point(27, 40)
        Me.lstDewormers.Name = "lstDewormers"
        Me.lstDewormers.ScrollAlwaysVisible = True
        Me.lstDewormers.Size = New System.Drawing.Size(308, 224)
        Me.lstDewormers.Sorted = True
        Me.lstDewormers.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.SystemColors.Control
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.BackColor = System.Drawing.SystemColors.Control
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.SystemColors.Control
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'VDewormersTableAdapter
        '
        Me.VDewormersTableAdapter.ClearBeforeFill = True
        '
        'FManageDewormers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1018, 683)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.dgvDewormers)
        Me.Controls.Add(Me.lblAddEditDelete)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblDewormers)
        Me.Controls.Add(Me.lstDewormers)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageDewormers"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Dewormers & View the Data"
        CType(Me.dgvDewormers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VDewormersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLDewormersDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvDewormers As System.Windows.Forms.DataGridView
    Friend WithEvents lblAddEditDelete As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lblDewormers As System.Windows.Forms.Label
    Friend WithEvents lstDewormers As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents CPDM_FoxLDewormersDS As CapstoneHorseApplication.CPDM_FoxLDewormersDS
    Friend WithEvents VDewormersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VDewormersTableAdapter As CapstoneHorseApplication.CPDM_FoxLDewormersDSTableAdapters.VDewormersTableAdapter
    Friend WithEvents IntDewormerIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteDewormerDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecDewormerCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrDewormerStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
