﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageHorseBuyers
' Abstract: Capstone Horse project- Manage Horse Buyers (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Imports System.Data.SqlClient


Public Class FManageHorseBuyers

    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadHorseBuyersList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the Horse Buyers list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseBuyersList
    ' Abstract: Load the Horse Buyers list.
    ' --------------------------------------------------------------------------------
    Private Function LoadHorseBuyersList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveHorseBuyers"

            Else

                strSourceTable = "VInActiveHorseBuyers"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intHorseBuyerID", _
                                                        "strFullName", _
                                                        lstHorseBuyers)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add Horse Buyer form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewHorseBuyerInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddHorse forms
            Dim frmAddHorseBuyer As FAddHorseBuyer

            ' Make an instance
            frmAddHorseBuyer = New FAddHorseBuyer

            ' Show modally
            frmAddHorseBuyer.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddHorseBuyer.GetResult() = True Then

                ' Get the new Horse Buyer values
                liNewHorseBuyerInformation = frmAddHorseBuyer.GetNewHorseBuyerInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstHorseBuyers.Items.Add(liNewHorseBuyerInformation)

                ' ... which we can use to select it
                lstHorseBuyers.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected Horse Buyer.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedHorseBuyerID As Integer
            Dim liSelectedHorseBuyer As CListItem
            Dim frmEditHorseBuyer As FEditHorseBuyer
            Dim liNewHorseBuyerInformation As CListItem
            Dim intIndex As Integer

            ' Is a Horse Buyer selected?
            If lstHorseBuyers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Buyer to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the Horse Buyer to edit ID
                liSelectedHorseBuyer = lstHorseBuyers.SelectedItem
                intSelectedHorseBuyerID = liSelectedHorseBuyer.GetID

                ' Create instance
                frmEditHorseBuyer = New FEditHorseBuyer

                ' Set the form values
                frmEditHorseBuyer.SetHorseBuyerID(intSelectedHorseBuyerID)

                ' Show it modally   
                frmEditHorseBuyer.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditHorseBuyer.GetResult() = True Then

                    ' Get the new Horse Buyer values
                    liNewHorseBuyerInformation = frmEditHorseBuyer.GetNewHorseBuyerInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstHorseBuyers.Items.RemoveAt(lstHorseBuyers.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstHorseBuyers.Items.Add(liNewHorseBuyerInformation)

                    ' ... which we can use to select it
                    lstHorseBuyers.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected Horse Buyer.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteHorseBuyer()

            Else

                ' No, undelete
                UndeleteHorseBuyer()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHorseBuyer
    ' Abstract: Delete the currently selected Buyer.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteHorseBuyer()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorseBuyer As CListItem
            Dim intSelectedHorseBuyerID As Integer
            Dim strSelectedHorseBuyerName As String
            Dim intSelectedHorseBuyerIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Horse Buyer selected?
            If lstHorseBuyers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Buyer to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Horse Buyers ID, name and list index
                liSelectedHorseBuyer = lstHorseBuyers.SelectedItem
                intSelectedHorseBuyerID = liSelectedHorseBuyer.GetID
                strSelectedHorseBuyerName = liSelectedHorseBuyer.GetName
                intSelectedHorseBuyerIndex = lstHorseBuyers.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Horse Buyer: " & strSelectedHorseBuyerName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Horse Buyer (use ID for database command)
                    blnResult = DeleteHorseBuyerFromDatabase(intSelectedHorseBuyerID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Horse Buyer from the list
                        lstHorseBuyers.Items.RemoveAt(intSelectedHorseBuyerIndex)

                        ' Select the next Horse Buyer in the list
                        HighlightNextItemInList(lstHorseBuyers, intSelectedHorseBuyerIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHorseBuyer
    ' Abstract: Undelete the currently selected Buyer.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteHorseBuyer()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorseBuyer As CListItem
            Dim intSelectedHorseBuyerID As Integer
            Dim intSelectedHorseBuyerIndex As Integer
            Dim blnResult As Boolean

            ' Is a Horse Buyer selected?
            If lstHorseBuyers.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Horse Buyer to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Horse Buyer ID and list index
                liSelectedHorseBuyer = lstHorseBuyers.SelectedItem
                intSelectedHorseBuyerID = liSelectedHorseBuyer.GetID
                intSelectedHorseBuyerIndex = lstHorseBuyers.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Horse Buyer (use ID for database command)
                blnResult = UndeleteHorseBuyerFromDatabase(intSelectedHorseBuyerID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Horse Buyer from the list
                    lstHorseBuyers.Items.RemoveAt(intSelectedHorseBuyerIndex)

                    ' Select the next Horse Buyer in the list
                    HighlightNextItemInList(lstHorseBuyers, intSelectedHorseBuyerIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Buyers.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Horse Buyers list
            LoadHorseBuyersList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VHorseBuyersTableAdapter.Fill(Me.CPDM_FoxLHorseBuyersDS.VHorseBuyers)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FManageHorseBuyers_Load
    ' Abstract: Loads the DataSet and populates the dataGridView on form load.
    '           I could not use this without getting a cartesian product when I clicked
    '           the button. But it made a nice place to store the code for the button.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageHorseBuyers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLHorseBuyersDS.VHorseBuyers' table.
    '    Me.VHorseBuyersTableAdapter.Fill(Me.CPDM_FoxLHorseBuyersDS.VHorseBuyers)

    'End Sub
End Class