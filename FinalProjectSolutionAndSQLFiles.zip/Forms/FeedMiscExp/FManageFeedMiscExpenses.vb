﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageFeedMiscExpenses
' Abstract: Capstone Horse project- Manage the feed and misc. expenses (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageFeedMiscExpenses


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadFeedMiscExpensesList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the feed and misc. expenses list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadFeedMiscExpensesList
    ' Abstract: Load the horse FeedMiscExpenses list.
    ' --------------------------------------------------------------------------------
    Private Function LoadFeedMiscExpensesList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveFeedMiscExpenses"

            Else

                strSourceTable = "VInActiveFeedMiscExpenses"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intFeedMiscExpenseID", _
                                                        "strName", _
                                                        lstFeedMiscExpenses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse FeedMiscExpense form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewFeedMiscExpenseInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddFeedMiscExpense forms
            Dim frmAddFeedMiscExpense As FAddFeedMiscExpense

            ' Make an instance
            frmAddFeedMiscExpense = New FAddFeedMiscExpense

            ' Show modally
            frmAddFeedMiscExpense.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddFeedMiscExpense.GetResult() = True Then

                ' Get the new FeedMiscExpense values
                liNewFeedMiscExpenseInformation = frmAddFeedMiscExpense.GetNewFeedMiscExpenseInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstFeedMiscExpenses.Items.Add(liNewFeedMiscExpenseInformation)

                ' ... which we can use to select it
                lstFeedMiscExpenses.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse FeedMiscExpense.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedFeedMiscExpenseID As Integer
            Dim liSelectedFeedMiscExpense As CListItem
            Dim frmEditFeedMiscExpense As FEditFeedMiscExpense
            Dim liNewFeedMiscExpenseInformation As CListItem
            Dim intIndex As Integer

            ' Is a FeedMiscExpense selected?
            If lstFeedMiscExpenses.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Feed & Misc. Expense to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the FeedMiscExpense to edit ID
                liSelectedFeedMiscExpense = lstFeedMiscExpenses.SelectedItem
                intSelectedFeedMiscExpenseID = liSelectedFeedMiscExpense.GetID

                ' Create instance
                frmEditFeedMiscExpense = New FEditFeedMiscExpense

                ' Set the form values
                frmEditFeedMiscExpense.SetFeedMiscExpenseID(intSelectedFeedMiscExpenseID)

                ' Show it modally   
                frmEditFeedMiscExpense.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditFeedMiscExpense.GetResult() = True Then

                    ' Get the new FeedMiscExpense values
                    liNewFeedMiscExpenseInformation = frmEditFeedMiscExpense.GetNewFeedMiscExpenseInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstFeedMiscExpenses.Items.RemoveAt(lstFeedMiscExpenses.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstFeedMiscExpenses.Items.Add(liNewFeedMiscExpenseInformation)

                    ' ... which we can use to select it
                    lstFeedMiscExpenses.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse FeedMiscExpense.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteFeedMiscExpense()

            Else

                ' No, undelete
                UndeleteFeedMiscExpense()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteFeedMiscExpense
    ' Abstract: Delete the currently selected FeedMiscExpense.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteFeedMiscExpense()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedFeedMiscExpense As CListItem
            Dim intSelectedFeedMiscExpenseID As Integer
            Dim strSelectedFeedMiscExpenseName As String
            Dim intSelectedFeedMiscExpenseIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a FeedMiscExpense selected?
            If lstFeedMiscExpenses.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Feed/Misc. Expense to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the FeedMiscExpense ID, name and list index
                liSelectedFeedMiscExpense = lstFeedMiscExpenses.SelectedItem
                intSelectedFeedMiscExpenseID = liSelectedFeedMiscExpense.GetID
                strSelectedFeedMiscExpenseName = liSelectedFeedMiscExpense.GetName
                intSelectedFeedMiscExpenseIndex = lstFeedMiscExpenses.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Feed/Misc. Expense: " & strSelectedFeedMiscExpenseName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the FeedMiscExpense (use ID for database command)
                    blnResult = DeleteFeedMiscExpenseFromDatabase(intSelectedFeedMiscExpenseID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the FeedMiscExpense from the list
                        lstFeedMiscExpenses.Items.RemoveAt(intSelectedFeedMiscExpenseIndex)

                        ' Select the next FeedMiscExpense in the list
                        HighlightNextItemInList(lstFeedMiscExpenses, intSelectedFeedMiscExpenseIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteFeedMiscExpense
    ' Abstract: Undelete the currently selected FeedMiscExpense.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteFeedMiscExpense()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedFeedMiscExpense As CListItem
            Dim intSelectedFeedMiscExpenseID As Integer
            Dim intSelectedFeedMiscExpenseIndex As Integer
            Dim blnResult As Boolean

            ' Is a FeedMiscExpense selected?
            If lstFeedMiscExpenses.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Feed/Misc. Expense to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the FeedMiscExpense ID and list index
                liSelectedFeedMiscExpense = lstFeedMiscExpenses.SelectedItem
                intSelectedFeedMiscExpenseID = liSelectedFeedMiscExpense.GetID
                intSelectedFeedMiscExpenseIndex = lstFeedMiscExpenses.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the FeedMiscExpense (use ID for database command)
                blnResult = UndeleteFeedMiscExpenseFromDatabase(intSelectedFeedMiscExpenseID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the FeedMiscExpense from the list
                    lstFeedMiscExpenses.Items.RemoveAt(intSelectedFeedMiscExpenseIndex)

                    ' Select the next FeedMiscExpense in the list
                    HighlightNextItemInList(lstFeedMiscExpenses, intSelectedFeedMiscExpenseIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the FeedMiscExpenses list
            LoadFeedMiscExpensesList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VFeedMiscExpensesTableAdapter.Fill(Me.CPDM_FoxLFeedMiscExpensesDS.VFeedMiscExpenses)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageFeedMiscExpenses_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLFeedMiscExpensesDS.VFeedMiscExpenses' table.
    '    Me.VFeedMiscExpensesTableAdapter.Fill(Me.CPDM_FoxLFeedMiscExpensesDS.VFeedMiscExpenses)

    'End Sub

End Class