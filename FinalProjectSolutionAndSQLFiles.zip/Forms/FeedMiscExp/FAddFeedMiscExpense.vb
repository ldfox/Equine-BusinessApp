﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditFeedMiscExpenses
' Abstract: Capstone Horse project - Edit Feed/Misc. Expenses (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddFeedMiscExpense


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intFeedMiscExpenseID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddFeedMiscExpense_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddFeedMiscExpense_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the FeedMiscExpense to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add FeedMiscExpense to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Expense Cost
            If txtExpenseCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtExpenseCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Purchase Date
            If txtDatePurchased.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Purchase date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtDatePurchased.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDatePurchased.Text) = False Then

                    strErrorMessage &= "-Purchase date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewFeedMiscExpense As New udtFeedMiscExpenseType

            ' Get values from form
            udtNewFeedMiscExpense = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddFeedMiscExpenseToDatabase2(udtNewFeedMiscExpense)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new FeedMiscExpense ID that's currently in the suitcase
                f_intFeedMiscExpenseID = udtNewFeedMiscExpense.intFeedMiscExpenseID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtFeedMiscExpenseType

        Dim udtFeedMiscExpense As New udtFeedMiscExpenseType

        ' Try/Catch with WriteLog
        Try

            Dim strExpenseCost As String

            ' Load up with data from the form
            'Name 
            udtFeedMiscExpense.strName = txtName.Text


            ' Expense Cost - Remove dollar signs and commas
            strExpenseCost = txtExpenseCost.Text
            strExpenseCost = strExpenseCost.Replace("$", "")
            strExpenseCost = strExpenseCost.Replace(",", "")
            udtFeedMiscExpense.decExpenseCost = Val(strExpenseCost)

            ' Purchase Date
            ' Boundary check - if textbox is empty
            If txtDatePurchased.Text = "" Then

                ' Then insert date
                udtFeedMiscExpense.dteDatePurchased = "1800/01/01"

            Else

                ' Else txtDatePurchased has a value
                udtFeedMiscExpense.dteDatePurchased = txtDatePurchased.Text

            End If

            ' Comments
            udtFeedMiscExpense.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtFeedMiscExpense

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewFeedMiscExpenseInformation
    ' Abstract: Get the new FeedMiscExpense information
    ' --------------------------------------------------------------------------------
    Public Function GetNewFeedMiscExpenseInformation() As CListItem

        Dim liFeedMiscExpense As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liFeedMiscExpense = New CListItem(f_intFeedMiscExpenseID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liFeedMiscExpense

    End Function

End Class