﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Horse HealthCertificates
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignHorseHealthCertificates


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignHorseHealthCertificates_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignHorseHealthCertificates_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveHorses", "intHorseID", "strName", cmbHorses)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHorseHealthCertificates
    ' Abstract: Load the selected and available HealthCertificate lists for the current Horse.
    ' --------------------------------------------------------------------------------
    Private Sub LoadHorseHealthCertificates()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHorse As CListItem
            Dim intHorseID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Horse selected
            If cmbHorses.SelectedIndex >= 0 Then

                ' Get the selected Horse ID
                liSelectedHorse = cmbHorses.SelectedItem
                intHorseID = liSelectedHorse.GetID

                ' Selected HealthCertificates
                ModDatabaseUtilities.LoadListWithHealthCertificatesFromDatabase2(intHorseID, lstSelectedHealthCertificates, True)

                ' Available HealthCertificates
                ModDatabaseUtilities.LoadListWithHealthCertificatesFromDatabase2(intHorseID, lstAvailableHealthCertificates, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableHealthCertificates.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableHealthCertificates.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedHealthCertificates.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedHealthCertificates.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all HealthCertificates to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intIndex As Integer

            ' Is a HealthCertificate selected?
            If lstAvailableHealthCertificates.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and HealthCertificate IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableHealthCertificates.SelectedItem


                ' Add the HealthCertificates from lstAvailableHealthCertificates 
                'If AddAllAvailableHealthCertificatesFromDatabaseMSAccess(intHorseID) = True Then
                If AddAllAvailableHealthCertificatesToHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableHealthCertificates.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedHealthCertificates from lstAvailableHealthCertificates
                        lstSelectedHealthCertificates.Items.Add(lstAvailableHealthCertificates.Items(0))

                        ' Remove from lstAvailableHealthCertificates
                        lstAvailableHealthCertificates.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedHealthCertificates then ...
                    If lstSelectedHealthCertificates.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedHealthCertificates.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a HealthCertificate to the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intHealthCertificateID As Integer
            Dim intIndex As Integer

            ' Is a HealthCertificate selected?
            If lstAvailableHealthCertificates.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and HealthCertificate IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstAvailableHealthCertificates.SelectedItem
                intHealthCertificateID = liSelectedItem.GetID

                ' Add the HealthCertificate
                'If AddHealthCertificateToHorseInDatabaseMSAccess(intHorseID, intHealthCertificateID) = True Then
                If AddHealthCertificateToHorseInDatabase2(intHorseID, intHealthCertificateID) = True Then

                    ' Add to selected HealthCertificates
                    intIndex = lstSelectedHealthCertificates.Items.Add(lstAvailableHealthCertificates.SelectedItem)
                    lstSelectedHealthCertificates.SelectedIndex = intIndex

                    ' Remove from available HealthCertificates
                    intIndex = lstAvailableHealthCertificates.SelectedIndex
                    lstAvailableHealthCertificates.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableHealthCertificates, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected HealthCertificate from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intHealthCertificateID As Integer
            Dim intIndex As Integer

            If lstSelectedHealthCertificates.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and HealthCertificate IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedHealthCertificates.SelectedItem
                intHealthCertificateID = liSelectedItem.GetID

                ' Remove the HealthCertificate
                'If RemoveHealthCertificateFromHorseInDatabaseMSAccess(intHorseID, intHealthCertificateID) = True Then
                If RemoveHealthCertificateFromHorseInDatabase2(intHorseID, intHealthCertificateID) = True Then

                    ' Add to available HealthCertificates
                    intIndex = lstAvailableHealthCertificates.Items.Add(lstSelectedHealthCertificates.SelectedItem)
                    lstAvailableHealthCertificates.SelectedIndex = intIndex

                    ' Remove from selected HealthCertificates
                    intIndex = lstSelectedHealthCertificates.SelectedIndex
                    lstSelectedHealthCertificates.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedHealthCertificates, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the HealthCertificates from the Horse.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intHorseID As Integer
            Dim intHealthCertificateID As Integer
            Dim intIndex As Integer

            If lstSelectedHealthCertificates.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Horse and HealthCertificate IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbHorses.SelectedItem
                intHorseID = liSelectedItem.GetID
                liSelectedItem = lstSelectedHealthCertificates.SelectedItem
                intHealthCertificateID = liSelectedItem.GetID

                ' Remove the HealthCertificate
                'If RemoveAllHealthCertificatesFromHorseInDatabaseMSAccess(intHorseID) = True Then
                If RemoveAllSelectedHealthCertificatesFromHorseInDatabase2(intHorseID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedHealthCertificates.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableHealthCertificates from lstSelectedHealthCertificates
                        lstAvailableHealthCertificates.Items.Add(lstSelectedHealthCertificates.Items(0))

                        ' Remove from lstSelectedHealthCertificates
                        lstSelectedHealthCertificates.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedHealthCertificates then ...
                    If lstAvailableHealthCertificates.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableHealthCertificates.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbHorses_SelectedIndexChanged
    ' Abstract: Load the selected and available HealthCertificate lists for the current Horse.
    ' -------------------------------------------------------------------------
    Private Sub cmbHorses_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbHorses.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadHorseHealthCertificates()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class