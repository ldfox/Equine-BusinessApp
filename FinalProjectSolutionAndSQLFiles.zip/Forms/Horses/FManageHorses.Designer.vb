﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageHorses
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.lstHorses = New System.Windows.Forms.ListBox()
        Me.lblHorses = New System.Windows.Forms.Label()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvHorses = New System.Windows.Forms.DataGridView()
        Me.IntHorseIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrBreedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrRegistrationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrColorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrSexDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrHeightDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BuyerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SellerDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCommentsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrHorseStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VHorsesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLHorsesDS = New CapstoneHorseApplication.CPDM_FoxLHorsesDS()
        Me.VHorsesTableAdapter = New CapstoneHorseApplication.CPDM_FoxLHorsesDSTableAdapters.VHorsesTableAdapter()
        CType(Me.dgvHorses, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VHorsesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLHorsesDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(363, 132)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(534, 132)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(701, 132)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'lstHorses
        '
        Me.lstHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstHorses.FormattingEnabled = True
        Me.lstHorses.ItemHeight = 22
        Me.lstHorses.Location = New System.Drawing.Point(24, 30)
        Me.lstHorses.Name = "lstHorses"
        Me.lstHorses.ScrollAlwaysVisible = True
        Me.lstHorses.Size = New System.Drawing.Size(308, 224)
        Me.lstHorses.Sorted = True
        Me.lstHorses.TabIndex = 8
        '
        'lblHorses
        '
        Me.lblHorses.AutoSize = True
        Me.lblHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHorses.Location = New System.Drawing.Point(22, 7)
        Me.lblHorses.Name = "lblHorses"
        Me.lblHorses.Size = New System.Drawing.Size(75, 24)
        Me.lblHorses.TabIndex = 9
        Me.lblHorses.Text = "Horses:"
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(24, 260)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(470, 225)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(261, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnViewData
        '
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(853, 225)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(261, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = True
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(839, 172)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 12
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(657, 45)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(227, 54)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "a horse status of ""InActive"" and " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "may be un" & _
    "deleted any time. "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(360, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 54)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Click on a horse in the list box " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to highlight then click Add, Edit," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " or Delete" & _
    " to make changes."
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(164, 258)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(199, 34)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox to toggle " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "between Delete and Undelete."
        '
        'dgvHorses
        '
        Me.dgvHorses.AllowUserToAddRows = False
        Me.dgvHorses.AllowUserToDeleteRows = False
        Me.dgvHorses.AutoGenerateColumns = False
        Me.dgvHorses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHorses.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntHorseIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.StrBreedDataGridViewTextBoxColumn, Me.StrRegistrationDataGridViewTextBoxColumn, Me.StrColorDataGridViewTextBoxColumn, Me.StrSexDataGridViewTextBoxColumn, Me.StrHeightDataGridViewTextBoxColumn, Me.BuyerDataGridViewTextBoxColumn, Me.SellerDataGridViewTextBoxColumn, Me.StrCommentsDataGridViewTextBoxColumn, Me.StrHorseStatusDataGridViewTextBoxColumn})
        Me.dgvHorses.DataSource = Me.VHorsesBindingSource
        Me.dgvHorses.Location = New System.Drawing.Point(25, 296)
        Me.dgvHorses.Name = "dgvHorses"
        Me.dgvHorses.ReadOnly = True
        Me.dgvHorses.RowTemplate.Height = 24
        Me.dgvHorses.Size = New System.Drawing.Size(1158, 361)
        Me.dgvHorses.TabIndex = 13
        '
        'IntHorseIDDataGridViewTextBoxColumn
        '
        Me.IntHorseIDDataGridViewTextBoxColumn.DataPropertyName = "intHorseID"
        Me.IntHorseIDDataGridViewTextBoxColumn.HeaderText = "intHorseID"
        Me.IntHorseIDDataGridViewTextBoxColumn.Name = "IntHorseIDDataGridViewTextBoxColumn"
        Me.IntHorseIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrBreedDataGridViewTextBoxColumn
        '
        Me.StrBreedDataGridViewTextBoxColumn.DataPropertyName = "strBreed"
        Me.StrBreedDataGridViewTextBoxColumn.HeaderText = "strBreed"
        Me.StrBreedDataGridViewTextBoxColumn.Name = "StrBreedDataGridViewTextBoxColumn"
        Me.StrBreedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrRegistrationDataGridViewTextBoxColumn
        '
        Me.StrRegistrationDataGridViewTextBoxColumn.DataPropertyName = "strRegistration"
        Me.StrRegistrationDataGridViewTextBoxColumn.HeaderText = "strRegistration"
        Me.StrRegistrationDataGridViewTextBoxColumn.Name = "StrRegistrationDataGridViewTextBoxColumn"
        Me.StrRegistrationDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrColorDataGridViewTextBoxColumn
        '
        Me.StrColorDataGridViewTextBoxColumn.DataPropertyName = "strColor"
        Me.StrColorDataGridViewTextBoxColumn.HeaderText = "strColor"
        Me.StrColorDataGridViewTextBoxColumn.Name = "StrColorDataGridViewTextBoxColumn"
        Me.StrColorDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrSexDataGridViewTextBoxColumn
        '
        Me.StrSexDataGridViewTextBoxColumn.DataPropertyName = "strSex"
        Me.StrSexDataGridViewTextBoxColumn.HeaderText = "strSex"
        Me.StrSexDataGridViewTextBoxColumn.Name = "StrSexDataGridViewTextBoxColumn"
        Me.StrSexDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrHeightDataGridViewTextBoxColumn
        '
        Me.StrHeightDataGridViewTextBoxColumn.DataPropertyName = "strHeight"
        Me.StrHeightDataGridViewTextBoxColumn.HeaderText = "strHeight"
        Me.StrHeightDataGridViewTextBoxColumn.Name = "StrHeightDataGridViewTextBoxColumn"
        Me.StrHeightDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BuyerDataGridViewTextBoxColumn
        '
        Me.BuyerDataGridViewTextBoxColumn.DataPropertyName = "Buyer"
        Me.BuyerDataGridViewTextBoxColumn.HeaderText = "Buyer"
        Me.BuyerDataGridViewTextBoxColumn.Name = "BuyerDataGridViewTextBoxColumn"
        Me.BuyerDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SellerDataGridViewTextBoxColumn
        '
        Me.SellerDataGridViewTextBoxColumn.DataPropertyName = "Seller"
        Me.SellerDataGridViewTextBoxColumn.HeaderText = "Seller"
        Me.SellerDataGridViewTextBoxColumn.Name = "SellerDataGridViewTextBoxColumn"
        Me.SellerDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCommentsDataGridViewTextBoxColumn
        '
        Me.StrCommentsDataGridViewTextBoxColumn.DataPropertyName = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.HeaderText = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.Name = "StrCommentsDataGridViewTextBoxColumn"
        Me.StrCommentsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrHorseStatusDataGridViewTextBoxColumn
        '
        Me.StrHorseStatusDataGridViewTextBoxColumn.DataPropertyName = "strHorseStatus"
        Me.StrHorseStatusDataGridViewTextBoxColumn.HeaderText = "strHorseStatus"
        Me.StrHorseStatusDataGridViewTextBoxColumn.Name = "StrHorseStatusDataGridViewTextBoxColumn"
        Me.StrHorseStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VHorsesBindingSource
        '
        Me.VHorsesBindingSource.DataMember = "VHorses"
        Me.VHorsesBindingSource.DataSource = Me.CPDM_FoxLHorsesDS
        '
        'CPDM_FoxLHorsesDS
        '
        Me.CPDM_FoxLHorsesDS.DataSetName = "CPDM_FoxLHorsesDS"
        Me.CPDM_FoxLHorsesDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VHorsesTableAdapter
        '
        Me.VHorsesTableAdapter.ClearBeforeFill = True
        '
        'FManageHorses
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1208, 683)
        Me.Controls.Add(Me.dgvHorses)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblHorses)
        Me.Controls.Add(Me.lstHorses)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageHorses"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Horses & View the Data"
        CType(Me.dgvHorses, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VHorsesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLHorsesDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents lstHorses As System.Windows.Forms.ListBox
    Friend WithEvents lblHorses As System.Windows.Forms.Label
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvHorses As System.Windows.Forms.DataGridView
    Friend WithEvents CPDM_FoxLHorsesDS As CapstoneHorseApplication.CPDM_FoxLHorsesDS
    Friend WithEvents VHorsesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VHorsesTableAdapter As CapstoneHorseApplication.CPDM_FoxLHorsesDSTableAdapters.VHorsesTableAdapter
    Friend WithEvents IntHorseIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrBreedDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrRegistrationDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrColorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrSexDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrHeightDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BuyerDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SellerDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCommentsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrHorseStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
   

End Class
