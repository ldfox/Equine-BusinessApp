﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageFeedMiscExpenses
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvFeedMiscExpenses = New System.Windows.Forms.DataGridView()
        Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecExpenseCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteDatePurchasedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCommentsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VFeedMiscExpensesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLFeedMiscExpensesDS = New CapstoneHorseApplication.CPDM_FoxLFeedMiscExpensesDS()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lblFeedMiscExpenses = New System.Windows.Forms.Label()
        Me.lstFeedMiscExpenses = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.VFeedMiscExpensesTableAdapter = New CapstoneHorseApplication.CPDM_FoxLFeedMiscExpensesDSTableAdapters.VFeedMiscExpensesTableAdapter()
        CType(Me.dgvFeedMiscExpenses, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VFeedMiscExpensesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLFeedMiscExpensesDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.BackColor = System.Drawing.SystemColors.Menu
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvFeedMiscExpenses
        '
        Me.dgvFeedMiscExpenses.AllowUserToAddRows = False
        Me.dgvFeedMiscExpenses.AllowUserToDeleteRows = False
        Me.dgvFeedMiscExpenses.AutoGenerateColumns = False
        Me.dgvFeedMiscExpenses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvFeedMiscExpenses.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.DecExpenseCostDataGridViewTextBoxColumn, Me.DteDatePurchasedDataGridViewTextBoxColumn, Me.StrCommentsDataGridViewTextBoxColumn, Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn})
        Me.dgvFeedMiscExpenses.DataSource = Me.VFeedMiscExpensesBindingSource
        Me.dgvFeedMiscExpenses.Location = New System.Drawing.Point(27, 311)
        Me.dgvFeedMiscExpenses.Name = "dgvFeedMiscExpenses"
        Me.dgvFeedMiscExpenses.ReadOnly = True
        Me.dgvFeedMiscExpenses.RowTemplate.Height = 24
        Me.dgvFeedMiscExpenses.Size = New System.Drawing.Size(963, 344)
        Me.dgvFeedMiscExpenses.TabIndex = 6
        '
        'IntFeedMiscExpenseIDDataGridViewTextBoxColumn
        '
        Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn.DataPropertyName = "intFeedMiscExpenseID"
        Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn.HeaderText = "intFeedMiscExpenseID"
        Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn.Name = "IntFeedMiscExpenseIDDataGridViewTextBoxColumn"
        Me.IntFeedMiscExpenseIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecExpenseCostDataGridViewTextBoxColumn
        '
        Me.DecExpenseCostDataGridViewTextBoxColumn.DataPropertyName = "decExpenseCost"
        Me.DecExpenseCostDataGridViewTextBoxColumn.HeaderText = "decExpenseCost"
        Me.DecExpenseCostDataGridViewTextBoxColumn.Name = "DecExpenseCostDataGridViewTextBoxColumn"
        Me.DecExpenseCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteDatePurchasedDataGridViewTextBoxColumn
        '
        Me.DteDatePurchasedDataGridViewTextBoxColumn.DataPropertyName = "dteDatePurchased"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.HeaderText = "dteDatePurchased"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.Name = "DteDatePurchasedDataGridViewTextBoxColumn"
        Me.DteDatePurchasedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCommentsDataGridViewTextBoxColumn
        '
        Me.StrCommentsDataGridViewTextBoxColumn.DataPropertyName = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.HeaderText = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.Name = "StrCommentsDataGridViewTextBoxColumn"
        Me.StrCommentsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrFeedMiscExpenseStatusDataGridViewTextBoxColumn
        '
        Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn.DataPropertyName = "strFeedMiscExpenseStatus"
        Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn.HeaderText = "strFeedMiscExpenseStatus"
        Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn.Name = "StrFeedMiscExpenseStatusDataGridViewTextBoxColumn"
        Me.StrFeedMiscExpenseStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VFeedMiscExpensesBindingSource
        '
        Me.VFeedMiscExpensesBindingSource.DataMember = "VFeedMiscExpenses"
        Me.VFeedMiscExpensesBindingSource.DataSource = Me.CPDM_FoxLFeedMiscExpensesDS
        '
        'CPDM_FoxLFeedMiscExpensesDS
        '
        Me.CPDM_FoxLFeedMiscExpensesDS.DataSetName = "CPDM_FoxLFeedMiscExpensesDS"
        Me.CPDM_FoxLFeedMiscExpensesDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Menu
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(522, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(315, 36)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.BackColor = System.Drawing.SystemColors.Menu
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(291, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "status of 2 and may be undeleted any" & _
    " time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.BackColor = System.Drawing.SystemColors.Menu
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(522, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 10
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.BackColor = System.Drawing.SystemColors.Control
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(702, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.SystemColors.Control
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(366, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.BackColor = System.Drawing.SystemColors.Control
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = False
        '
        'lblFeedMiscExpenses
        '
        Me.lblFeedMiscExpenses.AutoSize = True
        Me.lblFeedMiscExpenses.BackColor = System.Drawing.SystemColors.Menu
        Me.lblFeedMiscExpenses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFeedMiscExpenses.Location = New System.Drawing.Point(25, 17)
        Me.lblFeedMiscExpenses.Name = "lblFeedMiscExpenses"
        Me.lblFeedMiscExpenses.Size = New System.Drawing.Size(194, 24)
        Me.lblFeedMiscExpenses.TabIndex = 9
        Me.lblFeedMiscExpenses.Text = "Feed/Misc Expenses:"
        '
        'lstFeedMiscExpenses
        '
        Me.lstFeedMiscExpenses.BackColor = System.Drawing.SystemColors.Menu
        Me.lstFeedMiscExpenses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstFeedMiscExpenses.FormattingEnabled = True
        Me.lstFeedMiscExpenses.ItemHeight = 22
        Me.lstFeedMiscExpenses.Location = New System.Drawing.Point(27, 40)
        Me.lstFeedMiscExpenses.Name = "lstFeedMiscExpenses"
        Me.lstFeedMiscExpenses.ScrollAlwaysVisible = True
        Me.lstFeedMiscExpenses.Size = New System.Drawing.Size(308, 224)
        Me.lstFeedMiscExpenses.Sorted = True
        Me.lstFeedMiscExpenses.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.SystemColors.Control
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'btnEdit
        '
        Me.btnEdit.BackColor = System.Drawing.SystemColors.Control
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = False
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.SystemColors.Control
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'VFeedMiscExpensesTableAdapter
        '
        Me.VFeedMiscExpensesTableAdapter.ClearBeforeFill = True
        '
        'FManageFeedMiscExpenses
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1018, 683)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.dgvFeedMiscExpenses)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblFeedMiscExpenses)
        Me.Controls.Add(Me.lstFeedMiscExpenses)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageFeedMiscExpenses"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Feed Misc Expenses & View the Data"
        CType(Me.dgvFeedMiscExpenses, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VFeedMiscExpensesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLFeedMiscExpensesDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvFeedMiscExpenses As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lblFeedMiscExpenses As System.Windows.Forms.Label
    Friend WithEvents lstFeedMiscExpenses As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents CPDM_FoxLFeedMiscExpensesDS As CapstoneHorseApplication.CPDM_FoxLFeedMiscExpensesDS
    Friend WithEvents VFeedMiscExpensesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VFeedMiscExpensesTableAdapter As CapstoneHorseApplication.CPDM_FoxLFeedMiscExpensesDSTableAdapters.VFeedMiscExpensesTableAdapter
    Friend WithEvents IntFeedMiscExpenseIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecExpenseCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteDatePurchasedDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCommentsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrFeedMiscExpenseStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
