﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageWestNileTests
' Abstract: Capstone Horse project- Manage the horses WestNileTests (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageWestNileTests


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadWestNileTestsList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the horse WestNileTests list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadWestNileTestsList
    ' Abstract: Load the horse WestNileTests list.
    ' --------------------------------------------------------------------------------
    Private Function LoadWestNileTestsList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveWestNileTests"

            Else

                strSourceTable = "VInActiveWestNileTests"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intWestNileTestID", _
                                                        "strName", _
                                                        lstWestNileTests)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse WestNileTest form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewWestNileTestInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddWestNileTest forms
            Dim frmAddWestNileTest As FAddWestNileTest

            ' Make an instance
            frmAddWestNileTest = New FAddWestNileTest

            ' Show modally
            frmAddWestNileTest.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddWestNileTest.GetResult() = True Then

                ' Get the new WestNileTest values
                liNewWestNileTestInformation = frmAddWestNileTest.GetNewWestNileTestInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstWestNileTests.Items.Add(liNewWestNileTestInformation)

                ' ... which we can use to select it
                lstWestNileTests.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse WestNileTest.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedWestNileTestID As Integer
            Dim liSelectedWestNileTest As CListItem
            Dim frmEditWestNileTest As FEditWestNileTest
            Dim liNewWestNileTestInformation As CListItem
            Dim intIndex As Integer

            ' Is a WestNileTest selected?
            If lstWestNileTests.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a WestNileTest to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the WestNileTest to edit ID
                liSelectedWestNileTest = lstWestNileTests.SelectedItem
                intSelectedWestNileTestID = liSelectedWestNileTest.GetID

                ' Create instance
                frmEditWestNileTest = New FEditWestNileTest

                ' Set the form values
                frmEditWestNileTest.SetWestNileTestID(intSelectedWestNileTestID)

                ' Show it modally   
                frmEditWestNileTest.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditWestNileTest.GetResult() = True Then

                    ' Get the new WestNileTest values
                    liNewWestNileTestInformation = frmEditWestNileTest.GetNewWestNileTestInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstWestNileTests.Items.RemoveAt(lstWestNileTests.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstWestNileTests.Items.Add(liNewWestNileTestInformation)

                    ' ... which we can use to select it
                    lstWestNileTests.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse WestNileTest.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteWestNileTest()

            Else

                ' No, undelete
                UndeleteWestNileTest()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteWestNileTest
    ' Abstract: Delete the currently selected WestNileTest.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteWestNileTest()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedWestNileTest As CListItem
            Dim intSelectedWestNileTestID As Integer
            Dim strSelectedWestNileTestName As String
            Dim intSelectedWestNileTestIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a WestNileTest selected?
            If lstWestNileTests.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a WestNile Test to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the WestNileTest ID, name and list index
                liSelectedWestNileTest = lstWestNileTests.SelectedItem
                intSelectedWestNileTestID = liSelectedWestNileTest.GetID
                strSelectedWestNileTestName = liSelectedWestNileTest.GetName
                intSelectedWestNileTestIndex = lstWestNileTests.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete horse WestNileTest: " & strSelectedWestNileTestName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the WestNileTest (use ID for database command)
                    blnResult = DeleteWestNileTestFromDatabase(intSelectedWestNileTestID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the WestNileTest from the list
                        lstWestNileTests.Items.RemoveAt(intSelectedWestNileTestIndex)

                        ' Select the next WestNileTest in the list
                        HighlightNextItemInList(lstWestNileTests, intSelectedWestNileTestIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteWestNileTest
    ' Abstract: Undelete the currently selected WestNileTest.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteWestNileTest()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedWestNileTest As CListItem
            Dim intSelectedWestNileTestID As Integer
            Dim intSelectedWestNileTestIndex As Integer
            Dim blnResult As Boolean

            ' Is a WestNileTest selected?
            If lstWestNileTests.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a horse WestNileTest to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the WestNileTest ID and list index
                liSelectedWestNileTest = lstWestNileTests.SelectedItem
                intSelectedWestNileTestID = liSelectedWestNileTest.GetID
                intSelectedWestNileTestIndex = lstWestNileTests.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the WestNileTest (use ID for database command)
                blnResult = UndeleteWestNileTestFromDatabase(intSelectedWestNileTestID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the WestNileTest from the list
                    lstWestNileTests.Items.RemoveAt(intSelectedWestNileTestIndex)

                    ' Select the next WestNileTest in the list
                    HighlightNextItemInList(lstWestNileTests, intSelectedWestNileTestIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the WestNileTests list
            LoadWestNileTestsList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VWestNileTestsTableAdapter.Fill(Me.CPDM_FoxLWestNileTestsDS.VWestNileTests)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageWestNileTests_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLWestNileTestsDS.VWestNileTests' table.
    '    Me.VWestNileTestsTableAdapter.Fill(Me.CPDM_FoxLWestNileTestsDS.VWestNileTests)

    'End Sub
End Class