﻿' Name: Laurie Fox - FAddHorse
' Abstract: Capstone Horse Project - Manage Horse (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddHorse


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHorseID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddHorse_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddHorse_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("THorseBreeds", "intBreedID", "strBreed", cmbBreed)
            ModDatabaseUtilities.LoadComboBoxFromDatabase("THorseColors", "intColorID", "strColor", cmbColor)
            ModDatabaseUtilities.LoadComboBoxFromDatabase("THorseSexes", "intSexID", "strSex", cmbSex)
            ModDatabaseUtilities.LoadComboBoxFromDatabase("THorseBuyers", "intHorseBuyerID", "strFullName ", cmbBuyer)
            ModDatabaseUtilities.LoadComboBoxFromDatabase("THorseSellers", "intHorseSellerID", "strFullName", cmbSeller)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Horse to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Horse to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewHorse As New udtHorseType

            ' Get values from form
            udtNewHorse = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            'blnResult = AddHorseToDatabaseMSAccess(udtNewHorse)
            blnResult = AddHorseToDatabase2(udtNewHorse)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new Horse ID that's currently in the suitcase
                f_intHorseID = udtNewHorse.intHorseID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHorseType

        Dim udtHorse As New udtHorseType

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedBreedID As Integer
            Dim liSelectedBreed As CListItem
            Dim intSelectedColorID As Integer
            Dim liSelectedColor As CListItem
            Dim intSelectedSexID As Integer
            Dim liSelectedSex As CListItem
            Dim intSelectedBuyerID As Integer
            Dim liSelectedBuyer As CListItem
            Dim intSelectedSellerID As Integer
            Dim liSelectedSeller As CListItem


            ' Load up with data from the form

            'Name 
            udtHorse.strName = txtName.Text

            ' Breed
            liSelectedBreed = cmbBreed.SelectedItem
            intSelectedBreedID = liSelectedBreed.GetID
            udtHorse.intBreedID = intSelectedBreedID

            ' Registration
            udtHorse.strRegistration = cmbRegistration.Text

            ' Color
            liSelectedColor = cmbColor.SelectedItem
            intSelectedColorID = liSelectedColor.GetID
            udtHorse.intColorID = intSelectedColorID

            ' Sex
            liSelectedSex = cmbSex.SelectedItem
            intSelectedSexID = liSelectedSex.GetID
            udtHorse.intSexID = intSelectedSexID

            ' Height
            udtHorse.strHeight = txtHeight.Text

            ' Buyer
            liSelectedBuyer = cmbBuyer.SelectedItem
            intSelectedBuyerID = liSelectedBuyer.GetID
            udtHorse.intHorseBuyerID = intSelectedBuyerID

            ' Seller
            liSelectedSeller = cmbSeller.SelectedItem
            intSelectedSellerID = liSelectedSeller.GetID
            udtHorse.intHorseSellerID = intSelectedSellerID

            ' Home phone number
            udtHorse.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHorse

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHorseInformation
    ' Abstract: Get the new Horse information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHorseInformation() As CListItem

        Dim liHorse As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liHorse = New CListItem(f_intHorseID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHorse

    End Function

End Class