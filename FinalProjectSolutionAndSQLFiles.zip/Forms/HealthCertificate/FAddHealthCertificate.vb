﻿' Name: Laurie Fox - FAddHealthCertificate
' Abstract: Capstone Horse Project - Manage Health Certificate (Add)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off  ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAddHealthCertificate


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intHealthCertificateID As Integer
    Private f_blnResult As Boolean


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAddHealthCertificate_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAddHealthCertificate_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the HealthCertificate to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add HealthCertificate to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' HealthCertificate Date
            If txtHealthCertificateDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-HealthCertificate date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtHealthCertificateDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtHealthCertificateDate.Text) = False Then

                    strErrorMessage &= "-HealthCertificate date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' HealthCertificate Cost
            If txtHealthCertificateCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtHealthCertificateCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtNewHealthCertificate As New udtHealthCertificateType

            ' Get values from form
            udtNewHealthCertificate = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = AddHealthCertificateToDatabase2(udtNewHealthCertificate)

            ' Was the add to database successful?
            If blnResult = True Then

                ' Yes, then save the new HealthCertificate ID that's currently in the suitcase
                f_intHealthCertificateID = udtNewHealthCertificate.intHealthCertificateID

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtHealthCertificateType

        Dim udtHealthCertificate As New udtHealthCertificateType

        ' Try/Catch with WriteLog
        Try

            Dim strHealthCertificateCost As String

            ' Load up with data from the form
            'Name 
            udtHealthCertificate.strName = txtName.Text

            ' HealthCertificate Date
            ' Boundary check - if textbox is empty
            If txtHealthCertificateDate.Text = "" Then

                ' Then insert date
                udtHealthCertificate.dteHealthCertificateDate = "1800/01/01"

            Else

                ' Else txtHealthCertificateDate has a value
                udtHealthCertificate.dteHealthCertificateDate = txtHealthCertificateDate.Text

            End If

            ' HealthCertificate Cost - Remove dollar signs and commas
            strHealthCertificateCost = txtHealthCertificateCost.Text
            strHealthCertificateCost = strHealthCertificateCost.Replace("$", "")
            strHealthCertificateCost = strHealthCertificateCost.Replace(",", "")
            udtHealthCertificate.decHealthCertificateCost = Val(strHealthCertificateCost)

            ' Comments
            udtHealthCertificate.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtHealthCertificate

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewHealthCertificateInformation
    ' Abstract: Get the new HealthCertificate information
    ' --------------------------------------------------------------------------------
    Public Function GetNewHealthCertificateInformation() As CListItem

        Dim liHealthCertificate As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liHealthCertificate = New CListItem(f_intHealthCertificateID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liHealthCertificate

    End Function

End Class