﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageEquipment
' Abstract: Capstone Horse project- Manage the Equipment (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageEquipment



    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadEquipmentList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the Equipment list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadEquipmentList
    ' Abstract: Load the horse Equipment list.
    ' --------------------------------------------------------------------------------
    Private Function LoadEquipmentList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveEquipment"

            Else

                strSourceTable = "VInActiveEquipment"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intEquipmentID", _
                                                        "strName", _
                                                        lstEquipment)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse Equipment form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewEquipmentInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddEquipment forms
            Dim frmAddEquipment As FAddEquipment

            ' Make an instance
            frmAddEquipment = New FAddEquipment

            ' Show modally
            frmAddEquipment.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddEquipment.GetResult() = True Then

                ' Get the new Equipment values
                liNewEquipmentInformation = frmAddEquipment.GetNewEquipmentInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstEquipment.Items.Add(liNewEquipmentInformation)

                ' ... which we can use to select it
                lstEquipment.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedEquipmentID As Integer
            Dim liSelectedEquipment As CListItem
            Dim frmEditEquipment As FEditEquipment
            Dim liNewEquipmentInformation As CListItem
            Dim intIndex As Integer

            ' Is a Equipment selected?
            If lstEquipment.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Equipment to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the Equipment to edit ID
                liSelectedEquipment = lstEquipment.SelectedItem
                intSelectedEquipmentID = liSelectedEquipment.GetID

                ' Create instance
                frmEditEquipment = New FEditEquipment

                ' Set the form values
                frmEditEquipment.SetEquipmentID(intSelectedEquipmentID)

                ' Show it modally   
                frmEditEquipment.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditEquipment.GetResult() = True Then

                    ' Get the new Equipment values
                    liNewEquipmentInformation = frmEditEquipment.GetNewEquipmentInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstEquipment.Items.RemoveAt(lstEquipment.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstEquipment.Items.Add(liNewEquipmentInformation)

                    ' ... which we can use to select it
                    lstEquipment.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteEquipment()

            Else

                ' No, undelete
                UndeleteEquipment()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteEquipment
    ' Abstract: Delete the currently selected Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteEquipment()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedEquipment As CListItem
            Dim intSelectedEquipmentID As Integer
            Dim strSelectedEquipmentName As String
            Dim intSelectedEquipmentIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Equipment selected?
            If lstEquipment.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Equipment to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Equipment ID, name and list index
                liSelectedEquipment = lstEquipment.SelectedItem
                intSelectedEquipmentID = liSelectedEquipment.GetID
                strSelectedEquipmentName = liSelectedEquipment.GetName
                intSelectedEquipmentIndex = lstEquipment.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Equipment: " & strSelectedEquipmentName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Equipment (use ID for database command)
                    blnResult = DeleteEquipmentFromDatabase(intSelectedEquipmentID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Equipment from the list
                        lstEquipment.Items.RemoveAt(intSelectedEquipmentIndex)

                        ' Select the next Equipment in the list
                        HighlightNextItemInList(lstEquipment, intSelectedEquipmentIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteEquipment
    ' Abstract: Undelete the currently selected Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteEquipment()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedEquipment As CListItem
            Dim intSelectedEquipmentID As Integer
            Dim intSelectedEquipmentIndex As Integer
            Dim blnResult As Boolean

            ' Is a Equipment selected?
            If lstEquipment.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Equipment to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Equipment ID and list index
                liSelectedEquipment = lstEquipment.SelectedItem
                intSelectedEquipmentID = liSelectedEquipment.GetID
                intSelectedEquipmentIndex = lstEquipment.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Equipment (use ID for database command)
                blnResult = UndeleteEquipmentFromDatabase(intSelectedEquipmentID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Equipment from the list
                    lstEquipment.Items.RemoveAt(intSelectedEquipmentIndex)

                    ' Select the next Equipment in the list
                    HighlightNextItemInList(lstEquipment, intSelectedEquipmentIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Equipment list
            LoadEquipmentList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VEquipmentTableAdapter.Fill(Me.CPDM_FoxLEquipmentDS.VEquipment)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageEquipment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLEquipmentDS.VEquipment' table.
    '    Me.VEquipmentTableAdapter.Fill(Me.CPDM_FoxLEquipmentDS.VEquipment)

    'End Sub

End Class