﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageHealthCertificates
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvHealthCertificates = New System.Windows.Forms.DataGridView()
        Me.IntHealthCertificateIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteHealthCertificateDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecHealthCertificateCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCommentsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrHealthCertificateStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VHealthCertificatesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLHealthCertificatesDS = New CapstoneHorseApplication.CPDM_FoxLHealthCertificatesDS()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lblHealthCertificates = New System.Windows.Forms.Label()
        Me.lstHealthCertificates = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.VHealthCertificatesTableAdapter = New CapstoneHorseApplication.CPDM_FoxLHealthCertificatesDSTableAdapters.VHealthCertificatesTableAdapter()
        CType(Me.dgvHealthCertificates, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VHealthCertificatesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLHealthCertificatesDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 7
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvHealthCertificates
        '
        Me.dgvHealthCertificates.AllowUserToAddRows = False
        Me.dgvHealthCertificates.AllowUserToDeleteRows = False
        Me.dgvHealthCertificates.AutoGenerateColumns = False
        Me.dgvHealthCertificates.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHealthCertificates.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntHealthCertificateIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.DteHealthCertificateDateDataGridViewTextBoxColumn, Me.DecHealthCertificateCostDataGridViewTextBoxColumn, Me.StrCommentsDataGridViewTextBoxColumn, Me.StrHealthCertificateStatusDataGridViewTextBoxColumn})
        Me.dgvHealthCertificates.DataSource = Me.VHealthCertificatesBindingSource
        Me.dgvHealthCertificates.Location = New System.Drawing.Point(27, 312)
        Me.dgvHealthCertificates.Name = "dgvHealthCertificates"
        Me.dgvHealthCertificates.ReadOnly = True
        Me.dgvHealthCertificates.RowTemplate.Height = 24
        Me.dgvHealthCertificates.Size = New System.Drawing.Size(963, 347)
        Me.dgvHealthCertificates.TabIndex = 6
        '
        'IntHealthCertificateIDDataGridViewTextBoxColumn
        '
        Me.IntHealthCertificateIDDataGridViewTextBoxColumn.DataPropertyName = "intHealthCertificateID"
        Me.IntHealthCertificateIDDataGridViewTextBoxColumn.HeaderText = "intHealthCertificateID"
        Me.IntHealthCertificateIDDataGridViewTextBoxColumn.Name = "IntHealthCertificateIDDataGridViewTextBoxColumn"
        Me.IntHealthCertificateIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteHealthCertificateDateDataGridViewTextBoxColumn
        '
        Me.DteHealthCertificateDateDataGridViewTextBoxColumn.DataPropertyName = "dteHealthCertificateDate"
        Me.DteHealthCertificateDateDataGridViewTextBoxColumn.HeaderText = "dteHealthCertificateDate"
        Me.DteHealthCertificateDateDataGridViewTextBoxColumn.Name = "DteHealthCertificateDateDataGridViewTextBoxColumn"
        Me.DteHealthCertificateDateDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecHealthCertificateCostDataGridViewTextBoxColumn
        '
        Me.DecHealthCertificateCostDataGridViewTextBoxColumn.DataPropertyName = "decHealthCertificateCost"
        Me.DecHealthCertificateCostDataGridViewTextBoxColumn.HeaderText = "decHealthCertificateCost"
        Me.DecHealthCertificateCostDataGridViewTextBoxColumn.Name = "DecHealthCertificateCostDataGridViewTextBoxColumn"
        Me.DecHealthCertificateCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCommentsDataGridViewTextBoxColumn
        '
        Me.StrCommentsDataGridViewTextBoxColumn.DataPropertyName = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.HeaderText = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.Name = "StrCommentsDataGridViewTextBoxColumn"
        Me.StrCommentsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrHealthCertificateStatusDataGridViewTextBoxColumn
        '
        Me.StrHealthCertificateStatusDataGridViewTextBoxColumn.DataPropertyName = "strHealthCertificateStatus"
        Me.StrHealthCertificateStatusDataGridViewTextBoxColumn.HeaderText = "strHealthCertificateStatus"
        Me.StrHealthCertificateStatusDataGridViewTextBoxColumn.Name = "StrHealthCertificateStatusDataGridViewTextBoxColumn"
        Me.StrHealthCertificateStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VHealthCertificatesBindingSource
        '
        Me.VHealthCertificatesBindingSource.DataMember = "VHealthCertificates"
        Me.VHealthCertificatesBindingSource.DataSource = Me.CPDM_FoxLHealthCertificatesDS
        '
        'CPDM_FoxLHealthCertificatesDS
        '
        Me.CPDM_FoxLHealthCertificatesDS.DataSetName = "CPDM_FoxLHealthCertificatesDS"
        Me.CPDM_FoxLHealthCertificatesDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(522, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(315, 36)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(291, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "status of 2 and may be undeleted any" & _
    " time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(522, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 10
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(702, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(366, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'lblHealthCertificates
        '
        Me.lblHealthCertificates.AutoSize = True
        Me.lblHealthCertificates.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHealthCertificates.Location = New System.Drawing.Point(25, 17)
        Me.lblHealthCertificates.Name = "lblHealthCertificates"
        Me.lblHealthCertificates.Size = New System.Drawing.Size(164, 24)
        Me.lblHealthCertificates.TabIndex = 9
        Me.lblHealthCertificates.Text = "Health Certificates:"
        '
        'lstHealthCertificates
        '
        Me.lstHealthCertificates.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstHealthCertificates.FormattingEnabled = True
        Me.lstHealthCertificates.ItemHeight = 22
        Me.lstHealthCertificates.Location = New System.Drawing.Point(27, 40)
        Me.lstHealthCertificates.Name = "lstHealthCertificates"
        Me.lstHealthCertificates.ScrollAlwaysVisible = True
        Me.lstHealthCertificates.Size = New System.Drawing.Size(308, 224)
        Me.lstHealthCertificates.Sorted = True
        Me.lstHealthCertificates.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'VHealthCertificatesTableAdapter
        '
        Me.VHealthCertificatesTableAdapter.ClearBeforeFill = True
        '
        'FManageHealthCertificates
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1018, 683)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.dgvHealthCertificates)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblHealthCertificates)
        Me.Controls.Add(Me.lstHealthCertificates)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageHealthCertificates"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Health Certificates & View the Data"
        CType(Me.dgvHealthCertificates, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VHealthCertificatesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLHealthCertificatesDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvHealthCertificates As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lblHealthCertificates As System.Windows.Forms.Label
    Friend WithEvents lstHealthCertificates As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents CPDM_FoxLHealthCertificatesDS As CapstoneHorseApplication.CPDM_FoxLHealthCertificatesDS
    Friend WithEvents VHealthCertificatesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VHealthCertificatesTableAdapter As CapstoneHorseApplication.CPDM_FoxLHealthCertificatesDSTableAdapters.VHealthCertificatesTableAdapter
    Friend WithEvents IntHealthCertificateIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteHealthCertificateDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecHealthCertificateCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCommentsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrHealthCertificateStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
