﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditVaccinations
' Abstract: Capstone Horse project - Edit horse Vaccinations (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditVaccination


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intVaccinationID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetVaccinationID
    ' Abstract: What Vaccination are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetVaccinationID(ByVal intVaccinationID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' Vaccination ID
            f_intVaccinationID = intVaccinationID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditVaccination_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditVaccination_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtVaccination As udtVaccinationType

            ' Make a suitcase instace
            udtVaccination = New udtVaccinationType

            ' Set the ID
            udtVaccination.intVaccinationID = f_intVaccinationID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetVaccinationInformationFromDatabase(udtVaccination) = True Then

                With udtVaccination

                    txtName.Text = .strName
                    txtVaccinationCost.Text = .decVaccinationCost.ToString("c")
                    txtVaccinationCost.Text = .decVaccinationCost.ToString("c2")  ' Currency with 2 decimal points
                    txtVaccinationCost.Text = FormatCurrency(.decVaccinationCost)

                    If .dteVaccinationDate <> "1800/01/01" Then

                        txtVaccinationDate.Text = .dteVaccinationDate.ToString("yyyy/MM/dd")

                    End If

                    txtComments.Text = .strComments

                End With

            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for Vaccination to edit." & vbNewLine & _
                                "The form will now close.", "Edit Vaccination Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the Vaccination to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add Vaccination to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If

            ' Vaccination Cost
            If txtVaccinationCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtVaccinationCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Vaccination Date
            If txtVaccinationDate.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Vaccination date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtVaccinationDate.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtVaccinationDate.Text) = False Then

                    strErrorMessage &= "-Vaccination date is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtVaccination As New udtVaccinationType

            ' Load it up with data from the form
            udtVaccination = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditVaccinationInDatabase2(udtVaccination)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtVaccinationType

        Dim udtVaccination As New udtVaccinationType

        ' Try/Catch with WriteLog
        Try

            Dim strVaccinationCost As String

            ' Load up with data from the form
            ' ID
            udtVaccination.intVaccinationID = f_intVaccinationID

            'Name 
            udtVaccination.strName = txtName.Text

            ' Farrier Cost - Remove dollar signs and commas
            strVaccinationCost = txtVaccinationCost.Text
            strVaccinationCost = strVaccinationCost.Replace("$", "")
            strVaccinationCost = strVaccinationCost.Replace(",", "")
            udtVaccination.decVaccinationCost = Val(strVaccinationCost)

            ' Vaccination Date
            ' Boundary check - if textbox is empty
            If txtVaccinationDate.Text = "" Then

                ' Then insert date
                udtVaccination.dteVaccinationDate = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtVaccination.dteVaccinationDate = txtVaccinationDate.Text

            End If

            ' Comments
            udtVaccination.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtVaccination

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewVaccinationInformation
    ' Abstract: Get the new Vaccination information
    ' --------------------------------------------------------------------------------
    Public Function GetNewVaccinationInformation() As CListItem

        Dim liVaccination As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liVaccination = New CListItem(f_intVaccinationID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liVaccination

    End Function

End Class