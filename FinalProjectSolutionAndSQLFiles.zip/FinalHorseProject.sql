-- Name: Laurie Fox
-- Class: CPDM - Final project
-- Abstract: Phase 3 - SQL script
-- --------------------------------------------------------------------------------

-- --------------------------------------------------------------------------------
-- Options
-- --------------------------------------------------------------------------------
SET NOCOUNT ON      -- Report only errors


-- --------------------------------------------------------------------------------
-- Step #1: Create statements
-- --------------------------------------------------------------------------------
GO

	-- Drop tables, stored procedures, and views if they are NOT NULL

	-- DROP TABLES

IF OBJECT_ID( 'TEquipmentMaintenance' )								IS NOT NULL DROP TABLE		TEquipmentMaintenance
IF OBJECT_ID( 'TMaintenance' )										IS NOT NULL DROP TABLE		TMaintenance
IF OBJECT_ID( 'TMaintenanceStatuses' )								IS NOT NULL DROP TABLE		TMaintenanceStatuses
IF OBJECT_ID( 'TEquipment' )										IS NOT NULL DROP TABLE		TEquipment
IF OBJECT_ID( 'TEquipmentStatuses' )								IS NOT NULL DROP TABLE		TEquipmentStatuses
IF OBJECT_ID( 'TFeedMiscExpenses' )									IS NOT NULL DROP TABLE		TFeedMiscExpenses
IF OBJECT_ID( 'TFeedMiscExpenseStatuses' )							IS NOT NULL DROP TABLE		TFeedMiscExpenseStatuses
IF OBJECT_ID( 'THorseHealthCertificates' )							IS NOT NULL DROP TABLE		THorseHealthCertificates
IF OBJECT_ID( 'THealthCertificates' )								IS NOT NULL DROP TABLE		THealthCertificates
IF OBJECT_ID( 'THealthCertificateStatuses' )						IS NOT NULL DROP TABLE		THealthCertificateStatuses
IF OBJECT_ID( 'THorseDewormers' )									IS NOT NULL DROP TABLE		THorseDewormers
IF OBJECT_ID( 'TDewormers' )										IS NOT NULL DROP TABLE		TDewormers
IF OBJECT_ID( 'TDewormerStatuses' )									IS NOT NULL DROP TABLE		TDewormerStatuses
IF OBJECT_ID( 'THorseWestNileTests' )								IS NOT NULL DROP TABLE		THorseWestNileTests
IF OBJECT_ID( 'TWestNileTests' )									IS NOT NULL DROP TABLE		TWestNileTests
IF OBJECT_ID( 'TWestNileTestStatuses' )								IS NOT NULL DROP TABLE		TWestNileTestStatuses
IF OBJECT_ID( 'THorseVaccinations' )								IS NOT NULL DROP TABLE		THorseVaccinations
IF OBJECT_ID( 'TVaccinations' )										IS NOT NULL DROP TABLE		TVaccinations
IF OBJECT_ID( 'TVaccinationStatuses' )								IS NOT NULL DROP TABLE		TVaccinationStatuses
IF OBJECT_ID( 'THorseShoes' )										IS NOT NULL DROP TABLE		THorseShoes
IF OBJECT_ID( 'TShoes' )											IS NOT NULL DROP TABLE		TShoes
IF OBJECT_ID( 'TShoeStatuses' )										IS NOT NULL DROP TABLE		TShoeStatuses
IF OBJECT_ID( 'THorses' )											IS NOT NULL DROP TABLE		THorses
IF OBJECT_ID( 'THorseBreeds' )										IS NOT NULL DROP TABLE		THorseBreeds
IF OBJECT_ID( 'THorseColors' )										IS NOT NULL DROP TABLE		THorseColors
IF OBJECT_ID( 'THorseSexes' )										IS NOT NULL DROP TABLE		THorseSexes
IF OBJECT_ID( 'THorseBuyers' )										IS NOT NULL DROP TABLE		THorseBuyers
IF OBJECT_ID( 'THorseSellers' )										IS NOT NULL DROP TABLE		THorseSellers
IF OBJECT_ID( 'THorseBuyerStatuses' )								IS NOT NULL DROP TABLE		THorseBuyerStatuses
IF OBJECT_ID( 'THorseSellerStatuses' )								IS NOT NULL DROP TABLE		THorseSellerStatuses
IF OBJECT_ID( 'TStates' )											IS NOT NULL DROP TABLE		TStates
IF OBJECT_ID( 'THorseStatuses' )									IS NOT NULL DROP TABLE		THorseStatuses

		-- DROP STORED PROCEDURES  -- 'ADD, ADD ALL, REMOVE, REMOVE ALL'

IF OBJECT_ID( 'uspRemoveAllHorseShoes' )							IS NOT NULL DROP PROCEDURE	uspRemoveAllHorseShoes
IF OBJECT_ID( 'uspRemoveHorseShoe' )								IS NOT NULL DROP PROCEDURE	uspRemoveHorseShoe
IF OBJECT_ID( 'uspAddAllAvailableShoesToHorse' )					IS NOT NULL DROP PROCEDURE	uspAddAllAvailableShoesToHorse
IF OBJECT_ID( 'uspAddHorseShoe' )									IS NOT NULL DROP PROCEDURE	uspAddHorseShoe

IF OBJECT_ID( 'uspRemoveAllHorseVaccinations' )						IS NOT NULL DROP PROCEDURE	uspRemoveAllHorseVaccinations
IF OBJECT_ID( 'uspRemoveHorseVaccination' )							IS NOT NULL DROP PROCEDURE	uspRemoveHorseVaccination
IF OBJECT_ID( 'uspAddAllAvailableVaccinationsToHorse' )				IS NOT NULL DROP PROCEDURE	uspAddAllAvailableVaccinationsToHorse
IF OBJECT_ID( 'uspAddHorseVaccination' )							IS NOT NULL DROP PROCEDURE	uspAddHorseVaccination

IF OBJECT_ID( 'uspRemoveAllHorseWestNileTests' )					IS NOT NULL DROP PROCEDURE	uspRemoveAllHorseWestNileTests
IF OBJECT_ID( 'uspRemoveHorseWestNileTest' )						IS NOT NULL DROP PROCEDURE	uspRemoveHorseWestNileTest
IF OBJECT_ID( 'uspAddAllAvailableWestNileTestsToHorse' )			IS NOT NULL DROP PROCEDURE	uspAddAllAvailableWestNileTestsToHorse
IF OBJECT_ID( 'uspAddHorseWestNileTest' )							IS NOT NULL DROP PROCEDURE	uspAddHorseWestNileTest

IF OBJECT_ID( 'uspRemoveAllHorseDewormers' )						IS NOT NULL DROP PROCEDURE	uspRemoveAllHorseDewormers
IF OBJECT_ID( 'uspRemoveHorseDewormer' )							IS NOT NULL DROP PROCEDURE	uspRemoveHorseDewormer
IF OBJECT_ID( 'uspAddAllAvailableDewormersToHorse' )				IS NOT NULL DROP PROCEDURE	uspAddAllAvailableDewormersToHorse
IF OBJECT_ID( 'uspAddHorseDewormer' )								IS NOT NULL DROP PROCEDURE	uspAddHorseDewormer

IF OBJECT_ID( 'uspRemoveAllHorseHealthCertificates' )				IS NOT NULL DROP PROCEDURE	uspRemoveAllHorseHealthCertificates
IF OBJECT_ID( 'uspRemoveHorseHealthCertificate' )					IS NOT NULL DROP PROCEDURE	uspRemoveHorseHealthCertificate
IF OBJECT_ID( 'uspAddAllAvailableHealthCertificatesToHorse' )		IS NOT NULL DROP PROCEDURE	uspAddAllAvailableHealthCertificatesToHorse
IF OBJECT_ID( 'uspAddHorseHealthCertificate' )						IS NOT NULL DROP PROCEDURE	uspAddHorseHealthCertificate

IF OBJECT_ID( 'uspRemoveAllEquipmentMaintenance' )					IS NOT NULL DROP PROCEDURE	uspRemoveAllEquipmentMaintenance
IF OBJECT_ID( 'uspRemoveEquipmentMaintenance' )						IS NOT NULL DROP PROCEDURE	uspRemoveEquipmentMaintenance
IF OBJECT_ID( 'uspAddAllAvailableMaintenanceToEquipment' )	IS NOT NULL DROP PROCEDURE	uspAddAllAvailableMaintenanceToEquipment
IF OBJECT_ID( 'uspAddEquipmentMaintenance' )						IS NOT NULL DROP PROCEDURE	uspAddEquipmentMaintenance

				-- STORED PROCEDURES -- 'SET, ADD, EDIT'

IF OBJECT_ID( 'uspSetHorseBuyerStatus' )							IS NOT NULL DROP PROCEDURE	uspSetHorseBuyerStatus
IF OBJECT_ID( 'uspAddHorseBuyer' )									IS NOT NULL DROP PROCEDURE	uspAddHorseBuyer
IF OBJECT_ID( 'uspEditHorseBuyer' )									IS NOT NULL DROP PROCEDURE	uspEditHorseBuyer

IF OBJECT_ID( 'uspSetHorseSellerStatus' )							IS NOT NULL DROP PROCEDURE	uspSetHorseSellerStatus
IF OBJECT_ID( 'uspAddHorseSeller' )									IS NOT NULL DROP PROCEDURE	uspAddHorseSeller
IF OBJECT_ID( 'uspEditHorseSeller' )								IS NOT NULL DROP PROCEDURE	uspEditHorseSeller

IF OBJECT_ID( 'uspSetHorseStatus' )									IS NOT NULL DROP PROCEDURE	uspSetHorseStatus
IF OBJECT_ID( 'uspAddHorse' )										IS NOT NULL DROP PROCEDURE	uspAddHorse
IF OBJECT_ID( 'uspEditHorse' )										IS NOT NULL DROP PROCEDURE	uspEditHorse

IF OBJECT_ID( 'uspSetShoeStatus' )									IS NOT NULL DROP PROCEDURE	uspSetShoeStatus
IF OBJECT_ID( 'uspAddShoes' )										IS NOT NULL DROP PROCEDURE	uspAddShoes
IF OBJECT_ID( 'uspEditShoes' )										IS NOT NULL DROP PROCEDURE	uspEditShoes

IF OBJECT_ID( 'uspSetVaccinationStatus' )							IS NOT NULL DROP PROCEDURE	uspSetVaccinationStatus
IF OBJECT_ID( 'uspAddVaccinations' )								IS NOT NULL DROP PROCEDURE	uspAddVaccinations
IF OBJECT_ID( 'uspEditVaccinations' )								IS NOT NULL DROP PROCEDURE	uspEditVaccinations

IF OBJECT_ID( 'uspSetWestNileTestStatus' )							IS NOT NULL DROP PROCEDURE	uspSetWestNileTestStatus
IF OBJECT_ID( 'uspAddWestNileTests' )								IS NOT NULL DROP PROCEDURE	uspAddWestNileTests
IF OBJECT_ID( 'uspEditWestNileTests' )								IS NOT NULL DROP PROCEDURE	uspEditWestNileTests

IF OBJECT_ID( 'uspSetDewormerStatus' )								IS NOT NULL DROP PROCEDURE	uspSetDewormerStatus
IF OBJECT_ID( 'uspAddDewormers' )									IS NOT NULL DROP PROCEDURE	uspAddDewormers
IF OBJECT_ID( 'uspEditDewormers' )									IS NOT NULL DROP PROCEDURE	uspEditDewormers

IF OBJECT_ID( 'uspSetHealthCertificateStatus' )						IS NOT NULL DROP PROCEDURE	uspSetHealthCertificateStatus
IF OBJECT_ID( 'uspAddHealthCertificates' )							IS NOT NULL DROP PROCEDURE	uspAddHealthCertificates
IF OBJECT_ID( 'uspEditHealthCertificates' )							IS NOT NULL DROP PROCEDURE	uspEditHealthCertificates

IF OBJECT_ID( 'uspSetFeedMiscExpenseStatus' )						IS NOT NULL DROP PROCEDURE	uspSetFeedMiscExpenseStatus
IF OBJECT_ID( 'uspAddFeedMiscExpenses' )							IS NOT NULL DROP PROCEDURE	uspAddFeedMiscExpenses
IF OBJECT_ID( 'uspEditFeedMiscExpenses' )							IS NOT NULL DROP PROCEDURE	uspEditFeedMiscExpenses

IF OBJECT_ID( 'uspSetEquipmentStatus' )								IS NOT NULL DROP PROCEDURE	uspSetEquipmentStatus
IF OBJECT_ID( 'uspAddEquipment' )									IS NOT NULL DROP PROCEDURE	uspAddEquipment
IF OBJECT_ID( 'uspEditEquipment' )									IS NOT NULL DROP PROCEDURE	uspEditEquipment

IF OBJECT_ID( 'uspSetMaintenanceStatus' )							IS NOT NULL DROP PROCEDURE	uspSetMaintenanceStatus
IF OBJECT_ID( 'uspAddMaintenance' )									IS NOT NULL DROP PROCEDURE	uspAddMaintenance
IF OBJECT_ID( 'uspEditMaintenance' )								IS NOT NULL DROP PROCEDURE	uspEditMaintenance

			-- DROP VIEWS -- 'ACTIVE, INACTIVE & VIEWS FOR DATAGRIDVIEW'

IF OBJECT_ID( 'VActiveHorseBuyers' )								IS NOT NULL DROP VIEW  VActiveHorseBuyers
IF OBJECT_ID( 'VInActiveHorseBuyers' )								IS NOT NULL DROP VIEW  VInActiveHorseBuyers
IF OBJECT_ID( 'VHorseBuyers' )										IS NOT NULL DROP VIEW  VHorseBuyers

IF OBJECT_ID( 'VActiveHorseSellers' )								IS NOT NULL DROP VIEW  VActiveHorseSellers
IF OBJECT_ID( 'VInActiveHorseSellers' )								IS NOT NULL DROP VIEW  VInActiveHorseSellers
IF OBJECT_ID( 'VHorseSellers' )										IS NOT NULL DROP VIEW  VHorseSellers

IF OBJECT_ID( 'VActiveHorses' )										IS NOT NULL DROP VIEW  VActiveHorses
IF OBJECT_ID( 'VInActiveHorses' )									IS NOT NULL DROP VIEW  VInActiveHorses
IF OBJECT_ID( 'VHorses' )											IS NOT NULL DROP VIEW  VHorses

IF OBJECT_ID( 'VActiveShoes' )										IS NOT NULL DROP VIEW  VActiveShoes
IF OBJECT_ID( 'VInActiveShoes' )									IS NOT NULL DROP VIEW  VInActiveShoes
IF OBJECT_ID( 'VShoes' )											IS NOT NULL DROP VIEW  VShoes

IF OBJECT_ID( 'VActiveVaccinations' )								IS NOT NULL DROP VIEW  VActiveVaccinations
IF OBJECT_ID( 'VInActiveVaccinations' )								IS NOT NULL DROP VIEW  VInActiveVaccinations
IF OBJECT_ID( 'VVaccinations' )										IS NOT NULL DROP VIEW  VVaccinations

IF OBJECT_ID( 'VActiveWestNileTests' )								IS NOT NULL DROP VIEW  VActiveWestNileTests
IF OBJECT_ID( 'VInActiveWestNileTests' )							IS NOT NULL DROP VIEW  VInActiveWestNileTests
IF OBJECT_ID( 'VWestNileTests' )									IS NOT NULL DROP VIEW  VWestNileTests

IF OBJECT_ID( 'VActiveDewormers' )									IS NOT NULL DROP VIEW  VActiveDewormers
IF OBJECT_ID( 'VInActiveDewormers' )								IS NOT NULL DROP VIEW  VInActiveDewormers
IF OBJECT_ID( 'VDewormers' )										IS NOT NULL DROP VIEW  VDewormers

IF OBJECT_ID( 'VActiveHealthCertificates' )							IS NOT NULL DROP VIEW  VActiveHealthCertificates
IF OBJECT_ID( 'VInActiveHealthCertificates' )						IS NOT NULL DROP VIEW  VInActiveHealthCertificates
IF OBJECT_ID( 'VHealthCertificates' )								IS NOT NULL DROP VIEW  VHealthCertificates

IF OBJECT_ID( 'VActiveFeedMiscExpenses' )							IS NOT NULL DROP VIEW  VActiveFeedMiscExpenses
IF OBJECT_ID( 'VInActiveFeedMiscExpenses' )							IS NOT NULL DROP VIEW  VInActiveFeedMiscExpenses
IF OBJECT_ID( 'VFeedMiscExpenses' )									IS NOT NULL DROP VIEW  VFeedMiscExpenses

IF OBJECT_ID( 'VActiveEquipment' )									IS NOT NULL DROP VIEW  VActiveEquipment
IF OBJECT_ID( 'VInActiveEquipment' )								IS NOT NULL DROP VIEW  VInActiveEquipment
IF OBJECT_ID( 'VEquipment' )										IS NOT NULL DROP VIEW  VEquipment

IF OBJECT_ID( 'VActiveMaintenance' )								IS NOT NULL DROP VIEW  VActiveMaintenance
IF OBJECT_ID( 'VInActiveMaintenance' )								IS NOT NULL DROP VIEW  VInActiveMaintenance
IF OBJECT_ID( 'VMaintenance' )										IS NOT NULL DROP VIEW  VMaintenance

-- --------------------------------------------------------------------------------
-- Create tables
-- --------------------------------------------------------------------------------

CREATE TABLE THorseBreeds
(	
	 intBreedID							INTEGER					NOT NULL
	,strBreed							VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseBreeds_PK  PRIMARY KEY  ( intBreedID )
)

CREATE TABLE THorseColors
(	
	 intColorID							INTEGER					NOT NULL
	,strColor							VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseColors_PK  PRIMARY KEY  ( intColorID )
)

CREATE TABLE THorseSexes
(	
	 intSexID							INTEGER					NOT NULL
	,strSex								VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseSexes_PK  PRIMARY KEY  ( intSexID )
)

CREATE TABLE TStates
(
	 intStateID							INTEGER					NOT NULL
	,strState							VARCHAR(50)				NOT NULL
	,strStateAbbreviation				VARCHAR(50)				NOT NULL
	,CONSTRAINT  TStates_PK  PRIMARY KEY  ( intStateID )
) 

CREATE TABLE THorseBuyerStatuses
(
	 intHorseBuyerStatusID				INTEGER					NOT NULL
	,strHorseBuyerStatus				VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseBuyerStatuses_PK  PRIMARY KEY  ( intHorseBuyerStatusID ) 
)

CREATE TABLE THorseBuyers
(	
	 intHorseBuyerID					INTEGER					NOT NULL
	,strFullName						VARCHAR(50)				NOT NULL
	,strAddress							VARCHAR(50)				NOT NULL
	,strCity							VARCHAR(50)				NOT NULL
	,intStateID							INTEGER					NOT NULL
	,strZipCode							VARCHAR(50)				NOT NULL
	,decPurchasePrice					MONEY					NOT NULL		
	,dteDatePurchased					DATE					NOT NULL
	,intHorseBuyerStatusID				INTEGER					NOT NULL
	,CONSTRAINT  THorseBuyers_PK  PRIMARY KEY  ( intHorseBuyerID )
)

CREATE TABLE THorseSellerStatuses
(
	 intHorseSellerStatusID				INTEGER					NOT NULL
	,strHorseSellerStatus				VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseSellerStatuses_PK  PRIMARY KEY  ( intHorseSellerStatusID ) 
)

CREATE TABLE THorseSellers
(	
	 intHorseSellerID					INTEGER					NOT NULL
	,strFullName						VARCHAR(50)				NOT NULL
	,strAddress							VARCHAR(50)				NOT NULL
	,strCity							VARCHAR(50)				NOT NULL
	,intStateID							INTEGER					NOT NULL
	,strZipCode							VARCHAR(50)				NOT NULL
	,decSellingPrice					MONEY					NOT NULL
	,dteDateSold						DATE					NOT NULL
	,intHorseSellerStatusID				INTEGER					NOT NULL
	,CONSTRAINT  THorseSellers_PK  PRIMARY KEY  ( intHorseSellerID )
)


CREATE TABLE THorseStatuses
(
	 intHorseStatusID					INTEGER					NOT NULL
	,strHorseStatus						VARCHAR(50)				NOT NULL
	,CONSTRAINT  THorseStatuses_PK  PRIMARY KEY  ( intHorseStatusID ) 
)

CREATE TABLE THorses
(	
	 intHorseID							INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,intBreedID							INTEGER					NOT NULL
	,strRegistration					VARCHAR(50)				NOT NULL
	,intColorID							INTEGER					NOT NULL
	,intSexID							INTEGER					NOT NULL
	,strHeight							VARCHAR(50)				NOT NULL
	,intHorseBuyerID					INTEGER					NOT NULL
	,intHorseSellerID					INTEGER					NOT NULL	
	,strComments						VARCHAR(250)			NOT NULL
	,intHorseStatusID					INTEGER					NOT NULL
	,CONSTRAINT  THorses_PK  PRIMARY KEY  ( intHorseID )
)

CREATE TABLE TShoeStatuses
(
	 intShoeStatusID					INTEGER					NOT NULL
	,strShoeStatus						VARCHAR(50)				NOT NULL
	,CONSTRAINT  TShoeStatuses_PK  PRIMARY KEY  ( intShoeStatusID ) 
)

CREATE TABLE TShoes
(	
	 intShoeID							INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dteShod							DATE					NOT NULL
	,strTrimAngle						VARCHAR(50)				NOT NULL
	,decFarrierCost						MONEY					NOT NULL
	,strComments						VARCHAR(50)				NOT NULL
	,intShoeStatusID					INTEGER					NOT NULL
	,CONSTRAINT  TShoes_PK  PRIMARY KEY  ( intShoeID )
)

CREATE TABLE THorseShoes
(	
	 intHorseID							INTEGER					NOT NULL
	,intShoeID							INTEGER					NOT NULL
	,CONSTRAINT  THorseShoes_PK  PRIMARY KEY  ( intHorseID, intShoeID )
)

CREATE TABLE TVaccinationStatuses
(
	 intVaccinationStatusID				INTEGER					NOT NULL
	,strVaccinationStatus				VARCHAR(50)				NOT NULL
	,CONSTRAINT  TVaccinationStatuses_PK  PRIMARY KEY  ( intVaccinationStatusID ) 
)

CREATE TABLE TVaccinations
(	
	 intVaccinationID					INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,decVaccinationCost					MONEY					NOT NULL
	,dteVaccinationDate					DATE					NOT NULL
	,strComments						VARCHAR(250)			NOT NULL
	,intVaccinationStatusID				INTEGER					NOT NULL
	,CONSTRAINT  TVaccinations_PK  PRIMARY KEY  ( intVaccinationID )
)

CREATE TABLE THorseVaccinations
(	
	 intHorseID							INTEGER					NOT NULL
	,intVaccinationID					INTEGER					NOT NULL
	,CONSTRAINT  THorseVaccination_PK  PRIMARY KEY  ( intHorseID, intVaccinationID )
)

CREATE TABLE TWestNileTestStatuses
(	
	 intWestNileTestStatusID			INTEGER					NOT NULL
	,strWestNileTestStatus				VARCHAR(50)				NOT NULL
	,CONSTRAINT  TWestNileTestStatuses_PK  PRIMARY KEY  ( intWestNileTestStatusID ) 
)

CREATE TABLE TWestNileTests
(	
	 intWestNileTestID					INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dteWestNileTestDate				DATE					NOT NULL
	,decWestNileTestCost				MONEY					NOT NULL
	,strComments						VARCHAR(250)			NOT NULL
	,intWestNileTestStatusID			INTEGER					NOT NULL
	,CONSTRAINT  TWestNileTests_PK  PRIMARY KEY  ( intWestNileTestID )
)

CREATE TABLE THorseWestNileTests
(	
	 intHorseID							INTEGER					NOT NULL
	,intWestNileTestID					INTEGER					NOT NULL
	,CONSTRAINT  THorseWestNileTests_PK  PRIMARY KEY  ( intHorseID, intWestNileTestID )
)

CREATE TABLE TDewormerStatuses
(
	 intDewormerStatusID				INTEGER					NOT NULL
	,strDewormerStatus					VARCHAR(50)				NOT NULL
	,CONSTRAINT  TDewormerStatuses_PK  PRIMARY KEY  ( intDewormerStatusID ) 
)

CREATE TABLE TDewormers
(	
	 intDewormerID						INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dteDewormerDate					DATE					NOT NULL
	,decDewormerCost					MONEY					NOT NULL
	,intDewormerStatusID				INTEGER					NOT NULL
	,CONSTRAINT  TDewormers_PK  PRIMARY KEY  ( intDewormerID )
)

CREATE TABLE THorseDewormers
(	
	 intHorseID							INTEGER					NOT NULL
	,intDewormerID						INTEGER					NOT NULL
	,CONSTRAINT  THorseDewormers_PK  PRIMARY KEY  ( intHorseID, intDewormerID )
)

CREATE TABLE THealthCertificateStatuses
(
	 intHealthCertificateStatusID		INTEGER					NOT NULL
	,strHealthCertificateStatus			VARCHAR(50)				NOT NULL
	,CONSTRAINT  THealthCertificateStatuses_PK  PRIMARY KEY  ( intHealthCertificateStatusID ) 
)

CREATE TABLE THealthCertificates
(		
	 intHealthCertificateID				INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dteHealthCertificateDate			DATE					NOT NULL
	,decHealthCertificateCost			MONEY					NOT NULL
	,strComments						VARCHAR(250)			NOT NULL
	,intHealthCertificateStatusID		INTEGER					NOT NULL
	,CONSTRAINT  THealthCertificates_PK  PRIMARY KEY  ( intHealthCertificateID )
)

CREATE TABLE THorseHealthCertificates
(	
	 intHorseID							INTEGER					NOT NULL
	,intHealthCertificateID				INTEGER					NOT NULL
	,CONSTRAINT  THorseHealthCertificates_PK  PRIMARY KEY  ( intHorseID, intHealthCertificateID )
)

CREATE TABLE TFeedMiscExpenseStatuses
(
	 intFeedMiscExpenseStatusID			INTEGER					NOT NULL
	,strFeedMiscExpenseStatus			VARCHAR(50)				NOT NULL
	,CONSTRAINT  TFeedMiscExpenseStatuses_PK  PRIMARY KEY  ( intFeedMiscExpenseStatusID ) 
)

CREATE TABLE TFeedMiscExpenses
(	
	 intFeedMiscExpenseID				INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL		
	,decExpenseCost						MONEY					NOT NULL
	,dteDatePurchased					DATE					NOT NULL		
	,strComments						VARCHAR(250)			NOT NULL
	,intFeedMiscExpenseStatusID			INTEGER					NOT NULL
	,CONSTRAINT  TFeedMiscExpenses_PK  PRIMARY KEY  ( intFeedMiscExpenseID )
)

CREATE TABLE TEquipmentStatuses
(
	 intEquipmentStatusID				INTEGER					NOT NULL
	,strEquipmentStatus					VARCHAR(50)				NOT NULL
	,CONSTRAINT  TEquipmentStatuses_PK  PRIMARY KEY  ( intEquipmentStatusID ) 
)

CREATE TABLE TEquipment
(	
	 intEquipmentID						INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dtePurchaseDate					DATE					NOT NULL
	,decCost							MONEY					NOT NULL
	,strComments						VARCHAR(250)			Not NULL
	,intEquipmentStatusID				INTEGER					NOT NULL
	,CONSTRAINT  TEquipment_PK  PRIMARY KEY  ( intEquipmentID )
)

CREATE TABLE TMaintenanceStatuses
(
	 intMaintenanceStatusID				INTEGER					NOT NULL
	,strMaintenanceStatus				VARCHAR(50)				NOT NULL
	,CONSTRAINT  TMaintenanceStatuses_PK  PRIMARY KEY  ( intMaintenanceStatusID ) 
)

CREATE TABLE TMaintenance
(	
	 intMaintenanceID					INTEGER					NOT NULL
	,strName							VARCHAR(50)				NOT NULL
	,dteMaintenanceDate					DATE					NOT NULL
	,decMaintenanceCost					MONEY					NOT NULL	
	,strComments						VARCHAR(250)			NOT NULL
	,intMaintenanceStatusID				INTEGER					NOT NULL
	,CONSTRAINT  TMaintenance_PK  PRIMARY KEY  ( intMaintenanceID )
)

CREATE TABLE TEquipmentMaintenance
(	
	 intEquipmentID						INTEGER					NOT NULL
	,intMaintenanceID					INTEGER					NOT NULL
	,CONSTRAINT  TEquipmentMaintenance_PK  PRIMARY KEY  ( intEquipmentID, intMaintenanceID )
)


-- --------------------------------------------------------------------------------
-- Identify and Create Foreign Keys
-- --------------------------------------------------------------------------------

-- #		Child							Parent					Columns
-- -		-----							------					-------
-- 1		THorses						THorseBreeds				intBreedID 
-- 2		THorses						THorseColors				intColorID
-- 3		THorses						THorseSexes					intSexID
-- 4		THorseBuyers				TStates						intStateID
-- 5		THorseSellers				TStates						intStateID
-- 6		THorseBuyers				THorseBuyerStatuses			intHorseBuyerStatusID
-- 7		THorses						THorseBuyers				intHorseBuyerID
-- 8		THorseSellers				THorseSellerStatuses		intHorseSellerStatusID
-- 9		THorses						THorseSellers				intHorseSellerID
-- 10		THorses						THorseStatuses				intHorseStatusID
-- 11		TShoes						TShoeStatuses				intShoeStatusID
-- 12		THorseShoes					TShoes						intShoeID
-- 13		THorseShoes					THorses						intHorseID
-- 14		TVaccinations				TVaccinationtatuses			intVaccinationStatusID
-- 15		THorseVaccinations			TVaccinations				intVaccinationID
-- 16		THorseVaccinations			THorses						intHorseID
-- 17		TWestNileTests				TWestNileTestStatuses		intWestNileTestStatusID
-- 18		THorseWestNileTests			TWestNileTests				intWestNileTestID
-- 19		THorseWestNileTests			THorses						intHorseID
-- 20		TDewormers					TDewormerStatuses			intDewormerStatusID
-- 21		THorseDewormers				TDewormers					intDewormerID
-- 22		THorseDewormers				THorses						intHorseID
-- 23		THealthCertificates			THealthCertificateStatuses	intHealthCertificateStatusID
-- 24		THorseHealthCertificates	THealthCertificates			intHealthCertificateID
-- 25		THorseHealthCertificates	THorses						intHorseID
-- 26		TFeedMiscExpenses			TFeedMiscExpenses			intFeedMiscExpenseStatusID
-- 27		TEquipment					TEquipmentStatuses			intEquipmentStatusID
-- 28		TEquipmentMaintenance		TEquipment					intEquipmentID
-- 29		TMaintenance				TMaintenanceStatuses		intMaintenanceStatusID
-- 30		TEquipmentMaintenance		TMaintenances				intMaintenanceID



-- ALTER TABLE <child> ADD CONSTRAINT <child>_<parent>_FK
-- FOREIGN KEY ( <child table column(s)> ) REFERENCES <parent table>( <parent table column(s)> )
  
 -- 1

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseBreeds_FK
FOREIGN KEY ( intBreedID ) REFERENCES THorseBreeds( intBreedID )

 -- 2

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseColors_FK
FOREIGN KEY ( intColorID ) REFERENCES THorseColors( intColorID )

 -- 3

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseSexes_FK
FOREIGN KEY ( intSexID ) REFERENCES THorseSexes( intSexID )

 -- 4

ALTER TABLE THorseBuyers ADD CONSTRAINT THorseBuyers_TStates_FK
FOREIGN KEY ( intStateID ) REFERENCES TStates( intStateID )

 -- 5

ALTER TABLE THorseSellers ADD CONSTRAINT THorseSellers_TStates_FK
FOREIGN KEY ( intStateID ) REFERENCES TStates( intStateID )

 -- 6 

ALTER TABLE THorseBuyers ADD CONSTRAINT THorseBuyers_THorseBuyerStatuses_FK
FOREIGN KEY ( intHorseBuyerStatusID ) REFERENCES THorseBuyerStatuses( intHorseBuyerStatusID )

 -- 7

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseBuyers_FK
FOREIGN KEY ( intHorseBuyerID ) REFERENCES THorseBuyers( intHorseBuyerID )

 -- 8 

ALTER TABLE THorseSellers ADD CONSTRAINT THorseSellers_THorseSellerStatuses_FK
FOREIGN KEY ( intHorseSellerStatusID ) REFERENCES THorseSellerStatuses( intHorseSellerStatusID )

 -- 9

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseSellers_FK
FOREIGN KEY ( intHorseSellerID ) REFERENCES THorseSellers( intHorseSellerID )

 -- 10 

ALTER TABLE THorses ADD CONSTRAINT THorses_THorseStatuses_FK
FOREIGN KEY ( intHorseStatusID ) REFERENCES THorseStatuses( intHorseStatusID )

 -- 11 

ALTER TABLE TShoes ADD CONSTRAINT TShoes_TShoeStatuses_FK
FOREIGN KEY ( intShoeStatusID ) REFERENCES TShoeStatuses( intShoeStatusID )

 -- 12

ALTER TABLE THorseShoes ADD CONSTRAINT THorseShoes_TShoes_FK
FOREIGN KEY ( intShoeID ) REFERENCES TShoes( intShoeID )

 -- 13

ALTER TABLE THorseShoes ADD CONSTRAINT THorseShoes_THorses_FK
FOREIGN KEY ( intHorseID ) REFERENCES THorses( intHorseID )

 -- 14 

ALTER TABLE TVaccinations ADD CONSTRAINT TVaccinations_TVaccinationStatuses_FK
FOREIGN KEY ( intVaccinationStatusID ) REFERENCES TVaccinationStatuses( intVaccinationStatusID )

 -- 15

ALTER TABLE THorseVaccinations ADD CONSTRAINT THorseVaccinations_TVaccinations_FK
FOREIGN KEY ( intVaccinationID ) REFERENCES TVaccinations( intVaccinationID )

 -- 16

ALTER TABLE THorseVaccinations ADD CONSTRAINT THorseVaccinations_THorses_FK
FOREIGN KEY ( intHorseID ) REFERENCES THorses( intHorseID )

 -- 17 

ALTER TABLE TWestNileTests ADD CONSTRAINT TWestNileTests_TWestNileTestStatuses_FK
FOREIGN KEY ( intWestNileTestStatusID ) REFERENCES TWestNileTestStatuses( intWestNileTestStatusID )

 -- 18

ALTER TABLE THorseWestNileTests ADD CONSTRAINT THorseWestNileTests_TWestNileTests_FK
FOREIGN KEY ( intWestNileTestID ) REFERENCES TWestNileTests( intWestNileTestID )

 -- 19

ALTER TABLE THorseWestNileTests ADD CONSTRAINT THorseWestNileTests_THorses_FK
FOREIGN KEY ( intHorseID ) REFERENCES THorses( intHorseID )

 -- 20 

ALTER TABLE TDewormers ADD CONSTRAINT TDewormers_TDewormerStatuses_FK
FOREIGN KEY ( intDewormerStatusID ) REFERENCES TDewormerStatuses( intDewormerStatusID )

 -- 21

ALTER TABLE THorseDewormers ADD CONSTRAINT THorseDewormers_TDewormers_FK
FOREIGN KEY ( intDewormerID ) REFERENCES TDewormers( intDewormerID )

 -- 22

ALTER TABLE THorseDewormers ADD CONSTRAINT THorseDewormers_THorses_FK
FOREIGN KEY ( intHorseID ) REFERENCES THorses( intHorseID )

 -- 23 

ALTER TABLE THealthCertificates ADD CONSTRAINT THealthCertificates_THealthCertificateStatuses_FK
FOREIGN KEY ( intHealthCertificateStatusID ) REFERENCES THealthCertificateStatuses( intHealthCertificateStatusID )

 -- 24

ALTER TABLE THorseHealthCertificates ADD CONSTRAINT THorseHealthCertificates_THealthCertificates_FK
FOREIGN KEY ( intHealthCertificateID ) REFERENCES THealthCertificates( intHealthCertificateID )

 -- 25

ALTER TABLE THorseHealthCertificates ADD CONSTRAINT THorseHealthCertificates_THorses_FK
FOREIGN KEY ( intHorseID ) REFERENCES THorses( intHorseID )

 -- 26 

ALTER TABLE TFeedMiscExpenses ADD CONSTRAINT TFeedMiscExpenses_TFeedMiscExpenseStatuses_FK
FOREIGN KEY ( intFeedMiscExpenseStatusID ) REFERENCES TFeedMiscExpenseStatuses( intFeedMiscExpenseStatusID )

 -- 27 

ALTER TABLE TEquipment ADD CONSTRAINT TEquipment_TEquipmentStatuses_FK
FOREIGN KEY ( intEquipmentStatusID ) REFERENCES TEquipmentStatuses( intEquipmentStatusID )

 -- 28
ALTER TABLE TEquipmentMaintenance ADD CONSTRAINT TEquipmentMaintenance_TEquipment_FK
FOREIGN KEY ( intEquipmentID ) REFERENCES TEquipment( intEquipmentID )

 -- 29 

ALTER TABLE TMaintenance ADD CONSTRAINT TMaintenance_TMaintenanceStatuses_FK
FOREIGN KEY ( intMaintenanceStatusID ) REFERENCES TMaintenanceStatuses( intMaintenanceStatusID )

 -- 30

ALTER TABLE TEquipmentMaintenance ADD CONSTRAINT TEquipmentMaintenance_TMaintenance_FK
FOREIGN KEY ( intMaintenanceID ) REFERENCES TMaintenance( intMaintenanceID )

-- --------------------------------------------------------------------------------
-- Insert test data into tables
-- --------------------------------------------------------------------------------

INSERT INTO THorseBreeds ( intBreedID, strBreed )
VALUES	 ( 1, 'Tennessee Walker' )
		,( 2, 'Saddlebred' )
		,( 3, 'Standardbred' )
		,( 4, 'Rocky Mountain Horse' )
		,( 5, 'Missouri Fox Trotter' )
		,( 6, 'Racking Horse' )

INSERT INTO THorseColors ( intColorID, strColor )
VALUES	 ( 1, 'Bay' )
		,( 2, 'Black' )
		,( 3, 'Tobiano' )
		,( 4, 'Sorrel' )
		,( 5, 'Buckskin' )
		,( 6, 'Palomino' )

INSERT INTO THorseSexes ( intSexID, strSex )
VALUES	 ( 1, 'Mare' )
		,( 2, 'Gelding' )
		,( 3, 'Stud' )
		,( 4, 'Filly' )

INSERT INTO TStates ( intStateID, strState, strStateAbbreviation )		
VALUES	 ( 1, 'Absolutely unknown', 'N/A' )
		,( 2, 'Alabama', 'AL' )	
		,( 3, 'Alaska', 'AK' )
		,( 4, 'Arizona', 'AZ' )
		,( 5, 'Arkansas', 'AR' )
		,( 6, 'California', 'CA' )
		,( 7, 'Colorado', 'CO' )
		,( 8, 'Connecticut', 'CT' )
		,( 9, 'Delaware', 'DE' )
		,( 10, 'Florida', 'FL' )
		,( 11, 'Georgia', 'GA' )
		,( 12, 'Hawaii', 'HI' )
		,( 13, 'Idaho', 'ID' )
		,( 14, 'Illinois', 'IL' )
		,( 15, 'Indiana', 'IN' )
		,( 16, 'Iowa', 'IA' )
		,( 17, 'Kansas', 'KS' )
		,( 18, 'Kentucky', 'KY' )
		,( 19, 'Louisiana', 'LA' )
		,( 20, 'Maine', 'ME' )
		,( 21, 'Maryland', 'MD' )
		,( 22, 'Massachusetts', 'MA' )
		,( 23, 'Michigan', 'MI' )
		,( 24, 'Minnesota', 'MN' )
		,( 25, 'Mississippi', 'MS' )
		,( 26, 'Missouri', 'MO' )
		,( 27, 'Montana', 'MT' )
		,( 28, 'Nebraska', 'NE' )
		,( 29, 'Nevada', 'NV' )
		,( 30, 'New Hampshire', 'NH' )
		,( 31, 'New Jersey', 'NJ' )
		,( 32, 'New Mexico', 'NM' )
		,( 33, 'New York', 'NY' )
		,( 34, 'North Carolina', 'NC' )
		,( 35, 'North Dakota', 'ND' )
		,( 36, 'Ohio', 'OH' )
		,( 37, 'Oklahoma', 'OK' )
		,( 38, 'Oregon', 'OR' )
		,( 39, 'Pennsylvania', 'PA' )
		,( 40, 'Rhode Island', 'RI' )
		,( 41, 'South Carolina', 'SC' )
		,( 42, 'South Dakota', 'SD' )
		,( 43, 'Tennessee', 'TN' )
		,( 44, 'Texas', 'TX' )
		,( 45, 'Utah', 'UT' )
		,( 46, 'Vermont', 'VT' )
		,( 47, 'Virginia', 'VA' )
		,( 48, 'Washington', 'WA' )
		,( 49, 'West Virginia', 'WV' )
		,( 50, 'Wisconsin', 'WI' )
		,( 51, 'Wyoming', 'WY' )
		,( 52, 'American Samoa', 'AS' )
		,( 53, 'District of Columbia', 'DC' )
		,( 54, 'Federated States of Micronesia', 'FM' )
		,( 55, 'Guam', 'GU' )
		,( 56, 'Marshall Islands', 'MH' )
		,( 57, 'Northern Mariana Islands', 'MP' )
		,( 58, 'Palau', 'PW' )
		,( 59, 'Puerto Rico', 'PR' )
		,( 60, 'Virgin Islands', 'VI' )

INSERT INTO THorseBuyerStatuses( intHorseBuyerStatusID, strHorseBuyerStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO THorseBuyers ( intHorseBuyerID, strFullName, strAddress, strCity, intStateID, strZipCode, decPurchasePrice, dteDatePurchased, intHorseBuyerStatusID )
VALUES	 ( 1, 'N/A', 'N/A', 'N/A', 1, '', 0, '1900/01/01', 1 )
		,( 2, 'John Wayne', '98 Elm', 'Bakersfield', 5, '', 1500, '2014/08/30', 1 )
		,( 3, 'Clint Eastwood', '45 Eastwood Lane', 'Pheonix', 3, '87654', 1000, '2014/09/12', 1 )
		,( 4, 'Jim Brown', '67 Brown St.', 'Cleveland', 35, '', 2500, '2015/04/23', 1 )
		,( 5, 'James Drury', '1 Drury Lane', '', 46, '', 2000, '2015/06/05', 1 )
		,( 6, 'Joe Cartwright', '', '', 1, '', 1200, '2016/03/04', 1 ) 

INSERT INTO THorseSellerStatuses( intHorseSellerStatusID, strHorseSellerStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO THorseSellers ( intHorseSellerID, strFullName, strAddress, strCity, intStateID, strZipCode, decSellingPrice, dteDateSold, intHorseSellerStatusID )
VALUES	 ( 1, 'N/A', 'N/A', 'N/A', 1, '', 0, '1900/01/01', 1 )
		,( 2, 'Melissa Jones', '54 Walnut St.', 'Indianapolis', 14, '', 400, '2013/05/22', 1 )
		,( 3, 'Brad Klump', '53456 Blue Goose Rd.', 'Russellville', 35, '', 600, '2014/06/14', 1 )
		,( 4, 'Alvin Black', '', 'LaGrange', 17, '', 1500, '2014/08/15', 1 )
		,( 5, 'Tracy Evans', '', '', 1, '', 800, '2014/07/10', 1 )
		,( 6, 'Julie Evans', '', '', 1, '', 500, '2014/09/10', 1 )

INSERT INTO THorseStatuses( intHorseStatusID, strHorseStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO THorses ( intHorseID, strName, intBreedID, strRegistration, intColorID, intSexID, strHeight, intHorseBuyerID, intHorseSellerID, strComments, intHorseStatusID )
VALUES	 ( 1, 'Gypsy', 1, 'No', 3, 1, '14.2 hands', 3, 2, '', 1 )
		,( 2, 'Star', 1, 'Yes', 3, 1, '15 hands', 4, 3, '', 1 )
		,( 3, 'Mellissa', 1, 'No', 1, 1, '16 hands', 5, 4, '', 1 )
		,( 4, 'Dakota', 1, 'No', 3, 2, '15.2 hands', 1, 1, 'In training/raised on farm', 1 )
		,( 5, 'Koko', 1, 'Yes', 3, 1, '16.1 hands', 1, 1, 'In training/raised on farm', 1 )
		,( 6, 'Beauty', 2, 'Yes', 3, 1, '16.2 hands', 1, 1, 'In training/raised on farm', 1 ) 
		
INSERT INTO TShoeStatuses( intShoeStatusID, strShoeStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )  

INSERT INTO TShoes ( intShoeID, strName, dteShod, strTrimAngle, decFarrierCost, strComments, intShoeStatusID )
VALUES	 ( 1, 'Trim', '2013/11/19', '52/54', 20, 'Trim only', 2 )
		,( 2, 'Borium2-14', '2014/02/12', '52/54', 38, 'Trim and new shoes',  2 )
		,( 3, 'Borium5-14', '2014/05/22', '52/54', 28, 'Trim and reset',  2 )
		,( 4, 'Borium8-14', '2014/08/22', '52/54', 28, 'Trim and reset', 2 )
		,( 5, 'Trim11-14', '2014/11/19', '52/54', 20, 'Trim only', 2 )
		,( 6, 'Borium2-15', '2015/02/12', '52/54', 38, 'Trim and new shoes', 2 )
		,( 7, 'Borium5-15', '2015/05/22', '52/54', 28, 'Trim and reset', 2 )
		,( 8, 'Borium8-15', '2015/08/22', '52/54', 28, 'Trim and reset', 2 )
		,( 9, 'Trim11-15', '2015/11/19', '52/54', 20, 'Trim only', 2 )
		,( 10, 'Borium2/16', '2016/02/12', '52/54', 38, 'Trim and new shoes', 1 )

INSERT INTO THorseShoes ( intHorseID, intShoeID )
VALUES	 ( 1, 1 )
		,( 1, 2 )
		,( 1, 3 )
		,( 1, 4 )
		,( 2, 5 )
		,( 2, 6 )
		,( 3, 4 )
		,( 3, 5 )
		,( 3, 6 )
		,( 3, 7 )
		,( 4, 6 )
		,( 4, 7 )
		,( 4, 8 )
		,( 4, 9 )
		,( 4, 10 )
		,( 5, 6 )
		,( 5, 7 )
		,( 5, 8 )
		,( 5, 9 )
		,( 5, 10 )
		,( 6, 6 )
		,( 6, 7 )
		,( 6, 8 )
		,( 6, 9 )
		,( 6, 10 )

INSERT INTO TVaccinationStatuses( intVaccinationStatusID, strVaccinationStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TVaccinations ( intVaccinationID, strName, decVaccinationCost, dteVaccinationDate, strComments, intVaccinationStatusID )
VALUES	 ( 1, 'Innovator5/14', 115, '2014/08/22', 'N/A', 2 )
		,( 2, 'Strangles/14', 40, '2014/08/22', 'N/A', 2 )
		,( 3, 'Innovator5/15', 125, '2015/08/22', 'N/A', 1 )
		,( 4, 'Strangles/15', 50, '2015/08/22', 'N/A', 1 )

INSERT INTO THorseVaccinations ( intHorseID, intVaccinationID )
VALUES	 ( 1, 1 )
		,( 1, 2 )
		,( 2, 1 )
		,( 2, 2 )
		,( 3, 1 )
		,( 3, 2 )
		,( 4, 1 )
		,( 4, 2 )
		,( 4, 3 )
		,( 4, 4 )
		,( 5, 1 )
		,( 5, 2 )
		,( 5, 3 )
		,( 5, 4 )
		,( 6, 1 )
		,( 6, 2 )
		,( 6, 3 )
		,( 6, 4 )

INSERT INTO TWestNileTestStatuses( intWestNileTestStatusID, strWestNileTestStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TWestNileTests ( intWestNileTestID, strName, dteWestNileTestDate, decWestNileTestCost, strComments, intWestNileTestStatusID )
VALUES	 ( 1, 'Coggins1-Shawnee', '2013/05/15', 62, 'Training out of state', 2 )
		,( 2, 'Coggins2-Shawnee', '2013/05/15', 62, 'Training out of state', 2 )
		,( 3, 'Coggins3-HockingHills', '2014/07/15', 62, 'Training out of state', 2 )
		,( 4, 'Coggins4-HockingHills', '2014/07/15', 62, 'Training out of state', 2 )
		,( 5, 'Coggins5-BigSouthFork', '2015/06/15', 62, 'Training out of state', 1 )
		,( 6, 'Coggins6-BigSouthFork', '2015/06/15', 62, 'Training out of state', 1 )

INSERT INTO THorseWestNileTests ( intHorseID, intWestNileTestID )
VALUES	 ( 2, 1 )
		,( 3, 2 )
		,( 2, 3 )
		,( 3, 4 )
		,( 4, 5 )
		,( 6, 6 )

INSERT INTO TDewormerStatuses( intDewormerStatusID, strDewormerStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TDewormers( intDewormerID, strName, dteDewormerDate, decDewormerCost, intDewormerStatusID )
VALUES	 ( 1, 'Safeguard2-14', '2014/02/25', 10, 2 )
		,( 2, 'Ivermectin5-14', '2014/05/27', 12, 2 )
		,( 3, 'Fenbendazole8-14', '2014/08/25', 10, 2 )
		,( 4, 'Zimecterin Gold11/14', '2014/11/28', 14, 2 )
		,( 5, 'Safeguard2-15', '2015/02/22', 11, 2 )
		,( 6, 'Ivermectin5-15', '2015/05/30', 13, 2 )
		,( 7, 'Fenbendazole8-15', '2015/08/25', 11, 1)
		,( 8, 'Zimecterin Gold11-15', '2015/11/30', 15, 1 )
		,( 9, 'Safeguard2-16', '2016/02/27', 11, 1 )

INSERT INTO THorseDewormers ( intHorseID, intDewormerID )
VALUES	 ( 1, 1 )
		,( 1, 2 )
		,( 1, 3 )
		,( 2, 3 )
		,( 2, 4 )
		,( 2, 5 )
		,( 2, 6 )
		,( 3, 3 )
		,( 3, 4 )
		,( 3, 5 )
		,( 3, 6 )
		,( 4, 1 )
		,( 4, 2 )
		,( 4, 3 )
		,( 4, 4 )
		,( 4, 5 )
		,( 4, 6 )
		,( 4, 7 )
		,( 4, 8 )
		,( 4, 9 )
		,( 5, 1 )
		,( 5, 2 )
		,( 5, 3 )
		,( 5, 4 )
		,( 5, 5 )
		,( 5, 6 )
		,( 5, 7 )
		,( 5, 8 )
		,( 5, 9 )
		,( 6, 1 )
		,( 6, 2 )
		,( 6, 3 )
		,( 6, 4 )
		,( 6, 5 )
		,( 6, 6 )
		,( 6, 7 )
		,( 6, 8 )
		,( 6, 9 )

INSERT INTO THealthCertificateStatuses( intHealthCertificateStatusID, strHealthCertificateStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO THealthCertificates ( intHealthCertificateID, strName, dteHealthCertificateDate, decHealthCertificateCost, strComments, intHealthCertificateStatusID )
VALUES	 ( 1, 'HC1-Shawnee', '2013/06/22', 35, 'Out of state training', 2 )
		,( 2, 'HC2-Shawnee', '2013/06/22', 35, 'Out of state training', 2 )
		,( 3, 'HC3-HockingHills', '2014/08/22', 35, 'Out of state training', 2 )
		,( 4, 'HC4-HockingHills', '2014/08/22', 35, 'Out of state training', 2 )
		,( 5, 'HC5-BigSouthFork', '2015/07/22', 35, 'Out of state training', 2 )
		,( 6, 'HC6-BigSouthFork', '2015/07/22', 35, 'Out of state training', 2 )

INSERT INTO THorseHealthCertificates ( intHorseID, intHealthCertificateID )
VALUES	 ( 2, 1 )
		,( 3, 2 )
		,( 2, 3 )
		,( 3, 4 )
		,( 4, 5 )
		,( 6, 6 )

INSERT INTO TFeedMiscExpenseStatuses( intFeedMiscExpenseStatusID, strFeedMiscExpenseStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TFeedMiscExpenses ( intFeedMiscExpenseID, strName, decExpenseCost, dteDatePurchased, strComments, intFeedMiscExpenseStatusID )
VALUES	 ( 1, 'Hay', 350, '2014/12/02', '10 round bales-brohm', 1 )
		,( 2, 'Grain', 240, '2014/12/10', '900lb. 14% winter mix', 1 )
		,( 3, 'Hay', 350, '2015/02/26', '10 round bales-timothy', 1 )
		,( 4, 'Hay', 320, '2015/04/15', '80 square bales-timothy', 1 )
		,( 5, 'Grain', 225, '2015/04/01', '900lb. 14% summer mix', 1 ) 
		,( 6, 'Hay', 300, '2015/10/25', '10 round bales-brohm', 1 )
		,( 7, 'Grain', 245, '2015/11/20', '900lb. 14% winter mix', 1 )
		,( 8, 'Hay', 800, '2016/03/04', '200 square bales-timothy', 1 )

INSERT INTO TEquipmentStatuses( intEquipmentStatusID, strEquipmentStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TEquipment ( intEquipmentID, strName, dtePurchaseDate, decCost, strComments, intEquipmentStatusID )
VALUES	 ( 1, 'Bison', '2013/03/24', 1800, 'Trailer, stock', 1 )
		,( 2, 'Elite', '2014/04/18', 35000, 'Trailer, four horse living quarters', 1 )
		,( 3, 'Bee', '2014/05/12', 4500, 'Trailer, four horse', 1 )

INSERT INTO TMaintenanceStatuses( intMaintenanceStatusID, strMaintenanceStatus )
VALUES	 ( 1, 'Active' )
		,( 2, 'InActive' )

INSERT INTO TMaintenance ( intMaintenanceID, strName, dteMaintenanceDate, decMaintenanceCost, strComments, intMaintenanceStatusID )
VALUES	 ( 1, 'Brakes', '2013/08/24', 200, 'Bison, Brake Pads only', 1 )
		,( 2, 'Tires', '2014/09/12', 800, 'Bee, all four', 1 )
		,( 3, 'Hydraulic Jack', '2015/04/05', 2000, 'Elite, Jack 12000lb.', 1 )
		,( 4, 'Batteries', '2015/05/12', 275, 'Elite, Marine duty', 1 )
		,( 5, 'Brakes', '2015/06/12', 1000, 'Elite, total rebuild', 1 )
		,( 6, 'Tires', '2015/09/12', 975, 'Elite, all four', 1 )

INSERT INTO TEquipmentMaintenance ( intEquipmentID, intMaintenanceID )
VALUES	 ( 1, 1 )
		,( 3, 2 )
		,( 2, 3 )
		,( 2, 4 )
		,( 2, 5 )
		,( 2, 6 )

-- -----------------------------------------------------------------------------
--  Create uspSetHorseBuyerStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetHorseBuyerStatus
	 @intHorseBuyerID				AS INTEGER
	,@intHorseBuyerStatusID		AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	THorseBuyers
SET
	 intHorseBuyerStatusID		= @intHorseBuyerStatusID
WHERE
		intHorseBuyerID 		= @intHorseBuyerID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddHorseBuyer
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddHorseBuyer
	 @strFullName					AS VARCHAR(50)
	,@strAddress					AS VARCHAR(50)	
	,@strCity						AS VARCHAR(50)	
	,@intStateID					AS INTEGER	
	,@strZipCode					AS VARCHAR(50)	
	,@decPurchasePrice				AS MONEY	
	,@dteDatePurchased				AS DATE
	,@intHorseBuyerStatusID		    AS INTEGER	

AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Rollback transaction on error

BEGIN TRANSACTION	

	DECLARE @intHorseBuyerID			 INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intHorseBuyerID = MAX( intHorseBuyerID ) + 1 FROM THorseBuyers 

		-- Default to 1 if table is empty
		SELECT @intHorseBuyerID = COALESCE( @intHorseBuyerID, 1 )

		INSERT INTO THorseBuyers( intHorseBuyerID, strFullName, strAddress, strCity, intStateID, strZipCode, decPurchasePrice, dteDatePurchased, intHorseBuyerStatusID )
		VALUES( @intHorseBuyerID, @strFullName, @strAddress, @strCity, @intStateID, @strZipCode, @decPurchasePrice, @dteDatePurchased, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intHorseBuyerID	AS intHorseBuyerID

COMMIT TRANSACTION

GO

 -- SELECT * FROM THorseBuyers

--------------------------------------------------------------------------------
--  Create a uspEditHorseBuyer stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditHorseBuyer
	 @intHorseBuyerID				AS INTEGER
	,@strFullName					AS VARCHAR(50)
	,@strAddress					AS VARCHAR(50)	
	,@strCity						AS VARCHAR(50)	
	,@intStateID					AS INTEGER	
	,@strZipCode					AS VARCHAR(50)	
	,@decPurchasePrice				AS MONEY	
	,@dteDatePurchased				AS DATE
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION		
	-- Update the record 
	UPDATE
		THorseBuyers
	SET
		 strFullName				= @strFullName
		,strAddress					= @strAddress
		,strCity					= @strCity
		,intStateID					= @intStateID
		,strZipCode					= @strZipCode
		,decPurchasePrice			= @decPurchasePrice
		,dteDatePurchased			= @dteDatePurchased
	WHERE
		intHorseBuyerID			= @intHorseBuyerID

COMMIT TRANSACTION

GO

-- SELECT * FROM THorseBuyers

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveHorseBuyers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveHorseBuyers
AS

SELECT 
	 	 intHorseBuyerID								-- always get ID
	 	,strFullName									-- always get name				
FROM 	
 		 THorseBuyers 
WHERE
	intHorseBuyerStatusID = 1							-- 1 = Active
							
GO

-- SELECT * FROM VActiveHorseBuyers

-- --------------------------------------------------------------------------------
--  Create the view VInActiveHorseBuyers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveHorseBuyers
AS

SELECT 
	 	 intHorseBuyerID								-- always get ID
	 	,strFullName									-- always get name				
FROM 	
 		 THorseBuyers 
WHERE
	intHorseBuyerStatusID = 2							-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveHorseBuyers

-- --------------------------------------------------------------------------------
--  Create the view VHorseBuyers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VHorseBuyers
AS

SELECT 
	 THBYR.intHorseBuyerID								-- always get ID
	,THBYR.strFullName									-- always get name
	,THBYR.strAddress
	,THBYR.strCity
	,TS.strState
	,THBYR.strZipCode
	,THBYR.decPurchasePrice
	,THBYR.dteDatePurchased
	,THBSTAT.strHorseBuyerStatus
															
FROM 	
 	THorseBuyers AS THBYR

		INNER JOIN THorseBuyerStatuses AS THBSTAT
        ON THBYR.intHorseBuyerStatusID = THBSTAT.intHorseBuyerStatusID 
		
		INNER JOIN TStates AS TS
        ON THBYR.intStateID = TS.intStateID 

							
GO

-- SELECT * FROM VHorseBuyers

-- -----------------------------------------------------------------------------
--  Create uspSetHorseSellerStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetHorseSellerStatus
	 @intHorseSellerID				AS INTEGER
	,@intHorseSellerStatusID		AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	THorseSellers
SET
	 intHorseSellerStatusID		= @intHorseSellerStatusID
WHERE
		intHorseSellerID 		= @intHorseSellerID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddHorseSeller
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddHorseSeller
	 @strFullName					AS VARCHAR(50)
	,@strAddress					AS VARCHAR(50)	
	,@strCity						AS VARCHAR(50)	
	,@intStateID					AS INTEGER	
	,@strZipCode					AS VARCHAR(50)	
	,@decSellingPrice				AS MONEY	
	,@dteDateSold					AS DATE
	,@intHorseSellerStatusID		AS INTEGER	

AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Rollback transaction on error

BEGIN TRANSACTION	

	DECLARE @intHorseSellerID			 INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intHorseSellerID = MAX( intHorseSellerID ) + 1 FROM THorseSellers 

		-- Default to 1 if table is empty
		SELECT @intHorseSellerID = COALESCE( @intHorseSellerID, 1 )

		INSERT INTO THorseSellers( intHorseSellerID, strFullName, strAddress, strCity, intStateID, strZipCode, decSellingPrice, dteDateSold, intHorseSellerStatusID )
		VALUES( @intHorseSellerID, @strFullName, @strAddress, @strCity, @intStateID, @strZipCode, @decSellingPrice, @dteDateSold, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intHorseSellerID	AS intHorseSellerID

COMMIT TRANSACTION

GO

 -- SELECT * FROM THorseSellers

--------------------------------------------------------------------------------
--  Create a uspEditHorseSeller stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditHorseSeller
	 @intHorseSellerID				AS INTEGER
	,@strFullName					AS VARCHAR(50)
	,@strAddress					AS VARCHAR(50)	
	,@strCity						AS VARCHAR(50)	
	,@intStateID					AS INTEGER	
	,@strZipCode					AS VARCHAR(50)	
	,@decSellingPrice				AS MONEY	
	,@dteDateSold					AS DATE

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION		
	-- Update the record 
	UPDATE
		THorseSellers
	SET
		 strFullName				= @strFullName
		,strAddress					= @strAddress
		,strCity					= @strCity
		,intStateID					= @intStateID
		,strZipCode					= @strZipCode
		,decSellingPrice			= @decSellingPrice
		,dteDateSold				= @dteDateSold
	WHERE
		intHorseSellerID			= @intHorseSellerID

COMMIT TRANSACTION

GO

-- SELECT * FROM THorseSellers

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveHorseSellers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveHorseSellers
AS

SELECT 
	 	 intHorseSellerID								-- always get ID
	 	,strFullName									-- always get name				
FROM 	
 		 THorseSellers 
WHERE
	intHorseSellerStatusID = 1							-- 1 = Active
							
GO

-- SELECT * FROM VActiveHorseSellers

-- --------------------------------------------------------------------------------
--  Create the view VInActiveHorseSellers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveHorseSellers
AS

SELECT 
	 	 intHorseSellerID								-- always get ID
	 	,strFullName									-- always get name				
FROM 	
 		 THorseSellers 
WHERE
	intHorseSellerStatusID = 2							-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveHorseSellers

-- --------------------------------------------------------------------------------
--  Create the view VHorseSellers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VHorseSellers
AS

SELECT 
	 THSLR.intHorseSellerID								-- always get ID
	,THSLR.strFullName									-- always get name
	,THSLR.strAddress
	,THSLR.strCity
	,TS.strState
	,THSLR.strZipCode
	,THSLR.decSellingPrice
	,THSLR.dteDateSold
	,THSSTAT.strHorseSellerStatus
															
FROM 	
 	THorseSellers AS THSLR

		INNER JOIN THorseSellerStatuses AS THSSTAT
        ON THSLR.intHorseSellerStatusID = THSSTAT.intHorseSellerStatusID 
		
		INNER JOIN TStates AS TS
        ON THSLR.intStateID = TS.intStateID 

							
GO

-- SELECT * FROM VHorseSellers

-- -----------------------------------------------------------------------------
--  Create uspSetHorseStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetHorseStatus
	 @intHorseID				AS INTEGER
	,@intHorseStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	THorses
SET
	 intHorseStatusID	= @intHorseStatusID
WHERE
		intHorseID 		= @intHorseID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddHorse
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddHorse
	 @strName					AS VARCHAR(50)
	,@intBreedID				AS INTEGER
	,@strRegistration			AS VARCHAR(50)
	,@intColorID				AS INTEGER
	,@intSexID					AS INTEGER
	,@strHeight					AS VARCHAR(50)
	,@intHorseBuyerID			AS INTEGER	
	,@intHorseSellerID			AS INTEGER
	,@strComments				AS VARCHAR(250)
	,@intHorseStatusID			AS INTEGER

AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Rollback transaction on error

BEGIN TRANSACTION 

	DECLARE @intHorseID			 INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intHorseID = MAX( intHorseID ) + 1 FROM THorses 

		-- Default to 1 if table is empty
		SELECT @intHorseID = COALESCE( @intHorseID, 1 )

		INSERT INTO THorses( intHorseID, strName, intBreedID, strRegistration, intColorID, intSexID, strHeight, intHorseBuyerID, intHorseSellerID, strComments, intHorseStatusID )
		VALUES( @intHorseID, @strName, @intBreedID, @strRegistration, @intColorID, @intSexID, @strHeight, @intHorseBuyerID, @intHorseSellerID, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intHorseID AS intHorseID

COMMIT TRANSACTION

GO

 -- SELECT * FROM THorses

--------------------------------------------------------------------------------
--  Create a usp Edit Horse stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditHorse
	 @intHorseID				AS INTEGER
	,@strName					AS VARCHAR(50)			
	,@intBreedID				AS INTEGER		
	,@strRegistration			AS VARCHAR(50)			
	,@intColorID				AS INTEGER
	,@intSexID					AS INTEGER
	,@strHeight					AS VARCHAR(50)
	,@intHorseBuyerID			AS INTEGER			
	,@intHorseSellerID			AS INTEGER			
	,@strComments				AS VARCHAR(250)			
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION
	-- Update the record 
	UPDATE
		THorses
	SET
		 strName				= @strName
		,intBreedID				= @intBreedID
		,strRegistration		= @strRegistration
		,intColorID				= @intColorID
		,intSexID				= @intSexID
		,strHeight				= @strHeight
		,intHorseBuyerID		= @intHorseBuyerID
		,intHorseSellerID		= @intHorseSellerID
		,strComments			= @strComments
	WHERE
		intHorseID				= @intHorseID

COMMIT TRANSACTION

GO

-- SELECT * FROM THorses

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveHorses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveHorses
AS

SELECT 
	 	 intHorseID									-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 THorses 
WHERE
	intHorseStatusID = 1							-- 1 = Active
							
GO

-- SELECT * FROM VActiveHorses

-- --------------------------------------------------------------------------------
--  Create the view VInActiveHorses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveHorses
AS

SELECT 
	 	 intHorseID									-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 THorses 
WHERE
	intHorseStatusID = 2							-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveHorses

-- --------------------------------------------------------------------------------
--  Create the view VHorses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VHorses
AS

SELECT 
	  TH.intHorseID
	 ,TH.strName
	 ,THB.strBreed
	 ,TH.strRegistration
	 ,THC.strColor
	 ,THSEX.strSex
	 ,TH.strHeight
	 ,THBYR.strFullName AS Buyer
	 ,THSLR.strFullName AS Seller
	 ,TH.strComments
	 ,THSTAT.strHorseStatus
FROM     
	THorseBreeds AS THB
	 
		INNER JOIN THorses AS TH
        ON THB.intBreedID = TH.intBreedID 
		
		INNER JOIN THorseBuyers AS THBYR
        ON TH.intHorseBuyerID = THBYR.intHorseBuyerID 
		
		INNER JOIN THorseColors AS THC
        ON TH.intColorID = THC.intColorID 
		
		INNER JOIN THorseSellers AS THSLR
        ON TH.intHorseSellerID = THSLR.intHorseSellerID 
		
		INNER JOIN THorseSexes AS THSEX
        ON TH.intSexID = THSEX.intSexID 
		
		INNER JOIN THorseStatuses AS THSTAT
        ON TH.intHorseStatusID = THSTAT.intHorseStatusID

GO

-- SELECT * FROM VHorses


-- -----------------------------------------------------------------------------
--  Create uspSetShoeStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetShoeStatus
	 @intShoeID					AS INTEGER
	,@intShoeStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TShoes
SET
	 intShoeStatusID	= @intShoeStatusID
WHERE
		intShoeID 		= @intShoeID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddShoes
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddShoes
	 @strName					AS VARCHAR(50)
	,@dteshod					AS DATE
	,@strTrimAngle				AS VARCHAR(50)
	,@decFarrierCost			AS MONEY
	,@strComments				AS VARCHAR(250)
	,@intShoeStatusID			AS INTEGER

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION 

	DECLARE @intShoeID			 INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intShoeID = MAX( intShoeID ) + 1 FROM TShoes 

		-- Default to 1 if table is empty
		SELECT @intShoeID = COALESCE( @intShoeID, 1 )

		INSERT INTO TShoes( intShoeID, strName, dteshod, strTrimAngle, decFarrierCost, strComments,intShoeStatusID )
		VALUES( @intShoeID, @strName, @dteshod, @strTrimAngle, @decFarrierCost, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intShoeID AS intShoeID

COMMIT TRANSACTION

GO

-- SELECT * FROM TShoes

--------------------------------------------------------------------------------
--  Create a usp uspEditShoes stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditShoes
	 @intShoeID					AS INTEGER
	,@strName					AS VARCHAR(50)			
	,@dteshod					AS DATE		
	,@strTrimAngle				AS VARCHAR(50)			
	,@decFarrierCost			AS MONEY
	,@strComments				AS VARCHAR(250)	
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION
	-- Update the record 
	UPDATE
		TShoes
	SET
		 strName				= @strName
		,dteshod				= @dteshod
		,strTrimAngle			= @strTrimAngle
		,decFarrierCost			= @decFarrierCost
		,strComments			= @strComments
	WHERE
		intShoeID				= @intShoeID

COMMIT TRANSACTION

GO

-- SELECT * FROM TShoes

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveShoes
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveShoes
AS

SELECT 
	 	 intShoeID								-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TShoes 
WHERE
	intShoeStatusID = 1							-- 1 = Active
							
GO

-- SELECT * FROM VActiveShoes

-- --------------------------------------------------------------------------------
--  Create the view VInActiveShoes
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveShoes
AS

SELECT 
	 	 intShoeID								-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TShoes 
WHERE
	intShoeStatusID = 2							-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveShoes

-- --------------------------------------------------------------------------------
--  Create the view VShoes
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VShoes
AS

SELECT 
	 TSH.intShoeID								-- always get ID
	,TSH.strName									-- always get name
	,TSH.dteShod
	,TSH.strTrimAngle
	,TSH.decFarrierCost
	,TSH.strComments
	,TSHSTAT.strShoeStatus
															
FROM 	
 	TShoes AS TSH

		INNER JOIN TShoeStatuses AS TSHSTAT
        ON TSH.intShoeStatusID = TSHSTAT.intShoeStatusID 
							
GO

-- SELECT * FROM VShoes 

-- -----------------------------------------------------------------------------
--  Create uspSetVaccinationStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetVaccinationStatus
	 @intVaccinationID				AS INTEGER
	,@intVaccinationStatusID		AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TVaccinations
SET
	 intVaccinationStatusID	= @intVaccinationStatusID
WHERE
		intVaccinationID 	= @intVaccinationID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddVaccinations
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddVaccinations
	 @strName						AS VARCHAR(50)
	,@decVaccinationCost			AS MONEY
	,@dteVaccinationDate			AS DATE
	,@strComments					AS VARCHAR(250)
	,@intVaccinationStatusID		AS INTEGER

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION 

	DECLARE @intVaccinationID			INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intVaccinationID = MAX( intVaccinationID ) + 1 FROM TVaccinations 

		-- Default to 1 if table is empty
		SELECT @intVaccinationID = COALESCE( @intVaccinationID, 1 )

		INSERT INTO TVaccinations( intVaccinationID, strName, decVaccinationCost, dteVaccinationDate, strComments, intVaccinationStatusID )
		VALUES( @intVaccinationID, @strName, @decVaccinationCost, @dteVaccinationDate, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intVaccinationID AS intVaccinationID

COMMIT TRANSACTION

GO

-- SELECT * FROM TVaccinations

--------------------------------------------------------------------------------
--  Create a usp uspEditVaccinations stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditVaccinations
	 @intVaccinationID				AS INTEGER
	,@strName						AS VARCHAR(50)			
	,@decVaccinationCost			AS MONEY		
	,@dteVaccinationDate			AS DATE			
	,@strComments					AS VARCHAR(250)

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION
	-- Update the record 
	UPDATE
		TVaccinations
	SET
		 strName					= @strName
		,decVaccinationCost			= @decVaccinationCost
		,dteVaccinationDate			= @dteVaccinationDate
		,strComments				= @strComments
	WHERE
		intVaccinationID			= @intVaccinationID

COMMIT TRANSACTION

GO

-- SELECT * FROM TVaccinations

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveVaccinations
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveVaccinations
AS

SELECT 
	 	 intVaccinationID							-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 TVaccinations 
WHERE
	intVaccinationStatusID = 1						-- 1 = Active
							
GO

-- SELECT * FROM VActiveVaccinations

-- --------------------------------------------------------------------------------
--  Create the view VInActiveVaccinations
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveVaccinations
AS

SELECT 
	 	 intVaccinationID							-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 TVaccinations 
WHERE
	intVaccinationStatusID = 2						-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveVaccinations

-- --------------------------------------------------------------------------------
--  Create the view VVaccinations
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VVaccinations
AS

SELECT TVaccinations.intVaccinationID, TVaccinations.strName, TVaccinations.decVaccinationCost, TVaccinations.dteVaccinationDate, TVaccinations.strComments, TVaccinationStatuses.strVaccinationStatus
FROM     TVaccinations INNER JOIN
                  TVaccinationStatuses ON TVaccinations.intVaccinationStatusID = TVaccinationStatuses.intVaccinationStatusID
							
GO

-- SELECT * FROM VVaccinations

-- -----------------------------------------------------------------------------
--  Create uspSetWestNileTestStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetWestNileTestStatus
	 @intWestNileTestID				AS INTEGER
	,@intWestNileTestStatusID		AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TWestNileTests
SET
	 intWestNileTestStatusID	= @intWestNileTestStatusID
WHERE
		intWestNileTestID 		= @intWestNileTestID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddWestNileTests
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddWestNileTests
	 @strName						AS VARCHAR(50)
	,@dteWestNileTestDate			AS DATE
	,@decWestNileTestCost			AS MONEY
	,@strComments					AS VARCHAR(250)
	,@intWestNileTestStatusID		AS INTEGER

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION 

	DECLARE @intWestNileTestID			INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intWestNileTestID = MAX( intWestNileTestID ) + 1 FROM TWestNileTests 

		-- Default to 1 if table is empty
		SELECT @intWestNileTestID = COALESCE( @intWestNileTestID, 1 )

		INSERT INTO TWestNileTests( intWestNileTestID, strName, dteWestNileTestDate, decWestNileTestCost, strComments, intWestNileTestStatusID )
		VALUES( @intWestNileTestID, @strName, @dteWestNileTestDate, @decWestNileTestCost, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intWestNileTestID AS intWestNileTestID

COMMIT TRANSACTION

GO

-- SELECT * FROM TVaccinations

--------------------------------------------------------------------------------
--  Create a usp uspEditWestNileTests stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditWestNileTests
	 @intWestNileTestID				AS INTEGER
	,@strName						AS VARCHAR(50)
	,@dteWestNileTestDate			AS DATE
	,@decWestNileTestCost			AS MONEY
	,@strComments					AS VARCHAR(250)

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION
	-- Update the record 
	UPDATE
		TWestNileTests
	SET
		 strName					= @strName
		,dteWestNileTestDate		= @dteWestNileTestDate
		,decWestNileTestCost		= @decWestNileTestCost
		,strComments				= @strComments
	WHERE
		intWestNileTestID			= @intWestNileTestID

COMMIT TRANSACTION

GO

-- SELECT * FROM TWestNileTests

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveWestNileTests
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveWestNileTests
AS

SELECT 
	 	 intWestNileTestID							-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 TWestNileTests 
WHERE
	intWestNileTestStatusID = 1						-- 1 = Active
							
GO

-- SELECT * FROM VActiveWestNileTests

-- --------------------------------------------------------------------------------
--  Create the view VInActiveWestNileTests
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveWestNileTests
AS

SELECT 
	 	 intWestNileTestID							-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 TWestNileTests 
WHERE
	intWestNileTestStatusID = 2						-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveWestNileTests

-- --------------------------------------------------------------------------------
--  Create the view VWestNileTests
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VWestNileTests
AS

SELECT 
	 TWNT.intWestNileTestID
	 ,TWNT.strName
	 ,TWNT.dteWestNileTestDate
	 ,TWNT.decWestNileTestCost
	 ,TWNT.strComments
	 ,TWNTS.strWestNileTestStatus

FROM     
	TWestNileTests AS TWNT
			
			INNER JOIN TWestNileTestStatuses AS TWNTS
            ON TWNT.intWestNileTestStatusID = TWNTS.intWestNileTestStatusID
							
GO

-- SELECT * FROM VWestNileTests

-- -----------------------------------------------------------------------------
--  Create uspSetDewormerStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetDewormerStatus
	 @intDewormerID					AS INTEGER
	,@intDewormerStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TDewormers
SET
	 intDewormerStatusID	= @intDewormerStatusID
WHERE
		intDewormerID 		= @intDewormerID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddDewormers
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddDewormers
	 @strName						AS VARCHAR(50)
	,@dteDewormerDate				AS DATE
	,@decDewormerCost				AS MONEY
	,@intDewormerStatusID			AS INTEGER

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	

	DECLARE @intDewormerID			   INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intDewormerID = MAX( intDewormerID ) + 1 FROM TDewormers 

		-- Default to 1 if table is empty
		SELECT @intDewormerID = COALESCE( @intDewormerID, 1 )

		INSERT INTO TDewormers( intDewormerID, strName, dteDewormerDate, decDewormerCost, intDewormerStatusID )
		VALUES( @intDewormerID, @strName, @dteDewormerDate, @decDewormerCost, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intDewormerID AS intDewormerID

COMMIT TRANSACTION

GO

-- SELECT * FROM TDewormers

--------------------------------------------------------------------------------
--  Create a usp uspEditDewormers stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditDewormers
	 @intDewormerID					AS INTEGER
	,@strName						AS VARCHAR(50)
	,@dteDewormerDate				AS DATE
	,@decDewormerCost				AS MONEY

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION
	-- Update the record 
	UPDATE
		TDewormers	
	SET
		 strName				= @strName
		,dteDewormerDate		= @dteDewormerDate
		,decDewormerCost		= @decDewormerCost
	WHERE
		intDewormerID			= @intDewormerID

COMMIT TRANSACTION

GO

-- SELECT * FROM TDewormers

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveDewormers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveDewormers
AS

SELECT 
	 	 intDewormerID							-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TDewormers 
WHERE
	intDewormerStatusID = 1						-- 1 = Active
							
GO

-- SELECT * FROM VActiveDewormers

-- --------------------------------------------------------------------------------
--  Create the view VInActiveDewormers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveDewormers
AS

SELECT 
	 	 intDewormerID							-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TDewormers 
WHERE
	intDewormerStatusID = 2						-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveDewormers

-- --------------------------------------------------------------------------------
--  Create the view VDewormers
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VDewormers
AS

SELECT 
	 TD.intDewormerID
	 ,TD.strName
	 ,TD.dteDewormerDate
	 ,TD.decDewormerCost
	 ,TDSTAT.strDewormerStatus

FROM     
	TDewormers AS TD
	
		INNER JOIN TDewormerStatuses AS TDSTAT
        ON TD.intDewormerStatusID = TDSTAT.intDewormerStatusID
							
GO

-- SELECT * FROM VDewormers

-- -----------------------------------------------------------------------------
--  Create uspSetHealthCertificateStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetHealthCertificateStatus
	 @intHealthCertificateID					AS INTEGER
	,@intHealthCertificateStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	THealthCertificates
SET
	 intHealthCertificateStatusID	= @intHealthCertificateStatusID
WHERE
		intHealthCertificateID 		= @intHealthCertificateID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddHealthCertificates
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddHealthCertificates
	 @strName								AS VARCHAR(50)
	,@dteHealthCertificateDate				AS DATE
	,@decHealthCertificateCost				AS MONEY
	,@strComments							AS VARCHAR(250)
	,@intHealthCertificateStatusID			AS INTEGER	

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	

	DECLARE @intHealthCertificateID			   INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intHealthCertificateID = MAX( intHealthCertificateID ) + 1 FROM THealthCertificates 

		-- Default to 1 if table is empty
		SELECT @intHealthCertificateID = COALESCE( @intHealthCertificateID, 1 )

		INSERT INTO THealthCertificates( intHealthCertificateID, strName, dteHealthCertificateDate, decHealthCertificateCost, strComments, intHealthCertificateStatusID )
		VALUES( @intHealthCertificateID, @strName, @dteHealthCertificateDate, @decHealthCertificateCost, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intHealthCertificateID AS intHealthCertificateID

COMMIT TRANSACTION

GO

-- SELECT * FROM THealthCertificates

--------------------------------------------------------------------------------
--  Create a usp uspEditHealthCertificates stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditHealthCertificates
	 @intHealthCertificateID				AS INTEGER
	,@strName								AS VARCHAR(50)
	,@dteHealthCertificateDate				AS DATE
	,@decHealthCertificateCost				AS MONEY
	,@strComments							AS VARCHAR(250)
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	
	-- Update the record 
	UPDATE
		THealthCertificates	
	SET
		 strName						= @strName
		,dteHealthCertificateDate		= @dteHealthCertificateDate
		,decHealthCertificateCost		= @decHealthCertificateCost
		,strComments					= @strComments
	WHERE
		intHealthCertificateID			= @intHealthCertificateID

COMMIT TRANSACTION

GO

-- SELECT * FROM THealthCertificates

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveHealthCertificates
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveHealthCertificates
AS

SELECT 
	 	 intHealthCertificateID						-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 THealthCertificates 
WHERE
	intHealthCertificateStatusID = 1				-- 1 = Active
							
GO

-- SELECT * FROM VActiveHealthCertificates

-- --------------------------------------------------------------------------------
--  Create the view VInActiveHealthCertificates
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveHealthCertificates
AS

SELECT 
	 	 intHealthCertificateID						-- always get ID
	 	,strName									-- always get name				
FROM 	
 		 THealthCertificates 
WHERE
	intHealthCertificateStatusID = 2				-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveHealthCertificates

-- --------------------------------------------------------------------------------
--  Create the view VHealthCertificates
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VHealthCertificates
AS

SELECT 
	 THCERT.intHealthCertificateID
	 ,THCERT.strName
	 ,THCERT.dteHealthCertificateDate
	 ,THCERT.decHealthCertificateCost
	 ,THCERT.strComments
	 ,THCERTSTAT.strHealthCertificateStatus

FROM     
	THealthCertificates AS THCERT
	
		INNER JOIN THealthCertificateStatuses AS THCERTSTAT
        ON THCERT.intHealthCertificateStatusID = THCERTSTAT.intHealthCertificateStatusID
							
GO

-- SELECT * FROM VHealthCertificates

-- -----------------------------------------------------------------------------
--  Create uspSetFeedMiscExpenseStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetFeedMiscExpenseStatus
	 @intFeedMiscExpenseID					AS INTEGER
	,@intFeedMiscExpenseStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TFeedMiscExpenses
SET
	 intFeedMiscExpenseStatusID	= @intFeedMiscExpenseStatusID
WHERE
		intFeedMiscExpenseID 	= @intFeedMiscExpenseID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddFeedMiscExpenses
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddFeedMiscExpenses
	 @strName								AS VARCHAR(50)
	,@decExpenseCost						AS MONEY
	,@dteDatePurchased						AS DATE
	,@strComments							AS VARCHAR(250)
	,@intFeedMiscExpenseStatusID			AS INTEGER	

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	

	DECLARE @intFeedMiscExpenseID			   INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intFeedMiscExpenseID = MAX( intFeedMiscExpenseID ) + 1 FROM TFeedMiscExpenses 

		-- Default to 1 if table is empty
		SELECT @intFeedMiscExpenseID = COALESCE( @intFeedMiscExpenseID, 1 )

		INSERT INTO TFeedMiscExpenses( intFeedMiscExpenseID, strName, decExpenseCost, dteDatePurchased, strComments, intFeedMiscExpenseStatusID )
		VALUES( @intFeedMiscExpenseID, @strName, @decExpenseCost, @dteDatePurchased, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intFeedMiscExpenseID AS intFeedMiscExpenseID

COMMIT TRANSACTION

GO

-- SELECT * FROM TFeedMiscExpenses

--------------------------------------------------------------------------------
--  Create a usp uspEditFeedMiscExpenses stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditFeedMiscExpenses
	 @intFeedMiscExpenseID					AS INTEGER
	,@strName								AS VARCHAR(50)
	,@decExpenseCost						AS MONEY
	,@dteDatePurchased						AS DATE
	,@strComments							AS VARCHAR(250)
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	
	-- Update the record 
	UPDATE
		TFeedMiscExpenses	
	SET
		 strName						= @strName
		,decExpenseCost					= @decExpenseCost
		,dteDatePurchased				= @dteDatePurchased
		,strComments					= @strComments
	WHERE
		intFeedMiscExpenseID			= @intFeedMiscExpenseID

COMMIT TRANSACTION

GO

-- SELECT * FROM TFeedMiscExpenses

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveFeedMiscExpenses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveFeedMiscExpenses
AS

SELECT 
	 	 intFeedMiscExpenseID					-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TFeedMiscExpenses 
WHERE
	intFeedMiscExpenseStatusID = 1				-- 1 = Active
							
GO

-- SELECT * FROM VActiveFeedMiscExpenses

-- --------------------------------------------------------------------------------
--  Create the view VInActiveFeedMiscExpenses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveFeedMiscExpenses
AS

SELECT 
	 	 intFeedMiscExpenseID					-- always get ID
	 	,strName								-- always get name				
FROM 	
 		 TFeedMiscExpenses 
WHERE
	intFeedMiscExpenseStatusID = 2				-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveFeedMiscExpenses

-- --------------------------------------------------------------------------------
--  Create the view VFeedMiscExpenses
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VFeedMiscExpenses
AS

SELECT 
	 TFME.intFeedMiscExpenseID
	 ,TFME.strName
	 ,TFME.decExpenseCost
	 ,TFME.dteDatePurchased
	 ,TFME.strComments
	 ,TFMESTAT.strFeedMiscExpenseStatus

FROM     
	TFeedMiscExpenses AS TFME
	 
		INNER JOIN TFeedMiscExpenseStatuses AS TFMESTAT
        ON TFME.intFeedMiscExpenseStatusID = TFMESTAT.intFeedMiscExpenseStatusID
							
GO

-- SELECT * FROM VFeedMiscExpenses

-- -----------------------------------------------------------------------------
--  Create uspSetEquipmentStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetEquipmentStatus
	 @intEquipmentID					AS INTEGER
	,@intEquipmentStatusID				AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TEquipment
SET
	 intEquipmentStatusID	= @intEquipmentStatusID
WHERE
		intEquipmentID 	= @intEquipmentID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddEquipment
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddEquipment
	 @strName							AS VARCHAR(50)
	,@dtePurchaseDate					AS DATE
	,@decCost							AS MONEY
	,@strComments						AS VARCHAR(250)
	,@intEquipmentStatusID				AS INTEGER	

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	
	DECLARE @intEquipmentID			   INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intEquipmentID = MAX( intEquipmentID ) + 1 FROM TEquipment 

		-- Default to 1 if table is empty
		SELECT @intEquipmentID = COALESCE( @intEquipmentID, 1 )

		INSERT INTO TEquipment( intEquipmentID, strName, dtePurchaseDate, decCost, strComments, intEquipmentStatusID )
		VALUES( @intEquipmentID, @strName, @dtePurchaseDate, @decCost, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intEquipmentID AS intEquipmentID

COMMIT TRANSACTION

GO

-- SELECT * FROM TEquipment

--------------------------------------------------------------------------------
--  Create a usp uspEditEquipment stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditEquipment
	 @intEquipmentID					AS INTEGER
	,@strName							AS VARCHAR(50)
	,@dtePurchaseDate					AS DATE
	,@decCost							AS MONEY
	,@strComments						AS VARCHAR(250)
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	
	-- Update the record 
	UPDATE
		TEquipment	
	SET
		 strName						= @strName
		,dtePurchaseDate				= @dtePurchaseDate
		,decCost						= @decCost
		,strComments					= @strComments
	WHERE
		intEquipmentID					= @intEquipmentID

COMMIT TRANSACTION

GO

-- SELECT * FROM TEquipment

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveEquipment
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveEquipment
AS

SELECT 
	 	 intEquipmentID						-- always get ID
	 	,strName							-- always get name				
FROM 	
 		 TEquipment 
WHERE
	intEquipmentStatusID = 1				-- 1 = Active
							
GO

-- SELECT * FROM VActiveEquipment

-- --------------------------------------------------------------------------------
--  Create the view VInActiveEquipment
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveEquipment
AS

SELECT 
	 	 intEquipmentID						-- always get ID
	 	,strName							-- always get name				
FROM 	
 		 TEquipment 
WHERE
	intEquipmentStatusID = 2				-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveEquipment

-- --------------------------------------------------------------------------------
--  Create the view VEquipment
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VEquipment
AS

SELECT 
	 TE.intEquipmentID
	 ,TE.strName
	 ,TE.dtePurchaseDate
	 ,TE.decCost
	 ,TE.strComments
	 ,TESTAT.strEquipmentStatus

FROM     
	TEquipment AS TE
		
		INNER JOIN TEquipmentStatuses AS TESTAT
        ON TE.intEquipmentStatusID = TESTAT.intEquipmentStatusID
							
GO

-- SELECT * FROM VEquipment

-- -----------------------------------------------------------------------------
--  Create uspSetMaintenanceStatus stored procedure
-- -----------------------------------------------------------------------------
GO

CREATE PROCEDURE uspSetMaintenanceStatus
	 @intMaintenanceID					AS INTEGER
	,@intMaintenanceStatusID			AS INTEGER
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

-- Update the record 
UPDATE
	TMaintenance
SET
	 intMaintenanceStatusID	= @intMaintenanceStatusID
WHERE
		intMaintenanceID 	= @intMaintenanceID

GO

-- --------------------------------------------------------------------------------
-- Create uspAddMaintenance
-- --------------------------------------------------------------------------------
GO
Create Procedure uspAddMaintenance
	 @strName							AS VARCHAR(50)
	,@dteMaintenanceDate				AS DATE
	,@decMaintenanceCost				AS MONEY
	,@strComments						AS VARCHAR(250)
	,@intMaintenanceStatusID			AS INTEGER	

AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	

	DECLARE @intMaintenanceID			   INTEGER 

		-- Get the next highest ID and lock the table until the end of the transaction
		SELECT @intMaintenanceID = MAX( intMaintenanceID ) + 1 FROM TMaintenance 

		-- Default to 1 if table is empty
		SELECT @intMaintenanceID = COALESCE( @intMaintenanceID, 1 )

		INSERT INTO TMaintenance( intMaintenanceID, strName, dteMaintenanceDate, decMaintenanceCost, strComments, intMaintenanceStatusID )
		VALUES( @intMaintenanceID, @strName, @dteMaintenanceDate, @decMaintenanceCost, @strComments, 1 )	-- 1 Active

	-- Return ID to caller
	SELECT @intMaintenanceID AS intMaintenanceID

COMMIT TRANSACTION

GO

-- SELECT * FROM TMaintenance

--------------------------------------------------------------------------------
--  Create a usp uspEditMaintenance stored procedure
--------------------------------------------------------------------------------
GO

CREATE PROCEDURE uspEditMaintenance
	 @intMaintenanceID					AS INTEGER
	,@strName							AS VARCHAR(50)
	,@dteMaintenanceDate				AS DATE
	,@decMaintenanceCost				AS MONEY
	,@strComments						AS VARCHAR(250)
	
AS
SET NOCOUNT ON		-- Report only errors
SET XACT_ABORT ON	-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION	
	-- Update the record 
	UPDATE
		TMaintenance	
	SET
		 strName						= @strName
		,dteMaintenanceDate				= @dteMaintenanceDate
		,decMaintenanceCost				= @decMaintenanceCost
		,strComments					= @strComments
	WHERE
		intMaintenanceID				= @intMaintenanceID

COMMIT TRANSACTION

GO

-- SELECT * FROM TMaintenance

-- --------------------------------------------------------------------------------
-- Step #10: Create the view VActiveMaintenance
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VActiveMaintenance
AS

SELECT 
	 	 intMaintenanceID					-- always get ID
	 	,strName							-- always get name				
FROM 	
 		 TMaintenance 
WHERE
	intMaintenanceStatusID = 1				-- 1 = Active
							
GO

-- SELECT * FROM VActiveMaintenance

-- --------------------------------------------------------------------------------
--  Create the view VInActiveMaintenance
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VInActiveMaintenance
AS

SELECT 
	 	 intMaintenanceID					-- always get ID
	 	,strName							-- always get name				
FROM 	
 		 TMaintenance 
WHERE
	intMaintenanceStatusID = 2				-- 2 = InActive
							
GO

-- SELECT * FROM VInActiveMaintenance

-- --------------------------------------------------------------------------------
--  Create the view VMaintenance
-- --------------------------------------------------------------------------------	
GO

CREATE VIEW VMaintenance
AS

SELECT 
	 TM.intMaintenanceID
	 ,TM.strName
	 ,TM.dteMaintenanceDate
	 ,TM.decMaintenanceCost
	 ,TM.strComments
	 ,TMSTAT.strMaintenanceStatus

FROM     
	TMaintenance AS TM
	
		INNER JOIN TMaintenanceStatuses AS TMSTAT
        ON TM.intMaintenanceStatusID = TMSTAT.intMaintenanceStatusID 
							
GO

-- SELECT * FROM VMaintenance

--------------------------------------------------------------------------------
-- Create a uspAddHorseShoe stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddHorseShoe
	 @intHorseID						AS INTEGER
	,@intShoeID							AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		THorseShoes ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID	= @intHorseID
		AND intShoeID	= @intShoeID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO THorseShoes( intHorseID, intShoeID )
		VALUES( @intHorseID , @intShoeID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableShoesToHorse stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableShoesToHorse
	 @intHorseID						AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO THorseShoes( intHorseID, intShoeID )
	(
		-- Add all available active players to team ...
		SELECT
			@intHorseID
			,intShoeID 
		FROM
			VActiveShoes( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intShoeID NOT IN
			(
				SELECT	
					intShoeID
				FROM
					THorseShoes
				WHERE
					intHorseID		= @intHorseID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveHorseShoe stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveHorseShoe
	 @intHorseID					AS INTEGER
	,@intShoeID						AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		THorseShoes ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID		= @intHorseID
		AND intShoeID		= @intShoeID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			THorseShoes
		WHERE
			intHorseID		= @intHorseID
		AND intShoeID		= @intShoeID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllHorseShoes stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllHorseShoes
	 @intHorseID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		THorseShoes
	WHERE
		intHorseID		= @intHorseID

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddHorseVaccination stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddHorseVaccination
	 @intHorseID					AS INTEGER
	,@intVaccinationID				AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		THorseVaccinations ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID			= @intHorseID
		AND intVaccinationID	= @intVaccinationID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO THorseVaccinations( intHorseID, intVaccinationID )
		VALUES( @intHorseID , @intVaccinationID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableVaccinationsToHorse stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableVaccinationsToHorse
	 @intHorseID					AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO THorseVaccinations( intHorseID, intVaccinationID )
	(
		-- Add all available active players to team ...
		SELECT
			@intHorseID
			,intVaccinationID 
		FROM
			VActiveVaccinations( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intVaccinationID NOT IN
			(
				SELECT	
					intVaccinationID
				FROM
					THorseVaccinations
				WHERE
					intHorseID = @intHorseID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveHorseVaccination stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveHorseVaccination
	 @intHorseID					AS INTEGER
	,@intVaccinationID				AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		THorseVaccinations ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID			= @intHorseID
		AND intVaccinationID	= @intVaccinationID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			THorseVaccinations
		WHERE
			intHorseID			= @intHorseID
		AND intVaccinationID	= @intVaccinationID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllHorseVaccinations stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllHorseVaccinations
	 @intHorseID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		THorseVaccinations
	WHERE
		intHorseID	= @intHorseID

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddHorseWestNileTest stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddHorseWestNileTest
	 @intHorseID					AS INTEGER
	,@intWestNileTestID				AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		THorseWestNileTests ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID			= @intHorseID
		AND intWestNileTestID	= @intWestNileTestID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO THorseWestNileTests( intHorseID, intWestNileTestID )
		VALUES( @intHorseID , @intWestNileTestID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableWestNileTestsToHorse stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableWestNileTestsToHorse
	 @intHorseID					AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO THorseWestNileTests( intHorseID, intWestNileTestID )
	(
		-- Add all available active players to team ...
		SELECT
			@intHorseID
			,intWestNileTestID 
		FROM
			VActiveWestNileTests( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intWestNileTestID NOT IN
			(
				SELECT	
					intWestNileTestID
				FROM
					THorseWestNileTests
				WHERE
					intHorseID = @intHorseID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveHorseWestNileTest stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveHorseWestNileTest
	 @intHorseID					AS INTEGER
	,@intWestNileTestID				AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		THorseWestNileTests ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID			= @intHorseID
		AND intWestNileTestID	= @intWestNileTestID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			THorseWestNileTests
		WHERE
			intHorseID			= @intHorseID
		AND intWestNileTestID	= @intWestNileTestID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllHorseWestNileTests stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllHorseWestNileTests
	 @intHorseID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		THorseWestNileTests
	WHERE
		intHorseID = @intHorseID

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddHorseDewormer stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddHorseDewormer
	 @intHorseID					AS INTEGER
	,@intDewormerID					AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		THorseDewormers ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID		= @intHorseID
		AND intDewormerID	= @intDewormerID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO THorseDewormers( intHorseID, intDewormerID )
		VALUES( @intHorseID , @intDewormerID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableDewormersToHorse stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableDewormersToHorse
	 @intHorseID					AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO THorseDewormers( intHorseID, intDewormerID )
	(
		-- Add all available active players to team ...
		SELECT
			@intHorseID
			,intDewormerID 
		FROM
			VActiveDewormers( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intDewormerID NOT IN
			(
				SELECT	
					intDewormerID
				FROM
					THorseDewormers
				WHERE
					intHorseID	= @intHorseID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveHorseDewormer stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveHorseDewormer
	 @intHorseID					AS INTEGER
	,@intDewormerID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		THorseDewormers ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID		= @intHorseID
		AND intDewormerID	= @intDewormerID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			THorseDewormers
		WHERE
			intHorseID		= @intHorseID
		AND intDewormerID	= @intDewormerID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllHorseDewormers stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllHorseDewormers
	 @intHorseID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		THorseDewormers
	WHERE
		intHorseID	= @intHorseID

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddHorseHealthCertificate stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddHorseHealthCertificate
	 @intHorseID						AS INTEGER
	,@intHealthCertificateID			AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		THorseHealthCertificates ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID				= @intHorseID
		AND intHealthCertificateID	= @intHealthCertificateID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO THorseHealthCertificates( intHorseID, intHealthCertificateID )
		VALUES( @intHorseID , @intHealthCertificateID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableHealthCertificatesToHorse stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableHealthCertificatesToHorse
	 @intHorseID				AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO THorseHealthCertificates( intHorseID, intHealthCertificateID )
	(
		-- Add all available active players to team ...
		SELECT
			@intHorseID
			,intHealthCertificateID 
		FROM
			VActiveHealthCertificates( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intHealthCertificateID NOT IN
			(
				SELECT	
					intHealthCertificateID
				FROM
					THorseHealthCertificates
				WHERE
					intHorseID = @intHorseID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveHorseHealthCertificate stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveHorseHealthCertificate
	 @intHorseID						AS INTEGER
	,@intHealthCertificateID			AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		THorseHealthCertificates ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intHorseID	= @intHorseID
		AND intHealthCertificateID	= @intHealthCertificateID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			THorseHealthCertificates
		WHERE
			intHorseID				= @intHorseID
		AND intHealthCertificateID	= @intHealthCertificateID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllHorseHealthCertificates stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllHorseHealthCertificates
	 @intHorseID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		THorseHealthCertificates
	WHERE
		intHorseID	= @intHorseID

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddEquipmentMaintenance stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddEquipmentMaintenance
	 @intEquipmentID					AS INTEGER
	,@intMaintenanceID					AS INTEGER
AS
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

DECLARE @blnInAlreadyExists AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnInAlreadyExists = 1
	FROM
		TEquipmentMaintenance ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intEquipmentID			= @intEquipmentID
		AND intMaintenanceID		= @intMaintenanceID

	IF @blnInAlreadyExists = 0
	BEGIN	
		INSERT INTO TEquipmentMaintenance( intEquipmentID, intMaintenanceID )
		VALUES( @intEquipmentID , @intMaintenanceID )
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspAddAllAvailableEquipmentMaintenanceToEquipment stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspAddAllAvailableMaintenanceToEquipment
	 @intEquipmentID						AS INTEGER
AS

SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
BEGIN TRANSACTION						
 	
	INSERT INTO TEquipmentMaintenance( intEquipmentID, intMaintenanceID )
	(
		-- Add all available active players to team ...
		SELECT
			@intEquipmentID
			,intMaintenanceID 
		FROM
			VActiveMaintenance( TABLOCKX )  -- Lock table until end of transaction
		WHERE
			-- ... that are not already on the team
			intMaintenanceID NOT IN
			(
				SELECT	
					intMaintenanceID
				FROM
					TEquipmentMaintenance
				WHERE
					intEquipmentID	= @intEquipmentID
			)
	)

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveEquipmentMaintenance stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveEquipmentMaintenance
	 @intEquipmentID						AS INTEGER
	,@intMaintenanceID						AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error
 
DECLARE @blnDoesNotExist AS BIT  = 0		-- false, does not exist
 
BEGIN TRANSACTION						
 	
	SELECT
		@blnDoesNotExist = 1		-- True, does exist
	FROM
		TEquipmentMaintenance ( TABLOCKX )  -- Lock table until end of transaction
	WHERE
			intEquipmentID			= @intEquipmentID
		AND intMaintenanceID		= @intMaintenanceID

	IF @blnDoesNotExist = 1
	BEGIN
		DELETE
		FROM
			TEquipmentMaintenance
		WHERE
			intEquipmentID			= @intEquipmentID
		AND intMaintenanceID		= @intMaintenanceID
	END

COMMIT TRANSACTION

GO

--------------------------------------------------------------------------------
-- Create a uspRemoveAllEquipmentMaintenance stored procedure
-------------------------------------------------------------------------------- 
 GO

 CREATE PROCEDURE uspRemoveAllEquipmentMaintenance
	 @intEquipmentID					AS INTEGER
AS
	
SET NOCOUNT ON			-- Report only errors
SET XACT_ABORT ON		-- Terminate and rollback entire transaction on error

BEGIN TRANSACTION						
 	
	DELETE FROM
		TEquipmentMaintenance
	WHERE
		intEquipmentID	= @intEquipmentID

COMMIT TRANSACTION