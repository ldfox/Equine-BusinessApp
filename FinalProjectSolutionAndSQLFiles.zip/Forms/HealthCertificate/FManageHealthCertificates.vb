﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageHealthCertificates
' Abstract: Capstone Horse project- Manage the horses Health Certificates (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageHealthCertificates


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadHealthCertificatesList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the horse HealthCertificates list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadHealthCertificatesList
    ' Abstract: Load the horse HealthCertificates list.
    ' --------------------------------------------------------------------------------
    Private Function LoadHealthCertificatesList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveHealthCertificates"

            Else

                strSourceTable = "VInActiveHealthCertificates"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intHealthCertificateID", _
                                                        "strName", _
                                                        lstHealthCertificates)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse HealthCertificate form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewHealthCertificateInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddHealthCertificate forms
            Dim frmAddHealthCertificate As FAddHealthCertificate

            ' Make an instance
            frmAddHealthCertificate = New FAddHealthCertificate

            ' Show modally
            frmAddHealthCertificate.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddHealthCertificate.GetResult() = True Then

                ' Get the new HealthCertificate values
                liNewHealthCertificateInformation = frmAddHealthCertificate.GetNewHealthCertificateInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstHealthCertificates.Items.Add(liNewHealthCertificateInformation)

                ' ... which we can use to select it
                lstHealthCertificates.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse HealthCertificate.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedHealthCertificateID As Integer
            Dim liSelectedHealthCertificate As CListItem
            Dim frmEditHealthCertificate As FEditHealthCertificate
            Dim liNewHealthCertificateInformation As CListItem
            Dim intIndex As Integer

            ' Is a HealthCertificate selected?
            If lstHealthCertificates.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a HealthCertificate to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the HealthCertificate to edit ID
                liSelectedHealthCertificate = lstHealthCertificates.SelectedItem
                intSelectedHealthCertificateID = liSelectedHealthCertificate.GetID

                ' Create instance
                frmEditHealthCertificate = New FEditHealthCertificate

                ' Set the form values
                frmEditHealthCertificate.SetHealthCertificateID(intSelectedHealthCertificateID)

                ' Show it modally   
                frmEditHealthCertificate.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditHealthCertificate.GetResult() = True Then

                    ' Get the new HealthCertificate values
                    liNewHealthCertificateInformation = frmEditHealthCertificate.GetNewHealthCertificateInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstHealthCertificates.Items.RemoveAt(lstHealthCertificates.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstHealthCertificates.Items.Add(liNewHealthCertificateInformation)

                    ' ... which we can use to select it
                    lstHealthCertificates.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse HealthCertificate.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteHealthCertificate()

            Else

                ' No, undelete
                UndeleteHealthCertificate()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHealthCertificate
    ' Abstract: Delete the currently selected HealthCertificate.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteHealthCertificate()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHealthCertificate As CListItem
            Dim intSelectedHealthCertificateID As Integer
            Dim strSelectedHealthCertificateName As String
            Dim intSelectedHealthCertificateIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a HealthCertificate selected?
            If lstHealthCertificates.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Health Certificate to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the HealthCertificate ID, name and list index
                liSelectedHealthCertificate = lstHealthCertificates.SelectedItem
                intSelectedHealthCertificateID = liSelectedHealthCertificate.GetID
                strSelectedHealthCertificateName = liSelectedHealthCertificate.GetName
                intSelectedHealthCertificateIndex = lstHealthCertificates.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete horse Health Certificate: " & strSelectedHealthCertificateName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the HealthCertificate (use ID for database command)
                    blnResult = DeleteHealthCertificateFromDatabase(intSelectedHealthCertificateID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the HealthCertificate from the list
                        lstHealthCertificates.Items.RemoveAt(intSelectedHealthCertificateIndex)

                        ' Select the next HealthCertificate in the list
                        HighlightNextItemInList(lstHealthCertificates, intSelectedHealthCertificateIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHealthCertificate
    ' Abstract: Undelete the currently selected HealthCertificate.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteHealthCertificate()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedHealthCertificate As CListItem
            Dim intSelectedHealthCertificateID As Integer
            Dim intSelectedHealthCertificateIndex As Integer
            Dim blnResult As Boolean

            ' Is a HealthCertificate selected?
            If lstHealthCertificates.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a horse Health Certificate to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the HealthCertificate ID and list index
                liSelectedHealthCertificate = lstHealthCertificates.SelectedItem
                intSelectedHealthCertificateID = liSelectedHealthCertificate.GetID
                intSelectedHealthCertificateIndex = lstHealthCertificates.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the HealthCertificate (use ID for database command)
                blnResult = UndeleteHealthCertificateFromDatabase(intSelectedHealthCertificateID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the HealthCertificate from the list
                    lstHealthCertificates.Items.RemoveAt(intSelectedHealthCertificateIndex)

                    ' Select the next HealthCertificate in the list
                    HighlightNextItemInList(lstHealthCertificates, intSelectedHealthCertificateIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the HealthCertificates list
            LoadHealthCertificatesList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VHealthCertificatesTableAdapter.Fill(Me.CPDM_FoxLHealthCertificatesDS.VHealthCertificates)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageHealthCertificates_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLHealthCertificatesDS.VHealthCertificates' table.
    '    Me.VHealthCertificatesTableAdapter.Fill(Me.CPDM_FoxLHealthCertificatesDS.VHealthCertificates)

    'End Sub

End Class