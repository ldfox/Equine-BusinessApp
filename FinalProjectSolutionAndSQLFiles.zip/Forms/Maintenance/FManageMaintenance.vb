﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageMaintenance
' Abstract: Capstone Horse project- Manage the Maintenance (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageMaintenance


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadMaintenanceList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the Maintenance list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadMaintenanceList
    ' Abstract: Load the Maintenance list.
    ' --------------------------------------------------------------------------------
    Private Function LoadMaintenanceList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveMaintenance"

            Else

                strSourceTable = "VInActiveMaintenance"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intMaintenanceID", _
                                                        "strName", _
                                                        lstMaintenance)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse Maintenance form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewMaintenanceInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddMaintenance forms
            Dim frmAddMaintenance As FAddMaintenance

            ' Make an instance
            frmAddMaintenance = New FAddMaintenance

            ' Show modally
            frmAddMaintenance.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add successful?
            If frmAddMaintenance.GetResult() = True Then

                ' Get the new Maintenance values
                liNewMaintenanceInformation = frmAddMaintenance.GetNewMaintenanceInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstMaintenance.Items.Add(liNewMaintenanceInformation)

                ' ... which we can use to select it
                lstMaintenance.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected Maintenance.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedMaintenanceID As Integer
            Dim liSelectedMaintenance As CListItem
            Dim frmEditMaintenance As FEditMaintenance
            Dim liNewMaintenanceInformation As CListItem
            Dim intIndex As Integer

            ' Is a Maintenance selected?
            If lstMaintenance.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Maintenance to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the Maintenance to edit ID
                liSelectedMaintenance = lstMaintenance.SelectedItem
                intSelectedMaintenanceID = liSelectedMaintenance.GetID

                ' Create instance
                frmEditMaintenance = New FEditMaintenance

                ' Set the form values
                frmEditMaintenance.SetMaintenanceID(intSelectedMaintenanceID)

                ' Show it modally   
                frmEditMaintenance.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditMaintenance.GetResult() = True Then

                    ' Get the new Maintenance values
                    liNewMaintenanceInformation = frmEditMaintenance.GetNewMaintenanceInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstMaintenance.Items.RemoveAt(lstMaintenance.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstMaintenance.Items.Add(liNewMaintenanceInformation)

                    ' ... which we can use to select it
                    lstMaintenance.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected Maintenance.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteMaintenance()

            Else

                ' No, undelete
                UndeleteMaintenance()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteMaintenance
    ' Abstract: Delete the currently selected Maintenance.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteMaintenance()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedMaintenance As CListItem
            Dim intSelectedMaintenanceID As Integer
            Dim strSelectedMaintenanceName As String
            Dim intSelectedMaintenanceIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Maintenance selected?
            If lstMaintenance.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Maintenance to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Maintenance ID, name and list index
                liSelectedMaintenance = lstMaintenance.SelectedItem
                intSelectedMaintenanceID = liSelectedMaintenance.GetID
                strSelectedMaintenanceName = liSelectedMaintenance.GetName
                intSelectedMaintenanceIndex = lstMaintenance.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Maintenance: " & strSelectedMaintenanceName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Maintenance (use ID for database command)
                    blnResult = DeleteMaintenanceFromDatabase(intSelectedMaintenanceID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Maintenance from the list
                        lstMaintenance.Items.RemoveAt(intSelectedMaintenanceIndex)

                        ' Select the next Maintenance in the list
                        HighlightNextItemInList(lstMaintenance, intSelectedMaintenanceIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteMaintenance
    ' Abstract: Undelete the currently selected Maintenance.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteMaintenance()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedMaintenance As CListItem
            Dim intSelectedMaintenanceID As Integer
            Dim intSelectedMaintenanceIndex As Integer
            Dim blnResult As Boolean

            ' Is a Maintenance selected?
            If lstMaintenance.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Maintenance to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Maintenance ID and list index
                liSelectedMaintenance = lstMaintenance.SelectedItem
                intSelectedMaintenanceID = liSelectedMaintenance.GetID
                intSelectedMaintenanceIndex = lstMaintenance.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Maintenance (use ID for database command)
                blnResult = UndeleteMaintenanceFromDatabase(intSelectedMaintenanceID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Maintenance from the list
                    lstMaintenance.Items.RemoveAt(intSelectedMaintenanceIndex)

                    ' Select the next Maintenance in the list
                    HighlightNextItemInList(lstMaintenance, intSelectedMaintenanceIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Maintenance list
            LoadMaintenanceList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VMaintenanceTableAdapter.Fill(Me.CPDM_FoxLMaintenanceDS.VMaintenance)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageMaintenance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLMaintenanceDS.VMaintenance' table.
    '    Me.VMaintenanceTableAdapter.Fill(Me.CPDM_FoxLMaintenanceDS.VMaintenance)
    'End Sub

End Class