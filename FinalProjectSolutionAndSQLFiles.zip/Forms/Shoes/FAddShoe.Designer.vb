﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAddShoe
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtFarrierCost = New System.Windows.Forms.TextBox()
        Me.txtTrimAngle = New System.Windows.Forms.TextBox()
        Me.txtDateShod = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblComments = New System.Windows.Forms.Label()
        Me.lblFarrierCost = New System.Windows.Forms.Label()
        Me.lblTrimAngle = New System.Windows.Forms.Label()
        Me.lblDateShod = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblYearFormat = New System.Windows.Forms.Label()
        Me.lblRequired = New System.Windows.Forms.Label()
        Me.lblAngleFormat = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtFarrierCost
        '
        Me.txtFarrierCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFarrierCost.Location = New System.Drawing.Point(231, 141)
        Me.txtFarrierCost.MaxLength = 50
        Me.txtFarrierCost.Name = "txtFarrierCost"
        Me.txtFarrierCost.Size = New System.Drawing.Size(261, 28)
        Me.txtFarrierCost.TabIndex = 3
        '
        'txtTrimAngle
        '
        Me.txtTrimAngle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrimAngle.Location = New System.Drawing.Point(231, 104)
        Me.txtTrimAngle.Name = "txtTrimAngle"
        Me.txtTrimAngle.Size = New System.Drawing.Size(261, 28)
        Me.txtTrimAngle.TabIndex = 2
        '
        'txtDateShod
        '
        Me.txtDateShod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDateShod.Location = New System.Drawing.Point(231, 67)
        Me.txtDateShod.Name = "txtDateShod"
        Me.txtDateShod.Size = New System.Drawing.Size(261, 28)
        Me.txtDateShod.TabIndex = 1
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(298, 242)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(168, 39)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(63, 242)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(168, 39)
        Me.btnOK.TabIndex = 5
        Me.btnOK.Text = "&OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'txtComments
        '
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(231, 178)
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(261, 28)
        Me.txtComments.TabIndex = 4
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(231, 30)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(261, 28)
        Me.txtName.TabIndex = 0
        '
        'lblComments
        '
        Me.lblComments.AutoSize = True
        Me.lblComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComments.Location = New System.Drawing.Point(36, 181)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(106, 24)
        Me.lblComments.TabIndex = 14
        Me.lblComments.Text = "Comments:"
        '
        'lblFarrierCost
        '
        Me.lblFarrierCost.AutoSize = True
        Me.lblFarrierCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFarrierCost.Location = New System.Drawing.Point(36, 144)
        Me.lblFarrierCost.Name = "lblFarrierCost"
        Me.lblFarrierCost.Size = New System.Drawing.Size(112, 24)
        Me.lblFarrierCost.TabIndex = 8
        Me.lblFarrierCost.Text = "Farrier Cost:"
        '
        'lblTrimAngle
        '
        Me.lblTrimAngle.AutoSize = True
        Me.lblTrimAngle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrimAngle.Location = New System.Drawing.Point(36, 107)
        Me.lblTrimAngle.Name = "lblTrimAngle"
        Me.lblTrimAngle.Size = New System.Drawing.Size(115, 24)
        Me.lblTrimAngle.TabIndex = 10
        Me.lblTrimAngle.Text = "Trim Angle:*"
        '
        'lblDateShod
        '
        Me.lblDateShod.AutoSize = True
        Me.lblDateShod.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateShod.Location = New System.Drawing.Point(36, 70)
        Me.lblDateShod.Name = "lblDateShod"
        Me.lblDateShod.Size = New System.Drawing.Size(110, 24)
        Me.lblDateShod.TabIndex = 12
        Me.lblDateShod.Text = "Date Shod:*"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(36, 33)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(73, 24)
        Me.lblName.TabIndex = 13
        Me.lblName.Text = "Name:*"
        '
        'lblYearFormat
        '
        Me.lblYearFormat.AutoSize = True
        Me.lblYearFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYearFormat.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblYearFormat.Location = New System.Drawing.Point(59, 89)
        Me.lblYearFormat.Name = "lblYearFormat"
        Me.lblYearFormat.Size = New System.Drawing.Size(69, 15)
        Me.lblYearFormat.TabIndex = 11
        Me.lblYearFormat.Text = "yyyy/mm/dd"
        '
        'lblRequired
        '
        Me.lblRequired.AutoSize = True
        Me.lblRequired.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequired.Location = New System.Drawing.Point(227, 206)
        Me.lblRequired.Name = "lblRequired"
        Me.lblRequired.Size = New System.Drawing.Size(117, 18)
        Me.lblRequired.TabIndex = 7
        Me.lblRequired.Text = "*=Required Field"
        '
        'lblAngleFormat
        '
        Me.lblAngleFormat.AutoSize = True
        Me.lblAngleFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAngleFormat.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblAngleFormat.Location = New System.Drawing.Point(73, 125)
        Me.lblAngleFormat.Name = "lblAngleFormat"
        Me.lblAngleFormat.Size = New System.Drawing.Size(34, 15)
        Me.lblAngleFormat.TabIndex = 9
        Me.lblAngleFormat.Text = "xx/xx"
        '
        'FAddShoe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 308)
        Me.Controls.Add(Me.lblAngleFormat)
        Me.Controls.Add(Me.lblRequired)
        Me.Controls.Add(Me.lblYearFormat)
        Me.Controls.Add(Me.txtFarrierCost)
        Me.Controls.Add(Me.txtTrimAngle)
        Me.Controls.Add(Me.txtDateShod)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblComments)
        Me.Controls.Add(Me.lblFarrierCost)
        Me.Controls.Add(Me.lblTrimAngle)
        Me.Controls.Add(Me.lblDateShod)
        Me.Controls.Add(Me.lblName)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAddShoe"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Add Shoe"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtFarrierCost As System.Windows.Forms.TextBox
    Friend WithEvents txtTrimAngle As System.Windows.Forms.TextBox
    Friend WithEvents txtDateShod As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents lblFarrierCost As System.Windows.Forms.Label
    Friend WithEvents lblTrimAngle As System.Windows.Forms.Label
    Friend WithEvents lblDateShod As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblYearFormat As System.Windows.Forms.Label
    Friend WithEvents lblRequired As System.Windows.Forms.Label
    Friend WithEvents lblAngleFormat As System.Windows.Forms.Label
End Class
