﻿' -------------------------------------------------------------------------------------
' Name: Laurie Fox - FEditFeedMiscExpenses
' Abstract: Capstone Horse project - Edit Feed/Misc. Expenses (with add and delete)
' -------------------------------------------------------------------------------------

' -------------------------------------------------------------------------------------
' Options
' -------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FEditFeedMiscExpense


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------
    Private f_intFeedMiscExpenseID As Integer
    Private f_blnResult As Boolean



    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: SetFeedMiscExpenseID
    ' Abstract: What FeedMiscExpense are we going to edit?
    '           Called after instance is created but before shown
    ' --------------------------------------------------------------------------------
    Public Sub SetFeedMiscExpenseID(ByVal intFeedMiscExpenseID As Integer)

        ' Try/Catch with WriteLog
        Try

            ' FeedMiscExpense ID
            f_intFeedMiscExpenseID = intFeedMiscExpenseID

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: FEditFeedMiscExpense_Shown
    ' Abstract: Load the form with values from the database.
    ' --------------------------------------------------------------------------------
    Private Sub FEditFeedMiscExpense_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            Dim udtFeedMiscExpense As udtFeedMiscExpenseType

            ' Make a suitcase instace
            udtFeedMiscExpense = New udtFeedMiscExpenseType

            ' Set the ID
            udtFeedMiscExpense.intFeedMiscExpenseID = f_intFeedMiscExpenseID

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is the data OK (pass in the empty suitcase by ref so it can be filled up)?
            If GetFeedMiscExpenseInformationFromDatabase(udtFeedMiscExpense) = True Then

                With udtFeedMiscExpense

                    ' Name
                    txtName.Text = .strName

                    'Expense Cost
                    txtExpenseCost.Text = .decExpenseCost.ToString("c")
                    txtExpenseCost.Text = .decExpenseCost.ToString("c2")  ' Currency with 2 decimal points
                    txtExpenseCost.Text = FormatCurrency(.decExpenseCost)


                    ' Date Purchased
                    If .dteDatePurchased <> "1800/01/01" Then

                        txtDatePurchased.Text = .dteDatePurchased.ToString("yyyy/MM/dd")

                    End If

                    ' Comments
                    txtComments.Text = .strComments

                End With
            Else

                ' Something went wrong.  Warn he user ...
                MessageBox.Show(Me, "Error: Unable to load information for FeedMiscExpense to edit." & vbNewLine & _
                                "The form will now close.", "Edit FeedMiscExpense Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

                ' ... and close the form
                Me.Hide()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)


        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnOK_Click
    ' Abstract: Add the FeedMiscExpense to the database if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click

        ' Try/Catch with WriteLog
        Try

            ' Is valid data
            If IsValidData() = True Then

                ' Add FeedMiscExpense to database
                If SaveData() = True Then

                    ' Yes, Success
                    f_blnResult = True

                    Me.Hide()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: IsValidData
    ' Abstract: Check to see if the data is valid.
    ' --------------------------------------------------------------------------------
    Private Function IsValidData() As Boolean

        Dim blnIsValidData As Boolean = True    ' Easier to assume true and have one error turn off

        ' Try/Catch with WriteLog
        Try

            Dim strErrorMessage As String = "Please correct the following error(s): " & vbNewLine

            ' Trim textboxes
            TrimAllFormTextBoxes(Me)

            ' Name
            If txtName.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Name can't be blank" & vbNewLine
                blnIsValidData = False

            End If


            ' Expense Cost
            If txtExpenseCost.Text <> "" Then

                ' Is valid format?
                If IsValidSalary(txtExpenseCost.Text) = False Then

                    strErrorMessage &= "-The dollar amount is an invalid format?"
                    blnIsValidData = False

                End If

            End If

            ' Expense Date
            If txtDatePurchased.Text = "" Then

                ' Is data valid?
                strErrorMessage &= "-Expense date can't be blank" & vbNewLine
                blnIsValidData = False

            ElseIf txtDatePurchased.Text <> "" Then

                ' Is valid format
                If IsValidDate(txtDatePurchased.Text) = False Then

                    strErrorMessage &= "-Expense date is an invalid format?"
                    blnIsValidData = False

                End If

            End If


            ' Bad Data?
            If blnIsValidData = False Then

                ' Yes, warn the user
                MessageBox.Show(strErrorMessage, Me.Text & " Error(s) ", _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnIsValidData

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SaveData
    ' Abstract: Make sure the data is good and save to the database.
    ' --------------------------------------------------------------------------------
    Private Function SaveData() As Boolean

        Dim blnResult As Boolean

        ' Try/Catch with WriteLog
        Try

            ' We need a suitcase because we are going traveling to ... the database
            Dim udtFeedMiscExpense As New udtFeedMiscExpenseType

            ' Load it up with data from the form
            udtFeedMiscExpense = GetValuesFromForm()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Do it, add data to database
            blnResult = EditFeedMiscExpenseInDatabase2(udtFeedMiscExpense)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetValuesFromForm
    ' Abstract: Get values from the form.
    ' --------------------------------------------------------------------------------
    Public Function GetValuesFromForm() As udtFeedMiscExpenseType

        Dim udtFeedMiscExpense As New udtFeedMiscExpenseType

        ' Try/Catch with WriteLog
        Try

            Dim strExpenseCost As String

            ' Load up with data from the form
            ' ID
            udtFeedMiscExpense.intFeedMiscExpenseID = f_intFeedMiscExpenseID

            'Name 
            udtFeedMiscExpense.strName = txtName.Text


            ' Expense Cost - Remove dollar signs and commas
            strExpenseCost = txtExpenseCost.Text
            strExpenseCost = strExpenseCost.Replace("$", "")
            strExpenseCost = strExpenseCost.Replace(",", "")
            udtFeedMiscExpense.decExpenseCost = Val(strExpenseCost)

            ' Expense Date
            ' Boundary check - if textbox is empty
            If txtDatePurchased.Text = "" Then

                ' Then insert date
                udtFeedMiscExpense.dteDatePurchased = "1800/01/01"

            Else

                ' Else txtDateOfBirth has a value
                udtFeedMiscExpense.dteDatePurchased = txtDatePurchased.Text

            End If

            ' Comments
            udtFeedMiscExpense.strComments = txtComments.Text


        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return udtFeedMiscExpense

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnCancel_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        ' Try/Catch with WriteLog
        Try

            ' Close the form
            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: GetResult
    ' Abstract: Was the add/edit successful?
    ' --------------------------------------------------------------------------------
    Public Function GetResult() As Boolean

        ' Try/Catch with WriteLog
        Try

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return f_blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetNewFeedMiscExpenseInformation
    ' Abstract: Get the new FeedMiscExpense information
    ' --------------------------------------------------------------------------------
    Public Function GetNewFeedMiscExpenseInformation() As CListItem

        Dim liFeedMiscExpense As CListItem = Nothing

        ' Try/Catch with WriteLog
        Try

            Dim strName As String

            ' Name
            strName = txtName.Text

            'Make an instance of CListItem
            liFeedMiscExpense = New CListItem(f_intFeedMiscExpenseID, strName)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return liFeedMiscExpense

    End Function

End Class