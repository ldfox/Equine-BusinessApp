﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FEditMaintenance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDateDewormedFormat = New System.Windows.Forms.Label()
        Me.lblRequired = New System.Windows.Forms.Label()
        Me.txtComments = New System.Windows.Forms.TextBox()
        Me.txtMaintenanceDate = New System.Windows.Forms.TextBox()
        Me.txtMaintenanceCost = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblComments = New System.Windows.Forms.Label()
        Me.lblMaintenanceDate = New System.Windows.Forms.Label()
        Me.lblMaintenanceCost = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblDateDewormedFormat
        '
        Me.lblDateDewormedFormat.AutoSize = True
        Me.lblDateDewormedFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateDewormedFormat.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblDateDewormedFormat.Location = New System.Drawing.Point(95, 92)
        Me.lblDateDewormedFormat.Name = "lblDateDewormedFormat"
        Me.lblDateDewormedFormat.Size = New System.Drawing.Size(84, 17)
        Me.lblDateDewormedFormat.TabIndex = 9
        Me.lblDateDewormedFormat.Text = "yyyy-mm-dd"
        '
        'lblRequired
        '
        Me.lblRequired.AutoSize = True
        Me.lblRequired.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.lblRequired.Location = New System.Drawing.Point(224, 171)
        Me.lblRequired.Name = "lblRequired"
        Me.lblRequired.Size = New System.Drawing.Size(117, 18)
        Me.lblRequired.TabIndex = 6
        Me.lblRequired.Text = "*=Required Field"
        '
        'txtComments
        '
        Me.txtComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtComments.Location = New System.Drawing.Point(228, 143)
        Me.txtComments.MaxLength = 50
        Me.txtComments.Name = "txtComments"
        Me.txtComments.Size = New System.Drawing.Size(261, 28)
        Me.txtComments.TabIndex = 3
        '
        'txtMaintenanceDate
        '
        Me.txtMaintenanceDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaintenanceDate.Location = New System.Drawing.Point(228, 69)
        Me.txtMaintenanceDate.Name = "txtMaintenanceDate"
        Me.txtMaintenanceDate.Size = New System.Drawing.Size(261, 28)
        Me.txtMaintenanceDate.TabIndex = 1
        '
        'txtMaintenanceCost
        '
        Me.txtMaintenanceCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMaintenanceCost.Location = New System.Drawing.Point(228, 106)
        Me.txtMaintenanceCost.Name = "txtMaintenanceCost"
        Me.txtMaintenanceCost.Size = New System.Drawing.Size(261, 28)
        Me.txtMaintenanceCost.TabIndex = 2
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(295, 203)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(168, 39)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(60, 203)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(168, 39)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "&OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(228, 32)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(261, 28)
        Me.txtName.TabIndex = 0
        '
        'lblComments
        '
        Me.lblComments.AutoSize = True
        Me.lblComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComments.Location = New System.Drawing.Point(33, 146)
        Me.lblComments.Name = "lblComments"
        Me.lblComments.Size = New System.Drawing.Size(106, 24)
        Me.lblComments.TabIndex = 7
        Me.lblComments.Text = "Comments:"
        '
        'lblMaintenanceDate
        '
        Me.lblMaintenanceDate.AutoSize = True
        Me.lblMaintenanceDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMaintenanceDate.Location = New System.Drawing.Point(33, 72)
        Me.lblMaintenanceDate.Name = "lblMaintenanceDate"
        Me.lblMaintenanceDate.Size = New System.Drawing.Size(174, 24)
        Me.lblMaintenanceDate.TabIndex = 10
        Me.lblMaintenanceDate.Text = "Maintenance Date:*"
        '
        'lblMaintenanceCost
        '
        Me.lblMaintenanceCost.AutoSize = True
        Me.lblMaintenanceCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMaintenanceCost.Location = New System.Drawing.Point(33, 109)
        Me.lblMaintenanceCost.Name = "lblMaintenanceCost"
        Me.lblMaintenanceCost.Size = New System.Drawing.Size(166, 24)
        Me.lblMaintenanceCost.TabIndex = 8
        Me.lblMaintenanceCost.Text = "Maintenance Cost:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(33, 35)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(73, 24)
        Me.lblName.TabIndex = 11
        Me.lblName.Text = "Name:*"
        '
        'FEditMaintenance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 268)
        Me.Controls.Add(Me.lblDateDewormedFormat)
        Me.Controls.Add(Me.lblRequired)
        Me.Controls.Add(Me.txtComments)
        Me.Controls.Add(Me.txtMaintenanceDate)
        Me.Controls.Add(Me.txtMaintenanceCost)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblComments)
        Me.Controls.Add(Me.lblMaintenanceDate)
        Me.Controls.Add(Me.lblMaintenanceCost)
        Me.Controls.Add(Me.lblName)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FEditMaintenance"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Edit Maintenance"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDateDewormedFormat As System.Windows.Forms.Label
    Friend WithEvents lblRequired As System.Windows.Forms.Label
    Friend WithEvents txtComments As System.Windows.Forms.TextBox
    Friend WithEvents txtMaintenanceDate As System.Windows.Forms.TextBox
    Friend WithEvents txtMaintenanceCost As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblComments As System.Windows.Forms.Label
    Friend WithEvents lblMaintenanceDate As System.Windows.Forms.Label
    Friend WithEvents lblMaintenanceCost As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
End Class
