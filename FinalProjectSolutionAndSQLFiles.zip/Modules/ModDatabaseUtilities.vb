﻿' ------------------------------------------------------------------------------------
' Module: modDatabaseUtilities
' Abstract: Capstone Horse project - Modularizing Database Functions.
' ------------------------------------------------------------------------------------

' ------------------------------------------------------------------------------------
' Options
' ------------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO

Public Module ModDatabaseUtilities



    ' --------------------------------------------------------------------------------
    '  Module constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Module variables
    ' --------------------------------------------------------------------------------
    ' Access Connection string (notice the use of the relative path)                           
    'Private m_strDatabaseConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    '                                                  "Data Source=" & Application.StartupPath & "..\..\..\Database\TeamsAndPlayers33.mdb;" & _
    '                                                  "User ID=Admin;" & _
    '                                                  "Password=;"


    ' --------------------------------------------------------------------------------
    '  SQL Server Connection string with integrated login v1
    ' --------------------------------------------------------------------------------
    'Private m_strDatabaseConnectionStringSQLServerV1 As String = "Provider=SQLOLEDB;" & _
    '                                                             "Server=(Local);" & _
    '                                                             "Database=dbSQL1;" & _
    '                                                             "Integrated Security=SSPI;"

    'Private m_strDatabaseConnectionStringSQLServerV2 As String = "Provider=SQLOLEDB;" & _
    '                                                             "Server=(Local);" & _
    '                                                             "Database=dbSQL1;" & _
    '                                                             "Trusted_Connection=True;"

    Private m_strDatabaseConnectionStringSQLServerV1 As String = "Provider=SQLOLEDB;Data Source=itd2.cincinnatistate.edu;Initial Catalog=CPDM_FoxL;User ID=CPDM_ldfox;Password=0593263;"

    '"Data Source=itd2.cincinnatistate.edu;Initial Catalog=CPDM_FoxL;User ID=CPDM_ldfox;Password=0593263"

    Private m_conAdministrator As OleDb.OleDbConnection



#Region "Open/Close Database"
    ' --------------------------------------------------------------------------------
    ' Name: OpenDatabaseConnectionMSAccess
    ' Abstract: Open a connection to the database.
    '           In a 2-Tier (Client Server) application we connect once in FMain
    '           and hold the connection open until FMain closes
    '
    '           ********** READ ME **********
    '
    '           For MS Access on Windows Vista/7/8 you must set the target CPU to "x86"
    '           under "Project/Properties/Compiler/Advanced Compiler Options (button at bottom)/Target CPU"
    '' --------------------------------------------------------------------------------
    'Public Function OpenDatabaseConnectionMSAccess() As Boolean

    '    Dim blnResult As Boolean = False

    '    ' Try/Catch with WriteLog
    '    Try

    '        ' Open a connection to the database
    '        m_conAdministrator = New OleDb.OleDbConnection
    '        m_conAdministrator.ConnectionString = m_strDatabaseConnectionString
    '        m_conAdministrator.Open()

    '        ' Success
    '        blnResult = True

    '    Catch excError As Exception

    '        ' Log and display error message
    '        WriteLog(excError)

    '        MessageBox.Show("Unable to connect to the database!" & vbNewLine & _
    '                        "The application will now close." & vbNewLine & _
    '                        vbNewLine & _
    '                        "See modDatabaseUtilities.OpenDatabaseConnection for more details", _
    '                        "Database Connection Error", _
    '                        MessageBoxButtons.OK, _
    '                        MessageBoxIcon.Information)

    '    End Try

    '    Return blnResult

    'End Function



    ' --------------------------------------------------------------------------------
    ' Name: OpenDatabaseConnectionSQLServer
    ' Abstract: Open a connection to the database.
    '           In a 2-Tier (Client Server) application we connect once in FMain
    '           and hold the connection open until FMain closes
    ' --------------------------------------------------------------------------------
    Public Function OpenDatabaseConnectionSQLServer() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            ' Open a connection to the database
            m_conAdministrator = New OleDb.OleDbConnection
            m_conAdministrator.ConnectionString = m_strDatabaseConnectionStringSQLServerV1
            m_conAdministrator.Open()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

            MessageBox.Show("Unable to connect to the database!" & vbNewLine & _
                            "The application will now close." & vbNewLine & _
                            vbNewLine & _
                            "See modDatabaseUtilities.OpenDatabaseConnection for more details", _
                            "Database Connection Error", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Information)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: CloseDatabaseConnection
    ' Abstract: If the database connection is open then close it.
    ' --------------------------------------------------------------------------------
    Public Function CloseDatabaseConnection() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            ' Anything there?
            If m_conAdministrator IsNot Nothing Then

                ' Open?
                If m_conAdministrator.State <> ConnectionState.Closed Then

                    ' Yes, Close it
                    m_conAdministrator.Close()

                End If

                ' Clean up
                m_conAdministrator = Nothing

            End If

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "LoadListBoxFromDatabase"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListBoxFromDatabase
    ' Abstract: Load a listbox control from a table in the Database.
    ' --------------------------------------------------------------------------------
    Public Function LoadListBoxFromDatabase(ByVal strTable As String, _
                                                    ByVal strPrimaryKey As String, _
                                                    ByVal strNameColumn As String, _
                                                    ByRef lstTarget As ListBox, _
                                           Optional ByVal strSortColumn As String = "", _
                                           Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim liNewItem As CListItem
            Dim intID As Integer
            Dim strName As String

            ' Show changes all at once at end (MUCH faster).
            lstTarget.BeginUpdate()

            ' Clear items from the ListBox if any exist
            lstTarget.Items.Clear()

            ' Build the select statement
            strSelect = BuildSelectStatement(strTable, strPrimaryKey, _
                                             strNameColumn, strSortColumn, _
                                             strCustomSQL)

            ' Wrap a command object around the select statement
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

            ' Retrieve all the records from the database
            drSourceTable = cmdSelect.ExecuteReader

            ' Loop through records one at a time
            ' Each call to read moves to the next record
            Do While drSourceTable.Read = True

                ' Make a List Item item to hold the information
                intID = drSourceTable.Item(0)       ' Primary Key
                strName = drSourceTable.Item(1)     ' Name column
                liNewItem = New CListItem(intID, strName)

                ' Add the item to the list
                lstTarget.Items.Add(liNewItem)

            Loop

            ' Select the first item in the list by default
            If lstTarget.Items.Count > 0 Then lstTarget.SelectedIndex = 0

            ' Show any changes
            lstTarget.EndUpdate()

            ' Clean up
            drSourceTable.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "BuildSelectStatement"
    ' -------------------------------------------------------------------------
    ' Name: BuildSelectStatement
    ' Abstract: Build a select statement for the table, ID and Name column.
    ' -------------------------------------------------------------------------
    Private Function BuildSelectStatement(ByVal strTable As String, _
                                          ByVal strPrimaryKey As String, _
                                          ByVal strNameColumn As String, _
                                          ByVal strSortColumn As String, _
                                 Optional ByVal strCustomSQL As String = "") As String

        Dim strSelectStatement As String = ""

        ' Try/Catch with WriteLog
        Try

            ' Custom select statement?
            If strCustomSQL = "" Then

                ' No, so build one

                ' Sort by name column if nothing provided
                If strSortColumn = "" Then strSortColumn = strNameColumn

                ' Put it all together
                strSelectStatement = "SELECT " & _
                                        strPrimaryKey & ", " & strNameColumn & _
                                     " FROM " & _
                                        strTable & _
                                     " ORDER BY " & strSortColumn

            Else

                ' Yes, use it
                strSelectStatement = strCustomSQL

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return strSelectStatement

    End Function
#End Region



#Region "LoadComboBoxFromDatabase"
    ' --------------------------------------------------------------------------------
    ' Name: LoadComboBoxFromDatabase
    ' Abstract: Load a combobox control from a table in the Database.
    ' --------------------------------------------------------------------------------
    Public Function LoadComboBoxFromDatabase(ByVal strTable As String, _
                                                    ByVal strPrimaryKey As String, _
                                                    ByVal strNameColumn As String, _
                                                    ByVal cmbTarget As ComboBox) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader
            Dim liNewItem As CListItem
            Dim intID As Integer
            Dim strName As String

            ' Clear items from the combobox if any exist
            'cmbTarget.Items.Clear()

            ' Show changes all at once at end (MUCH faster).
            cmbTarget.BeginUpdate()

            ' Build the select statement
            strSelect = "SELECT " & strPrimaryKey & ", " & strNameColumn & _
                        " FROM " & strTable & _
                        " ORDER BY " & strNameColumn

            ' Wrap a command object around the select statement
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

            ' Retrieve all the records from the database
            drSourceTable = cmdSelect.ExecuteReader

            ' Loop through records one at a time
            ' Each call to read moves to the next record
            Do While drSourceTable.Read = True

                ' Make a List Item item to hold the information
                intID = drSourceTable.Item(0)       ' Primary Key
                strName = drSourceTable.Item(1)     ' Name column
                liNewItem = New CListItem(intID, strName)

                ' Add the item to the list
                cmbTarget.Items.Add(liNewItem)

            Loop

            ' Select the first item in the list by default
            If cmbTarget.Items.Count > 0 Then cmbTarget.SelectedIndex = 0

            ' Show any changes
            cmbTarget.EndUpdate()

            ' Clean up
            drSourceTable.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "GetNextHighestRecordID"
    ' --------------------------------------------------------------------------------
    ' Name: GetNextHighestRecordID
    ' Abstract: Get the next highest ID from the table in the database
    '           Danger: Potential race condition.
    '           Why do we have this?  So we can see the mechanics of how 
    '           everything works.
    ' --------------------------------------------------------------------------------
    Public Function GetNextHighestRecordID(ByVal strPrimaryKey As String, _
                                           ByVal strTable As String, _
                                           ByRef intNextHighestRecordID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String
            Dim cmdSelect As OleDb.OleDbCommand
            Dim drSourceTable As OleDb.OleDbDataReader

            strSelect = "SELECT MAX( " & strPrimaryKey & " ) + 1 AS intNextHighestRecordID " & _
                        " FROM " & strTable

            ' Execute command
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                intNextHighestRecordID = 1

            Else

                ' No, get the next highest ID
                intNextHighestRecordID = drSourceTable.Item(0)

            End If


            ' Clean Up
            drSourceTable.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "DeleteRecordsFromTable"
    ' --------------------------------------------------------------------------------
    ' Name: DeleteRecordsFromTable
    ' Abstract: Delete all records from table that match the ID.
    ' --------------------------------------------------------------------------------
    Private Function DeleteRecordsFromTable(ByVal intRecordID As Integer, _
                                            ByVal strPrimaryKey As String, _
                                            ByVal strTable As String, _
                                   Optional ByVal strCustomSQL As String = "") As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strDelete As String
            Dim cmdDelete As OleDb.OleDbCommand
            Dim intRowsAffected As Integer = 0

            ' Custom SQL?
            If strCustomSQL = "" Then

                ' No, Build the SQL String
                strDelete = "DELETE FROM " & strTable & _
                            " WHERE " & strPrimaryKey & " = " & intRecordID

            Else

                ' Yes, use it
                strDelete = strCustomSQL

            End If

            ' Delete the record(s)
            cmdDelete = New OleDb.OleDbCommand(strDelete, m_conAdministrator)
            intRowsAffected = cmdDelete.ExecuteNonQuery()

            ' Did it work?
            If intRowsAffected > 0 Then

                ' Yes, success
                blnResult = True

            End If

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "HorseBuyers"
    ' --------------------------------------------------------------------------------
    ' Name: AddHorseBuyersToDatabase2
    ' Abstract: Add the Horse Buyer to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddHorseBuyerToDatabase2(ByRef udtHorseBuyer As udtHorseBuyerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseBuyer", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorseBuyer.strFullName)
                .AddWithValue("2", udtHorseBuyer.strAddress)
                .AddWithValue("3", udtHorseBuyer.strCity)
                .AddWithValue("4", udtHorseBuyer.intStateID)
                .AddWithValue("5", udtHorseBuyer.strZipCode)
                .AddWithValue("6", udtHorseBuyer.decPurchasePrice)
                .AddWithValue("7", udtHorseBuyer.dteDatePurchased)
                .AddWithValue("8", udtHorseBuyer.intHorseBuyerStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtHorseBuyer.intHorseBuyerID = drReturnValues.Item("intHorseBuyerID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetHorseBuyerInformationFromDatabase
    ' Abstract: Get data for the specified Horse Buyer from the database
    ' --------------------------------------------------------------------------------
    Public Function GetHorseBuyerInformationFromDatabase(ByRef udtHorseBuyer As udtHorseBuyerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTHorseBuyers As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM THorseBuyers" & _
                        " WHERE intHorseBuyerID = " & udtHorseBuyer.intHorseBuyerID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTHorseBuyers = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTHorseBuyers.Read()

            With drTHorseBuyers

                udtHorseBuyer.strFullName = .Item("strFullName")
                udtHorseBuyer.strAddress = .Item("strAddress")
                udtHorseBuyer.strCity = .Item("strCity")
                udtHorseBuyer.intStateID = .Item("intStateID")
                udtHorseBuyer.strZipCode = .Item("strZipCode")
                udtHorseBuyer.decPurchasePrice = .Item("decPurchasePrice")
                udtHorseBuyer.dteDatePurchased = .Item("dteDatePurchased")
                udtHorseBuyer.intHorseBuyerStatusID = intHORSEBUYER_STATUS_ACTIVE

            End With

            'Clean up
            drTHorseBuyers.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditHorseBuyerInDatabase2
    ' Abstract: Edit the Horse Buyer in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditHorseBuyerInDatabase2(ByVal udtHorseBuyer As udtHorseBuyerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditHorseBuyer", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorseBuyer.intHorseBuyerID)
                .AddWithValue("2", udtHorseBuyer.strFullName)
                .AddWithValue("3", udtHorseBuyer.strAddress)
                .AddWithValue("4", udtHorseBuyer.strCity)
                .AddWithValue("5", udtHorseBuyer.intStateID)
                .AddWithValue("6", udtHorseBuyer.strZipCode)
                .AddWithValue("7", udtHorseBuyer.decPurchasePrice)
                .AddWithValue("8", udtHorseBuyer.dteDatePurchased)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHorseBuyerFromDatabase
    ' Abstract: Delete the Horse Buyer from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteHorseBuyerFromDatabase(ByVal intHorseBuyerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseBuyerStatusInDatabase2(intHorseBuyerID, intHORSEBUYER_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHorseBuyerFromDatabase
    ' Abstract: Mark the Horse Buyer as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteHorseBuyerFromDatabase(ByVal intHorseBuyerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseBuyerStatusInDatabase2(intHorseBuyerID, intHORSEBUYER_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetHorseBuyerStatusInDatabase2
    ' Abstract: Mark the specified Horse as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetHorseBuyerStatusInDatabase2(ByVal intHorseBuyerID As Integer, _
                                            ByVal intHorseBuyerStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetHorseBuyerStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intHorseBuyerID)
                .AddWithValue("2", intHorseBuyerStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "HorseSellers"
    ' --------------------------------------------------------------------------------
    ' Name: AddHorseSellersToDatabase2
    ' Abstract: Add the Horse Seller to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddHorseSellerToDatabase2(ByRef udtHorseSeller As udtHorseSellerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseSeller", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorseSeller.strFullName)
                .AddWithValue("2", udtHorseSeller.strAddress)
                .AddWithValue("3", udtHorseSeller.strCity)
                .AddWithValue("4", udtHorseSeller.intStateID)
                .AddWithValue("5", udtHorseSeller.strZipCode)
                .AddWithValue("6", udtHorseSeller.decSellingPrice)
                .AddWithValue("7", udtHorseSeller.dteDateSold)
                .AddWithValue("8", udtHorseSeller.intHorseSellerStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtHorseSeller.intHorseSellerID = drReturnValues.Item("intHorseSellerID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetHorseSellerInformationFromDatabase
    ' Abstract: Get data for the specified Horse Seller from the database
    ' --------------------------------------------------------------------------------
    Public Function GetHorseSellerInformationFromDatabase(ByRef udtHorseSeller As udtHorseSellerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTHorseSellers As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM THorseSellers" & _
                        " WHERE intHorseSellerID = " & udtHorseSeller.intHorseSellerID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTHorseSellers = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTHorseSellers.Read()

            With drTHorseSellers

                udtHorseSeller.strFullName = .Item("strFullName")
                udtHorseSeller.strAddress = .Item("strAddress")
                udtHorseSeller.strCity = .Item("strCity")
                udtHorseSeller.intStateID = .Item("intStateID")
                udtHorseSeller.strZipCode = .Item("strZipCode")
                udtHorseSeller.decSellingPrice = .Item("decSellingPrice")
                udtHorseSeller.dteDateSold = .Item("dteDateSold")
                udtHorseSeller.intHorseSellerStatusID = intHORSESELLER_STATUS_ACTIVE

            End With

            'Clean up
            drTHorseSellers.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditHorseSellerInDatabase2
    ' Abstract: Edit the Horse Seller in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditHorseSellerInDatabase2(ByVal udtHorseSeller As udtHorseSellerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditHorseSeller", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorseSeller.intHorseSellerID)
                .AddWithValue("2", udtHorseSeller.strFullName)
                .AddWithValue("3", udtHorseSeller.strAddress)
                .AddWithValue("4", udtHorseSeller.strCity)
                .AddWithValue("5", udtHorseSeller.intStateID)
                .AddWithValue("6", udtHorseSeller.strZipCode)
                .AddWithValue("7", udtHorseSeller.decSellingPrice)
                .AddWithValue("8", udtHorseSeller.dteDateSold)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHorseSellerFromDatabase
    ' Abstract: Delete the Horse Seller from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteHorseSellerFromDatabase(ByVal intHorseSellerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseSellerStatusInDatabase2(intHorseSellerID, intHORSESELLER_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHorseSellerFromDatabase
    ' Abstract: Mark the Horse Seller as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteHorseSellerFromDatabase(ByVal intHorseSellerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseSellerStatusInDatabase2(intHorseSellerID, intHORSESELLER_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetHorseSellerStatusInDatabase2
    ' Abstract: Mark the specified Horse as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetHorseSellerStatusInDatabase2(ByVal intHorseSellerID As Integer, _
                                            ByVal intHorseSellerStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetHorseSellerStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intHorseSellerID)
                .AddWithValue("2", intHorseSellerStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horses"
    ' --------------------------------------------------------------------------------
    ' Name: AddHorseToDatabase2
    ' Abstract: Add the Horse to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddHorseToDatabase2(ByRef udtHorse As udtHorseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorse.strName)
                .AddWithValue("2", udtHorse.intBreedID)
                .AddWithValue("3", udtHorse.strRegistration)
                .AddWithValue("4", udtHorse.intColorID)
                .AddWithValue("5", udtHorse.intSexID)
                .AddWithValue("6", udtHorse.strHeight)
                .AddWithValue("7", udtHorse.intHorseBuyerID)
                .AddWithValue("8", udtHorse.intHorseSellerID)
                .AddWithValue("9", udtHorse.strComments)
                .AddWithValue("10", udtHorse.intHorseStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtHorse.intHorseID = drReturnValues.Item("intHorseID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetHorseInformationFromDatabase
    ' Abstract: Get data for the specified Horse from the database
    ' --------------------------------------------------------------------------------
    Public Function GetHorseInformationFromDatabase(ByRef udtHorse As udtHorseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTHorses As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM THorses" & _
                        " WHERE intHorseID = " & udtHorse.intHorseID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTHorses = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTHorses.Read()

            With drTHorses

                udtHorse.strName = .Item("strName")
                udtHorse.intBreedID = .Item("intBreedID")
                udtHorse.strRegistration = .Item("strRegistration")
                udtHorse.intColorID = .Item("intColorID")
                udtHorse.intSexID = .Item("intSexID")
                udtHorse.strHeight = .Item("strHeight")
                udtHorse.intHorseBuyerID = .Item("intHorseBuyerID")
                udtHorse.intHorseSellerID = .Item("intHorseSellerID")
                udtHorse.strComments = .Item("strComments")
                udtHorse.intHorseStatusID = intHORSE_STATUS_ACTIVE

            End With

            'Clean up
            drTHorses.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditHorseInDatabase2
    ' Abstract: Edit the Horse in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditHorseInDatabase2(ByVal udtHorse As udtHorseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHorse.intHorseID)
                .AddWithValue("2", udtHorse.strName)
                .AddWithValue("3", udtHorse.intBreedID)
                .AddWithValue("4", udtHorse.strRegistration)
                .AddWithValue("5", udtHorse.intColorID)
                .AddWithValue("6", udtHorse.intSexID)
                .AddWithValue("7", udtHorse.strHeight)
                .AddWithValue("8", udtHorse.intHorseBuyerID)
                .AddWithValue("9", udtHorse.intHorseSellerID)
                .AddWithValue("10", udtHorse.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHorseFromDatabase
    ' Abstract: Delete the Horse from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteHorseFromDatabase(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseStatusInDatabase2(intHorseID, intHORSE_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHorseFromDatabase
    ' Abstract: Mark the Horse as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteHorseFromDatabase(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHorseStatusInDatabase2(intHorseID, intHORSE_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetHorseStatusInDatabase2
    ' Abstract: Mark the specified Horse as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetHorseStatusInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intHorseStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetHorseStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intHorseID)
                .AddWithValue("2", intHorseStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Shoes"
    ' --------------------------------------------------------------------------------
    ' Name: AddShoeToDatabase2
    ' Abstract: Add the Shoe to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddShoeToDatabase2(ByRef udtShoe As udtShoeType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddShoes", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtShoe.strName)
                .AddWithValue("2", udtShoe.dteShod)
                .AddWithValue("3", udtShoe.strTrimAngle)
                .AddWithValue("4", udtShoe.decFarrierCost)
                .AddWithValue("5", udtShoe.strComments)
                .AddWithValue("6", udtShoe.intShoeStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtShoe.intShoeID = drReturnValues.Item("intShoeID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetShoeInformationFromDatabase
    ' Abstract: Get data for the specified Shoe from the database
    ' --------------------------------------------------------------------------------
    Public Function GetShoeInformationFromDatabase(ByRef udtShoe As udtShoeType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTShoes As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TShoes" & _
                        " WHERE intShoeID = " & udtShoe.intShoeID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTShoes = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTShoes.Read()

            With drTShoes

                udtShoe.strName = .Item("strName")
                udtShoe.dteShod = .Item("dteShod")
                udtShoe.strTrimAngle = .Item("strTrimAngle")
                udtShoe.decFarrierCost = .Item("decFarrierCost")
                udtShoe.strComments = .Item("strComments")
                udtShoe.intShoeStatusID = intSHOE_STATUS_ACTIVE

            End With

            'Clean up
            drTShoes.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditShoeInDatabase2
    ' Abstract: Edit the Shoe in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditShoeInDatabase2(ByVal udtShoe As udtShoeType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditShoes", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtShoe.intShoeID)
                .AddWithValue("2", udtShoe.strName)
                .AddWithValue("3", udtShoe.dteShod)
                .AddWithValue("4", udtShoe.strTrimAngle)
                .AddWithValue("5", udtShoe.decFarrierCost)
                .AddWithValue("6", udtShoe.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteShoeFromDatabase
    ' Abstract: Delete the Shoe from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteShoeFromDatabase(ByVal intShoeID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetShoeStatusInDatabase2(intShoeID, intSHOE_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteShoeFromDatabase
    ' Abstract: Mark the Shoe as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteShoeFromDatabase(ByVal intShoeID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetShoeStatusInDatabase2(intShoeID, intSHOE_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetShoeStatusInDatabase2
    ' Abstract: Mark the specified Shoe as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetShoeStatusInDatabase2(ByVal intShoeID As Integer, _
                                            ByVal intShoeStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetShoeStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intShoeID)
                .AddWithValue("2", intShoeStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horse Shoes"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithShoesFromDatabase
    ' Abstract: Load all the Shoes on/not on the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithShoesFromDatabase2(ByVal intHorseID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnShoesOnHorse As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected Shoes?
            If blnShoesOnHorse = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the Shoes on the Horse or all the Shoes NOT on the Horse
            ' Shoes must be active
            strCustomSQL = "SELECT " & _
                            "   intShoeID, strName " & _
                            " FROM " & _
                            "   VActiveShoes " & _
                            " WHERE intShoeID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intShoeID " & _
                            "     FROM THorseShoes " & _
                            "     WHERE intHorseID = " & intHorseID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddShoeToHorseInDatabase2
    ' Abstract: Add the Shoe to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddShoeToHorseInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intShoeID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseShoe", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
                .AddWithValue("@intShoeID", intShoeID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableShoesToHorseInDatabase2
    ' Abstract: Add all the available Shoes to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableShoesToHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableShoesToHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveShoeFromHorseInDatabase2
    ' Abstract: Remove the Shoe from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveShoeFromHorseInDatabase2(ByVal intHorseID As Integer, _
                                                    ByVal intShoeID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveHorseShoe", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
                .Add(New OleDb.OleDbParameter("@intShoeID", intShoeID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedShoesFromHorseInDatabase2
    ' Abstract: Remove the Shoe from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedShoesFromHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllHorseShoes", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Vaccinations"
    ' --------------------------------------------------------------------------------
    ' Name: AddVaccinationToDatabase2
    ' Abstract: Add the Vaccination to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddVaccinationToDatabase2(ByRef udtVaccination As udtVaccinationType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddVaccinations", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtVaccination.strName)
                .AddWithValue("2", udtVaccination.decVaccinationCost)
                .AddWithValue("3", udtVaccination.dteVaccinationDate)
                .AddWithValue("4", udtVaccination.strComments)
                .AddWithValue("5", udtVaccination.intVaccinationStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtVaccination.intVaccinationID = drReturnValues.Item("intVaccinationID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetVaccinationInformationFromDatabase
    ' Abstract: Get data for the specified Vaccination from the database
    ' --------------------------------------------------------------------------------
    Public Function GetVaccinationInformationFromDatabase(ByRef udtVaccination As udtVaccinationType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTVaccinations As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TVaccinations" & _
                        " WHERE intVaccinationID = " & udtVaccination.intVaccinationID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTVaccinations = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTVaccinations.Read()

            With drTVaccinations

                udtVaccination.strName = .Item("strName")
                udtVaccination.decVaccinationCost = .Item("decVaccinationCost")
                udtVaccination.dteVaccinationDate = .Item("dteVaccinationDate")
                udtVaccination.strComments = .Item("strComments")
                udtVaccination.intVaccinationStatusID = intVACCINATION_STATUS_ACTIVE

            End With

            'Clean up
            drTVaccinations.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditVaccinationInDatabase2
    ' Abstract: Edit the Vaccination in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditVaccinationInDatabase2(ByVal udtVaccination As udtVaccinationType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditVaccinations", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtVaccination.intVaccinationID)
                .AddWithValue("2", udtVaccination.strName)
                .AddWithValue("3", udtVaccination.decVaccinationCost)
                .AddWithValue("4", udtVaccination.dteVaccinationDate)
                .AddWithValue("5", udtVaccination.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteVaccinationFromDatabase
    ' Abstract: Delete the Vaccination from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteVaccinationFromDatabase(ByVal intVaccinationID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetVaccinationStatusInDatabase2(intVaccinationID, intVACCINATION_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteVaccinationFromDatabase
    ' Abstract: Mark the Vaccination as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteVaccinationFromDatabase(ByVal intVaccinationID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetVaccinationStatusInDatabase2(intVaccinationID, intVACCINATION_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetVaccinationStatusInDatabase2
    ' Abstract: Mark the specified Vaccination as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetVaccinationStatusInDatabase2(ByVal intVaccinationID As Integer, _
                                            ByVal intVaccinationStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetVaccinationStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intVaccinationID)
                .AddWithValue("2", intVaccinationStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horse Vaccinations"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithVaccinationsFromDatabase
    ' Abstract: Load all the Vaccinations on/not on the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithVaccinationsFromDatabase2(ByVal intHorseID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnVaccinationsOnHorse As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected Vaccinations?
            If blnVaccinationsOnHorse = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the Vaccinations on the Horse or all the Vaccinations NOT on the Horse
            ' Vaccinations must be active
            strCustomSQL = "SELECT " & _
                            "   intVaccinationID, strName " & _
                            " FROM " & _
                            "   VActiveVaccinations " & _
                            " WHERE intVaccinationID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intVaccinationID " & _
                            "     FROM THorseVaccinations " & _
                            "     WHERE intHorseID = " & intHorseID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddVaccinationToHorseInDatabase2
    ' Abstract: Add the Vaccination to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddVaccinationToHorseInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intVaccinationID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseVaccination", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
                .AddWithValue("@intVaccinationID", intVaccinationID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableVaccinationsToHorseInDatabase2
    ' Abstract: Add all the available Vaccinations to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableVaccinationsToHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableVaccinationsToHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveVaccinationFromHorseInDatabase2
    ' Abstract: Remove the Vaccination from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveVaccinationFromHorseInDatabase2(ByVal intHorseID As Integer, _
                                                    ByVal intVaccinationID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveHorseVaccination", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
                .Add(New OleDb.OleDbParameter("@intVaccinationID", intVaccinationID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedVaccinationsFromHorseInDatabase2
    ' Abstract: Remove the Vaccination from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedVaccinationsFromHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllHorseVaccinations", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "WestNileTests"
    ' --------------------------------------------------------------------------------
    ' Name: AddWestNileTestToDatabase2
    ' Abstract: Add the WestNileTest to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddWestNileTestToDatabase2(ByRef udtWestNileTest As udtWestNileTestType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddWestNileTests", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtWestNileTest.strName)
                .AddWithValue("2", udtWestNileTest.dteWestNileTestDate)
                .AddWithValue("3", udtWestNileTest.decWestNileTestCost)
                .AddWithValue("4", udtWestNileTest.strComments)
                .AddWithValue("5", udtWestNileTest.intWestNileTestStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtWestNileTest.intWestNileTestID = drReturnValues.Item("intWestNileTestID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetWestNileTestInformationFromDatabase
    ' Abstract: Get data for the specified WestNileTest from the database
    ' --------------------------------------------------------------------------------
    Public Function GetWestNileTestInformationFromDatabase(ByRef udtWestNileTest As udtWestNileTestType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTWestNileTests As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TWestNileTests" & _
                        " WHERE intWestNileTestID = " & udtWestNileTest.intWestNileTestID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTWestNileTests = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTWestNileTests.Read()

            With drTWestNileTests

                udtWestNileTest.strName = .Item("strName")
                udtWestNileTest.dteWestNileTestDate = .Item("dteWestNileTestDate")
                udtWestNileTest.decWestNileTestCost = .Item("decWestNileTestCost")
                udtWestNileTest.strComments = .Item("strComments")
                udtWestNileTest.intWestNileTestStatusID = intWESTNILETEST_STATUS_ACTIVE

            End With

            'Clean up
            drTWestNileTests.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditWestNileTestInDatabase2
    ' Abstract: Edit the WestNileTest in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditWestNileTestInDatabase2(ByVal udtWestNileTest As udtWestNileTestType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditWestNileTests", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtWestNileTest.intWestNileTestID)
                .AddWithValue("2", udtWestNileTest.strName)
                .AddWithValue("3", udtWestNileTest.dteWestNileTestDate)
                .AddWithValue("4", udtWestNileTest.decWestNileTestCost)
                .AddWithValue("5", udtWestNileTest.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteWestNileTestFromDatabase
    ' Abstract: Delete the WestNileTest from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteWestNileTestFromDatabase(ByVal intWestNileTestID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetWestNileTestStatusInDatabase2(intWestNileTestID, intWESTNILETEST_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteWestNileTestFromDatabase
    ' Abstract: Mark the WestNileTest as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteWestNileTestFromDatabase(ByVal intWestNileTestID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetWestNileTestStatusInDatabase2(intWestNileTestID, intWESTNILETEST_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetWestNileTestStatusInDatabase2
    ' Abstract: Mark the specified WestNileTest as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetWestNileTestStatusInDatabase2(ByVal intWestNileTestID As Integer, _
                                            ByVal intWestNileTestStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetWestNileTestStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intWestNileTestID)
                .AddWithValue("2", intWestNileTestStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horse WestNileTests"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithWestNileTestsFromDatabase
    ' Abstract: Load all the WestNileTests on/not on the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithWestNileTestsFromDatabase2(ByVal intHorseID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnWestNileTestsOnHorse As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected WestNileTests?
            If blnWestNileTestsOnHorse = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the WestNileTests on the Horse or all the WestNileTests NOT on the Horse
            ' WestNileTests must be active
            strCustomSQL = "SELECT " & _
                            "   intWestNileTestID, strName " & _
                            " FROM " & _
                            "   VActiveWestNileTests " & _
                            " WHERE intWestNileTestID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intWestNileTestID " & _
                            "     FROM THorseWestNileTests " & _
                            "     WHERE intHorseID = " & intHorseID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddWestNileTestToHorseInDatabase2
    ' Abstract: Add the WestNileTest to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddWestNileTestToHorseInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intWestNileTestID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseWestNileTest", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
                .AddWithValue("@intWestNileTestID", intWestNileTestID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableWestNileTestsToHorseInDatabase2
    ' Abstract: Add all the available WestNileTests to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableWestNileTestsToHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableWestNileTestsToHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveWestNileTestFromHorseInDatabase2
    ' Abstract: Remove the WestNileTest from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveWestNileTestFromHorseInDatabase2(ByVal intHorseID As Integer, _
                                                    ByVal intWestNileTestID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveHorseWestNileTest", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
                .Add(New OleDb.OleDbParameter("@intWestNileTestID", intWestNileTestID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedWestNileTestsFromHorseInDatabase2
    ' Abstract: Remove the WestNileTest from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedWestNileTestsFromHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllHorseWestNileTests", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Dewormers"
    ' --------------------------------------------------------------------------------
    ' Name: AddDewormerToDatabase2
    ' Abstract: Add the Dewormer to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddDewormerToDatabase2(ByRef udtDewormer As udtDewormerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddDewormers", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtDewormer.strName)
                .AddWithValue("2", udtDewormer.dteDewormerDate)
                .AddWithValue("3", udtDewormer.decDewormerCost)
                .AddWithValue("4", udtDewormer.intDewormerStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtDewormer.intDewormerID = drReturnValues.Item("intDewormerID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetDewormerInformationFromDatabase
    ' Abstract: Get data for the specified Dewormer from the database
    ' --------------------------------------------------------------------------------
    Public Function GetDewormerInformationFromDatabase(ByRef udtDewormer As udtDewormerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTDewormers As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TDewormers" & _
                        " WHERE intDewormerID = " & udtDewormer.intDewormerID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTDewormers = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTDewormers.Read()

            With drTDewormers

                udtDewormer.strName = .Item("strName")
                udtDewormer.dteDewormerDate = .Item("dteDewormerDate")
                udtDewormer.decDewormerCost = .Item("decDewormerCost")
                udtDewormer.intDewormerStatusID = intDEWORMER_STATUS_ACTIVE

            End With

            'Clean up
            drTDewormers.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditDewormerInDatabase2
    ' Abstract: Edit the Dewormer in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditDewormerInDatabase2(ByVal udtDewormer As udtDewormerType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditDewormers", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtDewormer.intDewormerID)
                .AddWithValue("2", udtDewormer.strName)
                .AddWithValue("3", udtDewormer.dteDewormerDate)
                .AddWithValue("4", udtDewormer.decDewormerCost)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteDewormerFromDatabase
    ' Abstract: Delete the Dewormer from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteDewormerFromDatabase(ByVal intDewormerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetDewormerStatusInDatabase2(intDewormerID, intDEWORMER_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteDewormerFromDatabase
    ' Abstract: Mark the Dewormer as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteDewormerFromDatabase(ByVal intDewormerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetDewormerStatusInDatabase2(intDewormerID, intDEWORMER_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetDewormerStatusInDatabase2
    ' Abstract: Mark the specified Dewormer as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetDewormerStatusInDatabase2(ByVal intDewormerID As Integer, _
                                            ByVal intDewormerStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetDewormerStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intDewormerID)
                .AddWithValue("2", intDewormerStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horse Dewormers"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithDewormersFromDatabase
    ' Abstract: Load all the Dewormers on/not on the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithDewormersFromDatabase2(ByVal intHorseID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnDewormersOnHorse As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected Dewormers?
            If blnDewormersOnHorse = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the Dewormers on the Horse or all the Dewormers NOT on the Horse
            ' Dewormers must be active
            strCustomSQL = "SELECT " & _
                            "   intDewormerID, strName " & _
                            " FROM " & _
                            "   VActiveDewormers " & _
                            " WHERE intDewormerID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intDewormerID " & _
                            "     FROM THorseDewormers " & _
                            "     WHERE intHorseID = " & intHorseID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddDewormerToHorseInDatabase2
    ' Abstract: Add the Dewormer to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddDewormerToHorseInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intDewormerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseDewormer", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
                .AddWithValue("@intDewormerID", intDewormerID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableDewormersToHorseInDatabase2
    ' Abstract: Add all the available Dewormers to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableDewormersToHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableDewormersToHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveDewormerFromHorseInDatabase2
    ' Abstract: Remove the Dewormer from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveDewormerFromHorseInDatabase2(ByVal intHorseID As Integer, _
                                                    ByVal intDewormerID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveHorseDewormer", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
                .Add(New OleDb.OleDbParameter("@intDewormerID", intDewormerID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedDewormersFromHorseInDatabase2
    ' Abstract: Remove the Dewormer from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedDewormersFromHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllHorseDewormers", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "HealthCertificates"
    ' --------------------------------------------------------------------------------
    ' Name: AddHealthCertificateToDatabase2
    ' Abstract: Add the HealthCertificate to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddHealthCertificateToDatabase2(ByRef udtHealthCertificate As udtHealthCertificateType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHealthCertificates", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHealthCertificate.strName)
                .AddWithValue("2", udtHealthCertificate.dteHealthCertificateDate)
                .AddWithValue("3", udtHealthCertificate.decHealthCertificateCost)
                .AddWithValue("4", udtHealthCertificate.strComments)
                .AddWithValue("5", udtHealthCertificate.intHealthCertificateStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtHealthCertificate.intHealthCertificateID = drReturnValues.Item("intHealthCertificateID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetHealthCertificateInformationFromDatabase
    ' Abstract: Get data for the specified HealthCertificate from the database
    ' --------------------------------------------------------------------------------
    Public Function GetHealthCertificateInformationFromDatabase(ByRef udtHealthCertificate As udtHealthCertificateType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTHealthCertificates As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM THealthCertificates" & _
                        " WHERE intHealthCertificateID = " & udtHealthCertificate.intHealthCertificateID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTHealthCertificates = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTHealthCertificates.Read()

            With drTHealthCertificates

                udtHealthCertificate.strName = .Item("strName")
                udtHealthCertificate.dteHealthCertificateDate = .Item("dteHealthCertificateDate")
                udtHealthCertificate.decHealthCertificateCost = .Item("decHealthCertificateCost")
                udtHealthCertificate.strComments = .Item("strComments")
                udtHealthCertificate.intHealthCertificateStatusID = intHEALTHCERTIFICATE_STATUS_ACTIVE

            End With

            'Clean up
            drTHealthCertificates.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditHealthCertificateInDatabase2
    ' Abstract: Edit the HealthCertificate in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditHealthCertificateInDatabase2(ByVal udtHealthCertificate As udtHealthCertificateType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditHealthCertificates", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtHealthCertificate.intHealthCertificateID)
                .AddWithValue("2", udtHealthCertificate.strName)
                .AddWithValue("3", udtHealthCertificate.dteHealthCertificateDate)
                .AddWithValue("4", udtHealthCertificate.decHealthCertificateCost)
                .AddWithValue("5", udtHealthCertificate.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteHealthCertificateFromDatabase
    ' Abstract: Delete the HealthCertificate from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteHealthCertificateFromDatabase(ByVal intHealthCertificateID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHealthCertificateStatusInDatabase2(intHealthCertificateID, intHEALTHCERTIFICATE_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteHealthCertificateFromDatabase
    ' Abstract: Mark the HealthCertificate as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteHealthCertificateFromDatabase(ByVal intHealthCertificateID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetHealthCertificateStatusInDatabase2(intHealthCertificateID, intHEALTHCERTIFICATE_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetHealthCertificateStatusInDatabase2
    ' Abstract: Mark the specified HealthCertificate as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetHealthCertificateStatusInDatabase2(ByVal intHealthCertificateID As Integer, _
                                            ByVal intHealthCertificateStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetHealthCertificateStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intHealthCertificateID)
                .AddWithValue("2", intHealthCertificateStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Horse HealthCertificates"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithHealthCertificatesFromDatabase
    ' Abstract: Load all the HealthCertificates on/not on the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithHealthCertificatesFromDatabase2(ByVal intHorseID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnHealthCertificatesOnHorse As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected HealthCertificates?
            If blnHealthCertificatesOnHorse = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the HealthCertificates on the Horse or all the HealthCertificates NOT on the Horse
            ' HealthCertificates must be active
            strCustomSQL = "SELECT " & _
                            "   intHealthCertificateID, strName " & _
                            " FROM " & _
                            "   VActiveHealthCertificates " & _
                            " WHERE intHealthCertificateID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intHealthCertificateID " & _
                            "     FROM THorseHealthCertificates " & _
                            "     WHERE intHorseID = " & intHorseID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddHealthCertificateToHorseInDatabase2
    ' Abstract: Add the HealthCertificate to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddHealthCertificateToHorseInDatabase2(ByVal intHorseID As Integer, _
                                            ByVal intHealthCertificateID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddHorseHealthCertificate", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
                .AddWithValue("@intHealthCertificateID", intHealthCertificateID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableHealthCertificatesToHorseInDatabase2
    ' Abstract: Add all the available HealthCertificates to the specified Horse
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableHealthCertificatesToHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableHealthCertificatesToHorse", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intHorseID", intHorseID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveHealthCertificateFromHorseInDatabase2
    ' Abstract: Remove the HealthCertificate from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveHealthCertificateFromHorseInDatabase2(ByVal intHorseID As Integer, _
                                                    ByVal intHealthCertificateID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveHorseHealthCertificate", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
                .Add(New OleDb.OleDbParameter("@intHealthCertificateID", intHealthCertificateID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedHealthCertificatesFromHorseInDatabase2
    ' Abstract: Remove the HealthCertificate from the specified Horse.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedHealthCertificatesFromHorseInDatabase2(ByVal intHorseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllHorseHealthCertificates", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intHorseID", intHorseID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "FeedMiscExpenses"
    ' --------------------------------------------------------------------------------
    ' Name: AddFeedMiscExpenseToDatabase2
    ' Abstract: Add the FeedMiscExpense to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddFeedMiscExpenseToDatabase2(ByRef udtFeedMiscExpense As udtFeedMiscExpenseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddFeedMiscExpenses", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtFeedMiscExpense.strName)
                .AddWithValue("2", udtFeedMiscExpense.decExpenseCost)
                .AddWithValue("3", udtFeedMiscExpense.dteDatePurchased)
                .AddWithValue("4", udtFeedMiscExpense.strComments)
                .AddWithValue("5", udtFeedMiscExpense.intFeedMiscExpenseStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtFeedMiscExpense.intFeedMiscExpenseID = drReturnValues.Item("intFeedMiscExpenseID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetFeedMiscExpenseInformationFromDatabase
    ' Abstract: Get data for the specified FeedMiscExpense from the database
    ' --------------------------------------------------------------------------------
    Public Function GetFeedMiscExpenseInformationFromDatabase(ByRef udtFeedMiscExpense As udtFeedMiscExpenseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTFeedMiscExpenses As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TFeedMiscExpenses" & _
                        " WHERE intFeedMiscExpenseID = " & udtFeedMiscExpense.intFeedMiscExpenseID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTFeedMiscExpenses = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTFeedMiscExpenses.Read()

            With drTFeedMiscExpenses

                udtFeedMiscExpense.strName = .Item("strName")
                udtFeedMiscExpense.decExpenseCost = .Item("decExpenseCost")
                udtFeedMiscExpense.dteDatePurchased = .Item("dteDatePurchased")
                udtFeedMiscExpense.strComments = .Item("strComments")
                udtFeedMiscExpense.intFeedMiscExpenseStatusID = intFEEDMISCEXPENSE_STATUS_ACTIVE

            End With

            'Clean up
            drTFeedMiscExpenses.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditFeedMiscExpenseInDatabase2
    ' Abstract: Edit the FeedMiscExpense in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditFeedMiscExpenseInDatabase2(ByVal udtFeedMiscExpense As udtFeedMiscExpenseType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditFeedMiscExpenses", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtFeedMiscExpense.intFeedMiscExpenseID)
                .AddWithValue("2", udtFeedMiscExpense.strName)
                .AddWithValue("3", udtFeedMiscExpense.decExpenseCost)
                .AddWithValue("4", udtFeedMiscExpense.dteDatePurchased)
                .AddWithValue("5", udtFeedMiscExpense.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteFeedMiscExpenseFromDatabase
    ' Abstract: Delete the FeedMiscExpense from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteFeedMiscExpenseFromDatabase(ByVal intFeedMiscExpenseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetFeedMiscExpenseStatusInDatabase2(intFeedMiscExpenseID, intFEEDMISCEXPENSE_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteFeedMiscExpenseFromDatabase
    ' Abstract: Mark the FeedMiscExpense as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteFeedMiscExpenseFromDatabase(ByVal intFeedMiscExpenseID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetFeedMiscExpenseStatusInDatabase2(intFeedMiscExpenseID, intFEEDMISCEXPENSE_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetFeedMiscExpenseStatusInDatabase2
    ' Abstract: Mark the specified FeedMiscExpense as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetFeedMiscExpenseStatusInDatabase2(ByVal intFeedMiscExpenseID As Integer, _
                                            ByVal intFeedMiscExpenseStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetFeedMiscExpenseStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intFeedMiscExpenseID)
                .AddWithValue("2", intFeedMiscExpenseStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Equipment"
    ' --------------------------------------------------------------------------------
    ' Name: AddEquipmentToDatabase2
    ' Abstract: Add the Equipment to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddEquipmentToDatabase2(ByRef udtEquipment As udtEquipmentType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddEquipment", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtEquipment.strName)
                .AddWithValue("2", udtEquipment.dtePurchaseDate)
                .AddWithValue("3", udtEquipment.decCost)
                .AddWithValue("4", udtEquipment.strComments)
                .AddWithValue("5", udtEquipment.intEquipmentStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtEquipment.intEquipmentID = drReturnValues.Item("intEquipmentID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetEquipmentInformationFromDatabase
    ' Abstract: Get data for the specified Equipment from the database
    ' --------------------------------------------------------------------------------
    Public Function GetEquipmentInformationFromDatabase(ByRef udtEquipment As udtEquipmentType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTEquipment As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TEquipment" & _
                        " WHERE intEquipmentID = " & udtEquipment.intEquipmentID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTEquipment = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTEquipment.Read()

            With drTEquipment

                udtEquipment.strName = .Item("strName")
                udtEquipment.dtePurchaseDate = .Item("dtePurchaseDate")
                udtEquipment.decCost = .Item("decCost")
                udtEquipment.strComments = .Item("strComments")
                udtEquipment.intEquipmentStatusID = intEQUIPMENT_STATUS_ACTIVE

            End With

            'Clean up
            drTEquipment.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditEquipmentInDatabase2
    ' Abstract: Edit the Equipment in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditEquipmentInDatabase2(ByVal udtEquipment As udtEquipmentType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditEquipment", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtEquipment.intEquipmentID)
                .AddWithValue("2", udtEquipment.strName)
                .AddWithValue("3", udtEquipment.dtePurchaseDate)
                .AddWithValue("4", udtEquipment.decCost)
                .AddWithValue("5", udtEquipment.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteEquipmentFromDatabase
    ' Abstract: Delete the Equipment from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteEquipmentFromDatabase(ByVal intEquipmentID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetEquipmentStatusInDatabase2(intEquipmentID, intEQUIPMENT_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteEquipmentFromDatabase
    ' Abstract: Mark the Equipment as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteEquipmentFromDatabase(ByVal intEquipmentID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetEquipmentStatusInDatabase2(intEquipmentID, intEQUIPMENT_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetEquipmentStatusInDatabase2
    ' Abstract: Mark the specified Equipment as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetEquipmentStatusInDatabase2(ByVal intEquipmentID As Integer, _
                                            ByVal intEquipmentStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetEquipmentStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intEquipmentID)
                .AddWithValue("2", intEquipmentStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Equipment Maintenance"
    ' --------------------------------------------------------------------------------
    ' Name: LoadListWithMaintenanceFromDatabase
    ' Abstract: Load all the Maintenance on/not for the specified Equipment.
    ' --------------------------------------------------------------------------------
    Public Function LoadListWithMaintenanceFromDatabase2(ByVal intEquipmentID As Integer, _
                                                            ByRef lstTarget As ListBox, _
                                                            ByVal blnMaintenanceOnEquipment As Boolean) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strCustomSQL As String = ""
            Dim strNot As String = "NOT"

            ' Selected Maintenance?
            If blnMaintenanceOnEquipment = True Then strNot = ""

            ' Build the Custom Sql Select statement
            ' We either want all the Maintenance on the Equipment or all the Maintenance NOT on the Equipment
            ' Maintenance must be active
            strCustomSQL = "SELECT " & _
                            "   intMaintenanceID, strName " & _
                            " FROM " & _
                            "   VActiveMaintenance " & _
                            " WHERE intMaintenanceID " & strNot & " IN " & _
                            "   ( " & _
                            "     SELECT intMaintenanceID " & _
                            "     FROM TEquipmentMaintenance " & _
                            "     WHERE intEquipmentID = " & intEquipmentID & _
                            "   ) " & _
                            " ORDER BY " & _
                            "   strName"

            blnResult = LoadListBoxFromDatabase("", "", "", lstTarget, "", strCustomSQL)

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddMaintenanceToEquipmentInDatabase2
    ' Abstract: Add the Maintenance to the specified Equipment
    ' --------------------------------------------------------------------------------
    Public Function AddMaintenanceToEquipmentInDatabase2(ByVal intEquipmentID As Integer, _
                                            ByVal intMaintenanceID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddEquipmentMaintenance", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intEquipmentID", intEquipmentID)
                .AddWithValue("@intMaintenanceID", intMaintenanceID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: AddAllAvailableMaintenanceToEquipmentInDatabase2
    ' Abstract: Add all the available Maintenance to the specified Equipment
    ' --------------------------------------------------------------------------------
    Public Function AddAllAvailableMaintenanceToEquipmentInDatabase2(ByVal intEquipmentID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddAllAvailableMaintenanceToEquipment", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .AddWithValue("@intEquipmentID", intEquipmentID)
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveMaintenanceFromEquipmentInDatabase2
    ' Abstract: Remove the Maintenance from the specified Equipment.
    ' --------------------------------------------------------------------------------
    Public Function RemoveMaintenanceFromEquipmentInDatabase2(ByVal intEquipmentID As Integer, _
                                                    ByVal intMaintenanceID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveEquipmentMaintenance", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intEquipmentID", intEquipmentID))
                .Add(New OleDb.OleDbParameter("@intMaintenanceID", intMaintenanceID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: RemoveAllSelectedMaintenanceFromEquipmentInDatabase2
    ' Abstract: Remove the Maintenance from the specified Equipment.
    ' --------------------------------------------------------------------------------
    Public Function RemoveAllSelectedMaintenanceFromEquipmentInDatabase2(ByVal intEquipmentID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspRemoveAllEquipmentMaintenance", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters
                .Add(New OleDb.OleDbParameter("@intEquipmentID", intEquipmentID))
            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region



#Region "Maintenance"
    ' --------------------------------------------------------------------------------
    ' Name: AddMaintenanceToDatabase2
    ' Abstract: Add the Maintenance to the sql database
    ' --------------------------------------------------------------------------------
    Public Function AddMaintenanceToDatabase2(ByRef udtMaintenance As udtMaintenanceType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand
            Dim drReturnValues As OleDb.OleDbDataReader

            ' Create sqlcommand object to un our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspAddMaintenance", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add parameters
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtMaintenance.strName)
                .AddWithValue("2", udtMaintenance.dteMaintenanceDate)
                .AddWithValue("3", udtMaintenance.decMaintenanceCost)
                .AddWithValue("4", udtMaintenance.strComments)
                .AddWithValue("5", udtMaintenance.intMaintenanceStatusID)

            End With

            ' Execute the stored procedure
            drReturnValues = cmdStoredProcedure.ExecuteReader()

            ' Should be 1 and only 1 record returned
            drReturnValues.Read()

            ' Get the new ID (could also use an output parameter)
            udtMaintenance.intMaintenanceID = drReturnValues.Item("intMaintenanceID")

            ' Clean up
            drReturnValues.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: GetMaintenanceInformationFromDatabase
    ' Abstract: Get data for the specified Maintenance from the database
    ' --------------------------------------------------------------------------------
    Public Function GetMaintenanceInformationFromDatabase(ByRef udtMaintenance As udtMaintenanceType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As New OleDb.OleDbCommand
            Dim drTMaintenance As OleDb.OleDbDataReader

            ' Build the select string
            strSelect = "SELECT *" & _
                        " FROM TMaintenance" & _
                        " WHERE intMaintenanceID = " & udtMaintenance.intMaintenanceID

            ' Retrieve the record
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drTMaintenance = cmdSelect.ExecuteReader

            ' Read (there should be 1 and only 1 row)
            drTMaintenance.Read()

            With drTMaintenance

                udtMaintenance.strName = .Item("strName")
                udtMaintenance.dteMaintenanceDate = .Item("dteMaintenanceDate")
                udtMaintenance.decMaintenanceCost = .Item("decMaintenanceCost")
                udtMaintenance.strComments = .Item("strComments")
                udtMaintenance.intMaintenanceStatusID = intMAINTENANCE_STATUS_ACTIVE

            End With

            'Clean up
            drTMaintenance.Close()

            ' Success
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: EditMaintenanceInDatabase2
    ' Abstract: Edit the Maintenance in the sql database.
    ' --------------------------------------------------------------------------------
    Public Function EditMaintenanceInDatabase2(ByVal udtMaintenance As udtMaintenanceType) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspEditMaintenance", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values here instead of above to prevent SQL injection attacks
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", udtMaintenance.intMaintenanceID)
                .AddWithValue("2", udtMaintenance.strName)
                .AddWithValue("3", udtMaintenance.dteMaintenanceDate)
                .AddWithValue("4", udtMaintenance.decMaintenanceCost)
                .AddWithValue("5", udtMaintenance.strComments)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: DeleteMaintenanceFromDatabase
    ' Abstract: Delete the Maintenance from the database.
    ' --------------------------------------------------------------------------------
    Public Function DeleteMaintenanceFromDatabase(ByVal intMaintenanceID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetMaintenanceStatusInDatabase2(intMaintenanceID, intMAINTENANCE_STATUS_INACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteMaintenanceFromDatabase
    ' Abstract: Mark the Maintenance as active.
    ' --------------------------------------------------------------------------------
    Public Function UndeleteMaintenanceFromDatabase(ByVal intMaintenanceID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            blnResult = SetMaintenanceStatusInDatabase2(intMaintenanceID, intMAINTENANCE_STATUS_ACTIVE)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: SetMaintenanceStatusInDatabase2
    ' Abstract: Mark the specified Maintenance as active or inactive.
    ' --------------------------------------------------------------------------------
    Public Function SetMaintenanceStatusInDatabase2(ByVal intMaintenanceID As Integer, _
                                            ByVal intMaintenanceStatusID As Integer) As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim cmdStoredProcedure As OleDb.OleDbCommand

            ' Create sqlcommand object to run our stored procedure
            cmdStoredProcedure = New OleDb.OleDbCommand("uspSetMaintenanceStatus", m_conAdministrator)
            cmdStoredProcedure.CommandType = CommandType.StoredProcedure

            ' Add column values 
            With cmdStoredProcedure.Parameters

                .AddWithValue("1", intMaintenanceID)
                .AddWithValue("2", intMaintenanceStatusID)

            End With

            ' Execute the stored procedure
            cmdStoredProcedure.ExecuteNonQuery()

            ' Success?
            blnResult = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

        Return blnResult

    End Function
#End Region


End Module
