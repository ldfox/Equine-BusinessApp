﻿' --------------------------------------------------------------------------------
' Name: Laurie Fox - FManageShoes
' Abstract: Capstone Horse project- Manage the horses Shoes (Add, Edit and Delete)
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions


Public Class FManageShoes


    ' --------------------------------------------------------------------------------
    ' Constants
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Form variables
    ' --------------------------------------------------------------------------------

    ' --------------------------------------------------------------------------------
    ' Name: Form_Shown
    ' Abstract: Do any initialization.
    ' --------------------------------------------------------------------------------
    Private Sub Form_Shown(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Shown

        ' Try/Catch with WriteLog
        Try

            Dim blnResult As Boolean = False

            ' Load the CBasePages list
            blnResult = LoadShoesList()

            ' Did it work?
            If blnResult = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Unable to load the horse Shoes list" & vbNewLine & _
                                "The form will now close.", _
                                Me.Text & " Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form
                Me.Close()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadShoesList
    ' Abstract: Load the horse Shoes list.
    ' --------------------------------------------------------------------------------
    Private Function LoadShoesList() As Boolean

        Dim blnResult As Boolean = False

        ' Try/Catch with WriteLog
        Try

            Dim strSourceTable As String = ""

            If chkShowDeleted.Checked = False Then

                strSourceTable = "VActiveShoes"

            Else

                strSourceTable = "VInActiveShoes"

            End If

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load list from database
            blnResult = LoadListBoxFromDatabase(strSourceTable, _
                                                        "intShoeID", _
                                                        "strName", _
                                                        lstShoes)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

        Return blnResult

    End Function



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Show the add horse Shoe form.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liNewShoeInformation As CListItem
            Dim intIndex As Integer

            ' Buy a plot of land zoned for FAddShoe forms
            Dim frmAddShoe As FAddShoe

            ' Make an instance
            frmAddShoe = New FAddShoe

            ' Show modally
            frmAddShoe.ShowDialog()

            ' We are busy
            SetBusyCursor(Me, True)

            ' Was the Add succesful?
            If frmAddShoe.GetResult() = True Then

                ' Get the new Shoe values
                liNewShoeInformation = frmAddShoe.GetNewShoeInformation()

                ' Add Item returns index of newly added item ...
                intIndex = lstShoes.Items.Add(liNewShoeInformation)

                ' ... which we can use to select it
                lstShoes.SelectedIndex = intIndex

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub




    ' --------------------------------------------------------------------------------
    ' Name: btnEdit_Click
    ' Abstract: Edit the selected horse Shoe.
    ' --------------------------------------------------------------------------------
    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        ' Try/Catch with WriteLog
        Try

            Dim intSelectedShoeID As Integer
            Dim liSelectedShoe As CListItem
            Dim frmEditShoe As FEditShoe
            Dim liNewShoeInformation As CListItem
            Dim intIndex As Integer

            ' Is a Shoe selected?
            If lstShoes.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Shoe to edit.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Yes, get the shoe to edit ID
                liSelectedShoe = lstShoes.SelectedItem
                intSelectedShoeID = liSelectedShoe.GetID

                ' Create instance
                frmEditShoe = New FEditShoe

                ' Set the form values
                frmEditShoe.SetShoeID(intSelectedShoeID)

                ' Show it modally   
                frmEditShoe.ShowDialog(Me)

                ' Was the Add succesful?
                If frmEditShoe.GetResult() = True Then

                    ' Get the new Shoe values
                    liNewShoeInformation = frmEditShoe.GetNewShoeInformation

                    ' Yes, remove and re-add from list so it gets sorted correctly
                    lstShoes.Items.RemoveAt(lstShoes.SelectedIndex)

                    ' Add Item returns index of newly added item ...
                    intIndex = lstShoes.Items.Add(liNewShoeInformation)

                    ' ... which we can use to select it
                    lstShoes.SelectedIndex = intIndex

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnDelete_Click
    ' Abstract: Delete the selected horse Shoe.
    ' --------------------------------------------------------------------------------
    Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnDelete.Click

        ' Try/Catch with WriteLog
        Try

            ' Delete?
            If chkShowDeleted.Checked = False Then

                ' Yes
                DeleteShoe()

            Else

                ' No, undelete
                UndeleteShoe()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: DeleteShoe
    ' Abstract: Delete the currently selected Shoe.
    ' --------------------------------------------------------------------------------
    Private Sub DeleteShoe()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedShoe As CListItem
            Dim intSelectedShoeID As Integer
            Dim strSelectedShoeName As String
            Dim intSelectedShoeIndex As Integer
            Dim drConfirm As DialogResult
            Dim blnResult As Boolean

            ' Is a Shoe selected?
            If lstShoes.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Shoe to delete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Shoe ID, name and list index
                liSelectedShoe = lstShoes.SelectedItem
                intSelectedShoeID = liSelectedShoe.GetID
                strSelectedShoeName = liSelectedShoe.GetName
                intSelectedShoeIndex = lstShoes.SelectedIndex

                ' Yes, confirm they want to delete (use name for user confirmation)
                drConfirm = MessageBox.Show("Are you sure?", "Delete Shoe: " & strSelectedShoeName, _
                                            MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                ' Yes?
                If drConfirm = Windows.Forms.DialogResult.Yes Then

                    ' We are busy
                    SetBusyCursor(Me, True)

                    ' Yes, delete the Shoe (use ID for database command)
                    blnResult = DeleteShoeFromDatabase(intSelectedShoeID)

                    ' Was the delete sucessful?
                    If blnResult = True Then

                        ' Yes, remove the Shoe from the list
                        lstShoes.Items.RemoveAt(intSelectedShoeIndex)

                        ' Select the next Shoe in the list
                        HighlightNextItemInList(lstShoes, intSelectedShoeIndex)

                    End If

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: UndeleteShoe
    ' Abstract: Undelete the currently selected Shoe.
    ' --------------------------------------------------------------------------------
    Private Sub UndeleteShoe()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedShoe As CListItem
            Dim intSelectedShoeID As Integer
            Dim intSelectedShoeIndex As Integer
            Dim blnResult As Boolean

            ' Is a Shoe selected?
            If lstShoes.SelectedIndex < 0 Then

                ' No, warn the user
                MessageBox.Show("You must select a Shoe to undelete.", Me.Text & " Error", _
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Else

                ' Get the Shoe ID and list index
                liSelectedShoe = lstShoes.SelectedItem
                intSelectedShoeID = liSelectedShoe.GetID
                intSelectedShoeIndex = lstShoes.SelectedIndex

                ' We are busy
                SetBusyCursor(Me, True)

                ' Yes, undelete the Shoe (use ID for database command)
                blnResult = UndeleteShoeFromDatabase(intSelectedShoeID)

                ' Was the undelete sucessful?
                If blnResult = True Then

                    ' Yes, remove the Shoe from the list
                    lstShoes.Items.RemoveAt(intSelectedShoeIndex)

                    ' Select the next Shoe in the list
                    HighlightNextItemInList(lstShoes, intSelectedShoeIndex)

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: chkShowDeleted_CheckedChanged
    ' Abstract: Toggle between active an inactive Horses.
    ' --------------------------------------------------------------------------------
    Private Sub chkShowDeleted_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles chkShowDeleted.CheckedChanged

        ' Try/Catch with WriteLog
        Try

            If chkShowDeleted.Checked = False Then

                btnAdd.Enabled = True
                btnEdit.Enabled = True
                btnDelete.Text = "&Delete"

            Else

                btnAdd.Enabled = False
                btnEdit.Enabled = False
                btnDelete.Text = "&Undelete"

            End If

            ' Load the Shoes list
            LoadShoesList()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close the form.
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        ' Try/Catch with WriteLog
        Try

            Me.Close()

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView via the button click.
    '           It also refreshes the dataGridView by clicking after changes have been made.
    ' --------------------------------------------------------------------------------
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        'Try/Catch with WriteLog
        Try

            Me.VShoesTableAdapter.Fill(Me.CPDM_FoxLShoesDS.VShoes)

        Catch excError As Exception

            'Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnViewData_Click
    ' Abstract: Loads the DataSet and populates the dataGridView.
    ' --------------------------------------------------------------------------------
    'Private Sub FManageShoes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'TODO: This line of code loads data into the 'CPDM_FoxLShoesDS.VShoes' table.
    '    Me.VShoesTableAdapter.Fill(Me.CPDM_FoxLShoesDS.VShoes)

    'End Sub

End Class