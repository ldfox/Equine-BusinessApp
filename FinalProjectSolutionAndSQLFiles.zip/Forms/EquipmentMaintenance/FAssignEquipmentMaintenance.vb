﻿' Name: Laurie Fox
' Abstract: Capstone Horse Project - Assign Equipment Maintenance
' --------------------------------------------------------------------------------

' --------------------------------------------------------------------------------
' Options
' --------------------------------------------------------------------------------
Option Explicit On  ' Must declare variables
Option Strict Off   ' Allow implicit conversions

' ------------------------------------------------------------------------------------
' Imports
' ------------------------------------------------------------------------------------
Imports System
Imports System.IO


Public Class FAssignEquipmentMaintenance


    ' --------------------------------------------------------------------------------
    '  Form variables/properties
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    '  Form procedures/methods
    ' --------------------------------------------------------------------------------


    ' --------------------------------------------------------------------------------
    ' Name: FAssignEquipmentMaintenance_Shown
    ' Abstract: Event that is fired/triggered when the form is shown for the first time.
    '           Close the application if we fail to connect to the database.
    ' --------------------------------------------------------------------------------
    Private Sub FAssignEquipmentMaintenance_Shown(sender As Object, e As EventArgs) Handles Me.Shown

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            ' Load combobox from database
            ModDatabaseUtilities.LoadComboBoxFromDatabase("VActiveEquipment", "intEquipmentID", "strName", cmbEquipment)

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: LoadEquipmentMaintenance
    ' Abstract: Load the selected and available Maintenance lists for the current Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub LoadEquipmentMaintenance()

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedEquipment As CListItem
            Dim intEquipmentID As Integer

            ' We are busy
            SetBusyCursor(Me, True)

            ' Is a Equipment selected
            If cmbEquipment.SelectedIndex >= 0 Then

                ' Get the selected Equipment ID
                liSelectedEquipment = cmbEquipment.SelectedItem
                intEquipmentID = liSelectedEquipment.GetID

                ' Selected Maintenance
                ModDatabaseUtilities.LoadListWithMaintenanceFromDatabase2(intEquipmentID, lstSelectedMaintenance, True)

                ' Available Maintenance
                ModDatabaseUtilities.LoadListWithMaintenanceFromDatabase2(intEquipmentID, lstAvailableMaintenance, False)

                ' Enable/disable    add/remove buttons
                EnableButtons()

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: EnableButtons
    ' Abstract: Enable/disable the OK and add/remove buttons.
    ' --------------------------------------------------------------------------------
    Private Sub EnableButtons()

        ' Try/Catch with WriteLog
        Try

            ' All
            btnAll.Enabled = False
            If lstAvailableMaintenance.Items.Count > 0 Then btnAll.Enabled = True

            ' Add
            btnAdd.Enabled = False
            If lstAvailableMaintenance.Items.Count > 0 Then btnAdd.Enabled = True

            ' Remove
            btnRemove.Enabled = False
            If lstSelectedMaintenance.Items.Count > 0 Then btnRemove.Enabled = True

            ' None
            btnNone.Enabled = False
            If lstSelectedMaintenance.Items.Count > 0 Then btnNone.Enabled = True

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAll_Click
    ' Abstract: Add all Maintenance to the Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnAll_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAll.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intEquipmentID As Integer
            Dim intIndex As Integer

            ' Is a Maintenance selected?
            If lstAvailableMaintenance.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Equipment and Maintenance IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbEquipment.SelectedItem
                intEquipmentID = liSelectedItem.GetID
                liSelectedItem = lstAvailableMaintenance.SelectedItem


                ' Add the Maintenance from lstAvailableMaintenance 
                'If AddAllAvailableMaintenanceFromDatabaseMSAccess(intEquipmentID) = True Then
                If AddAllAvailableMaintenanceToEquipmentInDatabase2(intEquipmentID) = True Then

                    ' Loop through list Items
                    For intIndex = lstAvailableMaintenance.Items.Count - 1 To 0 Step -1

                        ' Add to lstSelectedMaintenance from lstAvailableMaintenance
                        lstSelectedMaintenance.Items.Add(lstAvailableMaintenance.Items(0))

                        ' Remove from lstAvailableMaintenance
                        lstAvailableMaintenance.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedMaintenance then ...
                    If lstSelectedMaintenance.Items.Count > 0 Then

                        ' Select the first item in list
                        lstSelectedMaintenance.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnAdd_Click
    ' Abstract: Add a Maintenance to the Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnAdd.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intEquipmentID As Integer
            Dim intMaintenanceID As Integer
            Dim intIndex As Integer

            ' Is a Maintenance selected?
            If lstAvailableMaintenance.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Equipment and Maintenance IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbEquipment.SelectedItem
                intEquipmentID = liSelectedItem.GetID
                liSelectedItem = lstAvailableMaintenance.SelectedItem
                intMaintenanceID = liSelectedItem.GetID

                ' Add the Maintenance
                'If AddMaintenanceToEquipmentInDatabaseMSAccess(intEquipmentID, intMaintenanceID) = True Then
                If AddMaintenanceToEquipmentInDatabase2(intEquipmentID, intMaintenanceID) = True Then

                    ' Add to selected Maintenance
                    intIndex = lstSelectedMaintenance.Items.Add(lstAvailableMaintenance.SelectedItem)
                    lstSelectedMaintenance.SelectedIndex = intIndex

                    ' Remove from available Maintenance
                    intIndex = lstAvailableMaintenance.SelectedIndex
                    lstAvailableMaintenance.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstAvailableMaintenance, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnRemove_Click
    ' Abstract: Remove the currently selected Maintenance from the Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intEquipmentID As Integer
            Dim intMaintenanceID As Integer
            Dim intIndex As Integer

            If lstSelectedMaintenance.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Equipment and Maintenance IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbEquipment.SelectedItem
                intEquipmentID = liSelectedItem.GetID
                liSelectedItem = lstSelectedMaintenance.SelectedItem
                intMaintenanceID = liSelectedItem.GetID

                ' Remove the Maintenance
                'If RemoveMaintenanceFromEquipmentInDatabaseMSAccess(intEquipmentID, intMaintenanceID) = True Then
                If RemoveMaintenanceFromEquipmentInDatabase2(intEquipmentID, intMaintenanceID) = True Then

                    ' Add to available Maintenance
                    intIndex = lstAvailableMaintenance.Items.Add(lstSelectedMaintenance.SelectedItem)
                    lstAvailableMaintenance.SelectedIndex = intIndex

                    ' Remove from selected Maintenance
                    intIndex = lstSelectedMaintenance.SelectedIndex
                    lstSelectedMaintenance.Items.RemoveAt(intIndex)

                    ' Highlight next in list
                    HighlightNextItemInList(lstSelectedMaintenance, intIndex)

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnNone_Click
    ' Abstract: Remove All the Maintenance from the Equipment.
    ' --------------------------------------------------------------------------------
    Private Sub btnNone_Click(sender As Object, e As EventArgs) Handles btnNone.Click

        ' Try/Catch with WriteLog
        Try

            Dim liSelectedItem As CListItem
            Dim intEquipmentID As Integer
            Dim intMaintenanceID As Integer
            Dim intIndex As Integer

            If lstSelectedMaintenance.SelectedIndex >= 0 Then

                'Yes
                ' We are busy
                SetBusyCursor(Me, True)

                ' Get Equipment and Maintenance IDs from lists (which are populated with instances of CListItem)
                liSelectedItem = cmbEquipment.SelectedItem
                intEquipmentID = liSelectedItem.GetID
                liSelectedItem = lstSelectedMaintenance.SelectedItem
                intMaintenanceID = liSelectedItem.GetID

                ' Remove the Maintenance
                'If RemoveAllMaintenanceFromEquipmentInDatabaseMSAccess(intEquipmentID) = True Then
                If RemoveAllSelectedMaintenanceFromEquipmentInDatabase2(intEquipmentID) = True Then

                    ' Loop through list Items
                    For intIndex = lstSelectedMaintenance.Items.Count - 1 To 0 Step -1

                        ' Add to lstAvailableMaintenance from lstSelectedMaintenance
                        lstAvailableMaintenance.Items.Add(lstSelectedMaintenance.Items(0))

                        ' Remove from lstSelectedMaintenance
                        lstSelectedMaintenance.Items.RemoveAt(0)

                    Next

                    ' If there is more than one item in lstSelectedMaintenance then ...
                    If lstAvailableMaintenance.Items.Count > 0 Then

                        ' Select the first item in list
                        lstAvailableMaintenance.SelectedIndex = 0

                    End If

                    EnableButtons()

                End If

            End If

        Catch excError As Exception

            ' Display error message
            WriteLog(excError)

        Finally

            ' We are not busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' -------------------------------------------------------------------------
    ' Name: cmbEquipment_SelectedIndexChanged
    ' Abstract: Load the selected and available Maintenance lists for the current Equipment.
    ' -------------------------------------------------------------------------
    Private Sub cmbEquipment_SelectedIndexChanged(ByVal sender As System.Object, _
                                              ByVal e As System.EventArgs) Handles cmbEquipment.SelectedIndexChanged

        ' Try/Catch with WriteLog
        Try

            ' We are busy
            SetBusyCursor(Me, True)

            LoadEquipmentMaintenance()

        Catch excError As Exception

            ' Log and display error message
            WriteLog(excError)

        Finally

            ' We are NOT busy
            SetBusyCursor(Me, False)

        End Try

    End Sub



    ' --------------------------------------------------------------------------------
    ' Name: btnClose_Click
    ' Abstract: Close/Exit the form
    ' --------------------------------------------------------------------------------
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Try

            ' Closes just current form.  Application exits only if this is the last form open.
            Me.Close()

        Catch excError As Exception

            WriteLog(excError)

        End Try

    End Sub

End Class