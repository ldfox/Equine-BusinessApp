﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAssignHorseHealthCertificates
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpHealthCertificates = New System.Windows.Forms.GroupBox()
        Me.btnNone = New System.Windows.Forms.Button()
        Me.btnAll = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lstAvailableHealthCertificates = New System.Windows.Forms.ListBox()
        Me.lblSelected = New System.Windows.Forms.Label()
        Me.lblAvailable = New System.Windows.Forms.Label()
        Me.lstSelectedHealthCertificates = New System.Windows.Forms.ListBox()
        Me.cmbHorses = New System.Windows.Forms.ComboBox()
        Me.lblHorses = New System.Windows.Forms.Label()
        Me.grpHealthCertificates.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(304, 446)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(244, 43)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'grpHealthCertificates
        '
        Me.grpHealthCertificates.Controls.Add(Me.btnNone)
        Me.grpHealthCertificates.Controls.Add(Me.btnAll)
        Me.grpHealthCertificates.Controls.Add(Me.btnRemove)
        Me.grpHealthCertificates.Controls.Add(Me.btnAdd)
        Me.grpHealthCertificates.Controls.Add(Me.lstAvailableHealthCertificates)
        Me.grpHealthCertificates.Controls.Add(Me.lblSelected)
        Me.grpHealthCertificates.Controls.Add(Me.lblAvailable)
        Me.grpHealthCertificates.Controls.Add(Me.lstSelectedHealthCertificates)
        Me.grpHealthCertificates.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpHealthCertificates.Location = New System.Drawing.Point(30, 72)
        Me.grpHealthCertificates.Name = "grpHealthCertificates"
        Me.grpHealthCertificates.Size = New System.Drawing.Size(793, 350)
        Me.grpHealthCertificates.TabIndex = 1
        Me.grpHealthCertificates.TabStop = False
        Me.grpHealthCertificates.Text = "HealthCertificates"
        '
        'btnNone
        '
        Me.btnNone.Location = New System.Drawing.Point(338, 260)
        Me.btnNone.Name = "btnNone"
        Me.btnNone.Size = New System.Drawing.Size(118, 39)
        Me.btnNone.TabIndex = 3
        Me.btnNone.Text = "&None >>"
        Me.btnNone.UseVisualStyleBackColor = True
        '
        'btnAll
        '
        Me.btnAll.Location = New System.Drawing.Point(338, 77)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(118, 39)
        Me.btnAll.TabIndex = 0
        Me.btnAll.Text = "<< &All"
        Me.btnAll.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(338, 199)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(118, 39)
        Me.btnRemove.TabIndex = 2
        Me.btnRemove.Text = "&Remove >"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(338, 138)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(118, 39)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "< A&dd"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lstAvailableHealthCertificates
        '
        Me.lstAvailableHealthCertificates.FormattingEnabled = True
        Me.lstAvailableHealthCertificates.ItemHeight = 22
        Me.lstAvailableHealthCertificates.Location = New System.Drawing.Point(485, 53)
        Me.lstAvailableHealthCertificates.Name = "lstAvailableHealthCertificates"
        Me.lstAvailableHealthCertificates.Size = New System.Drawing.Size(278, 246)
        Me.lstAvailableHealthCertificates.Sorted = True
        Me.lstAvailableHealthCertificates.TabIndex = 5
        '
        'lblSelected
        '
        Me.lblSelected.AutoSize = True
        Me.lblSelected.Location = New System.Drawing.Point(26, 32)
        Me.lblSelected.Name = "lblSelected"
        Me.lblSelected.Size = New System.Drawing.Size(89, 24)
        Me.lblSelected.TabIndex = 0
        Me.lblSelected.Text = "Selected:"
        '
        'lblAvailable
        '
        Me.lblAvailable.AutoSize = True
        Me.lblAvailable.Location = New System.Drawing.Point(480, 32)
        Me.lblAvailable.Name = "lblAvailable"
        Me.lblAvailable.Size = New System.Drawing.Size(91, 24)
        Me.lblAvailable.TabIndex = 6
        Me.lblAvailable.Text = "Available:"
        '
        'lstSelectedHealthCertificates
        '
        Me.lstSelectedHealthCertificates.FormattingEnabled = True
        Me.lstSelectedHealthCertificates.ItemHeight = 22
        Me.lstSelectedHealthCertificates.Location = New System.Drawing.Point(30, 53)
        Me.lstSelectedHealthCertificates.Name = "lstSelectedHealthCertificates"
        Me.lstSelectedHealthCertificates.Size = New System.Drawing.Size(278, 246)
        Me.lstSelectedHealthCertificates.Sorted = True
        Me.lstSelectedHealthCertificates.TabIndex = 4
        '
        'cmbHorses
        '
        Me.cmbHorses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbHorses.FormattingEnabled = True
        Me.cmbHorses.Location = New System.Drawing.Point(120, 24)
        Me.cmbHorses.Name = "cmbHorses"
        Me.cmbHorses.Size = New System.Drawing.Size(261, 30)
        Me.cmbHorses.TabIndex = 0
        '
        'lblHorses
        '
        Me.lblHorses.AutoSize = True
        Me.lblHorses.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHorses.Location = New System.Drawing.Point(26, 27)
        Me.lblHorses.Name = "lblHorses"
        Me.lblHorses.Size = New System.Drawing.Size(75, 24)
        Me.lblHorses.TabIndex = 3
        Me.lblHorses.Text = "Horses:"
        '
        'FAssignHorseHealthCertificates
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(848, 513)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.grpHealthCertificates)
        Me.Controls.Add(Me.cmbHorses)
        Me.Controls.Add(Me.lblHorses)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAssignHorseHealthCertificates"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FAssignHorseHealthCertificates"
        Me.grpHealthCertificates.ResumeLayout(False)
        Me.grpHealthCertificates.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents grpHealthCertificates As System.Windows.Forms.GroupBox
    Friend WithEvents btnNone As System.Windows.Forms.Button
    Friend WithEvents btnAll As System.Windows.Forms.Button
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lstAvailableHealthCertificates As System.Windows.Forms.ListBox
    Friend WithEvents lblSelected As System.Windows.Forms.Label
    Friend WithEvents lblAvailable As System.Windows.Forms.Label
    Friend WithEvents lstSelectedHealthCertificates As System.Windows.Forms.ListBox
    Friend WithEvents cmbHorses As System.Windows.Forms.ComboBox
    Friend WithEvents lblHorses As System.Windows.Forms.Label
End Class
