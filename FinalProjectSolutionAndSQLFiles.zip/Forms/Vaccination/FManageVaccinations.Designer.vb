﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FManageVaccinations
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblShowDelete = New System.Windows.Forms.Label()
        Me.dgvVaccinations = New System.Windows.Forms.DataGridView()
        Me.IntVaccinationIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DecVaccinationCostDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DteVaccinationDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCommentsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrVaccinationStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VVaccinationsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPDM_FoxLVaccinationsDS = New CapstoneHorseApplication.CPDM_FoxLVaccinationsDS()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDeletes = New System.Windows.Forms.Label()
        Me.lblViewData = New System.Windows.Forms.Label()
        Me.btnViewData = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.chkShowDeleted = New System.Windows.Forms.CheckBox()
        Me.lblVaccinations = New System.Windows.Forms.Label()
        Me.lstVaccinations = New System.Windows.Forms.ListBox()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.VVaccinationsTableAdapter = New CapstoneHorseApplication.CPDM_FoxLVaccinationsDSTableAdapters.VVaccinationsTableAdapter()
        CType(Me.dgvVaccinations, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VVaccinationsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPDM_FoxLVaccinationsDS, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblShowDelete
        '
        Me.lblShowDelete.AutoSize = True
        Me.lblShowDelete.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblShowDelete.Location = New System.Drawing.Point(163, 268)
        Me.lblShowDelete.Name = "lblShowDelete"
        Me.lblShowDelete.Size = New System.Drawing.Size(113, 36)
        Me.lblShowDelete.TabIndex = 6
        Me.lblShowDelete.Text = "Click checkbox " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "to toggle view"
        '
        'dgvVaccinations
        '
        Me.dgvVaccinations.AllowUserToAddRows = False
        Me.dgvVaccinations.AllowUserToDeleteRows = False
        Me.dgvVaccinations.AutoGenerateColumns = False
        Me.dgvVaccinations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvVaccinations.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntVaccinationIDDataGridViewTextBoxColumn, Me.StrNameDataGridViewTextBoxColumn, Me.DecVaccinationCostDataGridViewTextBoxColumn, Me.DteVaccinationDateDataGridViewTextBoxColumn, Me.StrCommentsDataGridViewTextBoxColumn, Me.StrVaccinationStatusDataGridViewTextBoxColumn})
        Me.dgvVaccinations.DataSource = Me.VVaccinationsBindingSource
        Me.dgvVaccinations.Location = New System.Drawing.Point(29, 309)
        Me.dgvVaccinations.Name = "dgvVaccinations"
        Me.dgvVaccinations.ReadOnly = True
        Me.dgvVaccinations.RowTemplate.Height = 24
        Me.dgvVaccinations.Size = New System.Drawing.Size(965, 348)
        Me.dgvVaccinations.TabIndex = 7
        '
        'IntVaccinationIDDataGridViewTextBoxColumn
        '
        Me.IntVaccinationIDDataGridViewTextBoxColumn.DataPropertyName = "intVaccinationID"
        Me.IntVaccinationIDDataGridViewTextBoxColumn.HeaderText = "intVaccinationID"
        Me.IntVaccinationIDDataGridViewTextBoxColumn.Name = "IntVaccinationIDDataGridViewTextBoxColumn"
        Me.IntVaccinationIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrNameDataGridViewTextBoxColumn
        '
        Me.StrNameDataGridViewTextBoxColumn.DataPropertyName = "strName"
        Me.StrNameDataGridViewTextBoxColumn.HeaderText = "strName"
        Me.StrNameDataGridViewTextBoxColumn.Name = "StrNameDataGridViewTextBoxColumn"
        Me.StrNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DecVaccinationCostDataGridViewTextBoxColumn
        '
        Me.DecVaccinationCostDataGridViewTextBoxColumn.DataPropertyName = "decVaccinationCost"
        Me.DecVaccinationCostDataGridViewTextBoxColumn.HeaderText = "decVaccinationCost"
        Me.DecVaccinationCostDataGridViewTextBoxColumn.Name = "DecVaccinationCostDataGridViewTextBoxColumn"
        Me.DecVaccinationCostDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DteVaccinationDateDataGridViewTextBoxColumn
        '
        Me.DteVaccinationDateDataGridViewTextBoxColumn.DataPropertyName = "dteVaccinationDate"
        Me.DteVaccinationDateDataGridViewTextBoxColumn.HeaderText = "dteVaccinationDate"
        Me.DteVaccinationDateDataGridViewTextBoxColumn.Name = "DteVaccinationDateDataGridViewTextBoxColumn"
        Me.DteVaccinationDateDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrCommentsDataGridViewTextBoxColumn
        '
        Me.StrCommentsDataGridViewTextBoxColumn.DataPropertyName = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.HeaderText = "strComments"
        Me.StrCommentsDataGridViewTextBoxColumn.Name = "StrCommentsDataGridViewTextBoxColumn"
        Me.StrCommentsDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrVaccinationStatusDataGridViewTextBoxColumn
        '
        Me.StrVaccinationStatusDataGridViewTextBoxColumn.DataPropertyName = "strVaccinationStatus"
        Me.StrVaccinationStatusDataGridViewTextBoxColumn.HeaderText = "strVaccinationStatus"
        Me.StrVaccinationStatusDataGridViewTextBoxColumn.Name = "StrVaccinationStatusDataGridViewTextBoxColumn"
        Me.StrVaccinationStatusDataGridViewTextBoxColumn.ReadOnly = True
        '
        'VVaccinationsBindingSource
        '
        Me.VVaccinationsBindingSource.DataMember = "VVaccinations"
        Me.VVaccinationsBindingSource.DataSource = Me.CPDM_FoxLVaccinationsDS
        '
        'CPDM_FoxLVaccinationsDS
        '
        Me.CPDM_FoxLVaccinationsDS.DataSetName = "CPDM_FoxLVaccinationsDS"
        Me.CPDM_FoxLVaccinationsDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.Location = New System.Drawing.Point(522, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(315, 36)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Click on a horse in the list box to highlight then " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "click Add, Edit, or Delete t" & _
    "o make changes."
        '
        'lblDeletes
        '
        Me.lblDeletes.AutoSize = True
        Me.lblDeletes.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblDeletes.Location = New System.Drawing.Point(522, 115)
        Me.lblDeletes.Name = "lblDeletes"
        Me.lblDeletes.Size = New System.Drawing.Size(291, 36)
        Me.lblDeletes.TabIndex = 11
        Me.lblDeletes.Text = "Deletes will show in the data with a horse " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "status of 2 and may be undeleted any" & _
    " time. "
        '
        'lblViewData
        '
        Me.lblViewData.AutoSize = True
        Me.lblViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViewData.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblViewData.Location = New System.Drawing.Point(522, 179)
        Me.lblViewData.Name = "lblViewData"
        Me.lblViewData.Size = New System.Drawing.Size(363, 36)
        Me.lblViewData.TabIndex = 12
        Me.lblViewData.Text = "Click button ""View/Updated Data"" once to show data.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click again to show ""Updat" & _
    "ed Data"" after changes."
        '
        'btnViewData
        '
        Me.btnViewData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewData.Location = New System.Drawing.Point(702, 242)
        Me.btnViewData.Name = "btnViewData"
        Me.btnViewData.Size = New System.Drawing.Size(250, 39)
        Me.btnViewData.TabIndex = 3
        Me.btnViewData.Text = "View/Updated Data"
        Me.btnViewData.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(366, 242)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 39)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Close Form"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'chkShowDeleted
        '
        Me.chkShowDeleted.AutoSize = True
        Me.chkShowDeleted.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShowDeleted.Location = New System.Drawing.Point(27, 270)
        Me.chkShowDeleted.Name = "chkShowDeleted"
        Me.chkShowDeleted.Size = New System.Drawing.Size(135, 24)
        Me.chkShowDeleted.TabIndex = 4
        Me.chkShowDeleted.Text = "Show Deleted"
        Me.chkShowDeleted.UseVisualStyleBackColor = True
        '
        'lblVaccinations
        '
        Me.lblVaccinations.AutoSize = True
        Me.lblVaccinations.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVaccinations.Location = New System.Drawing.Point(25, 17)
        Me.lblVaccinations.Name = "lblVaccinations"
        Me.lblVaccinations.Size = New System.Drawing.Size(122, 24)
        Me.lblVaccinations.TabIndex = 9
        Me.lblVaccinations.Text = "Vaccinations:"
        '
        'lstVaccinations
        '
        Me.lstVaccinations.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstVaccinations.FormattingEnabled = True
        Me.lstVaccinations.ItemHeight = 22
        Me.lstVaccinations.Location = New System.Drawing.Point(27, 40)
        Me.lstVaccinations.Name = "lstVaccinations"
        Me.lstVaccinations.ScrollAlwaysVisible = True
        Me.lstVaccinations.Size = New System.Drawing.Size(308, 224)
        Me.lstVaccinations.Sorted = True
        Me.lstVaccinations.TabIndex = 8
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(366, 169)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(100, 39)
        Me.btnDelete.TabIndex = 2
        Me.btnDelete.Text = "&Delete"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEdit.Location = New System.Drawing.Point(366, 110)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.Size = New System.Drawing.Size(100, 39)
        Me.btnEdit.TabIndex = 1
        Me.btnEdit.Text = "&Edit"
        Me.btnEdit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(366, 51)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(100, 39)
        Me.btnAdd.TabIndex = 0
        Me.btnAdd.Text = "&Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'VVaccinationsTableAdapter
        '
        Me.VVaccinationsTableAdapter.ClearBeforeFill = True
        '
        'FManageVaccinations
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1018, 683)
        Me.Controls.Add(Me.lblShowDelete)
        Me.Controls.Add(Me.dgvVaccinations)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblDeletes)
        Me.Controls.Add(Me.lblViewData)
        Me.Controls.Add(Me.btnViewData)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.chkShowDeleted)
        Me.Controls.Add(Me.lblVaccinations)
        Me.Controls.Add(Me.lstVaccinations)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnEdit)
        Me.Controls.Add(Me.btnAdd)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FManageVaccinations"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Manage Vaccinnations & View the Data"
        CType(Me.dgvVaccinations, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VVaccinationsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPDM_FoxLVaccinationsDS, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblShowDelete As System.Windows.Forms.Label
    Friend WithEvents dgvVaccinations As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblDeletes As System.Windows.Forms.Label
    Friend WithEvents lblViewData As System.Windows.Forms.Label
    Friend WithEvents btnViewData As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents chkShowDeleted As System.Windows.Forms.CheckBox
    Friend WithEvents lblVaccinations As System.Windows.Forms.Label
    Friend WithEvents lstVaccinations As System.Windows.Forms.ListBox
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents CPDM_FoxLVaccinationsDS As CapstoneHorseApplication.CPDM_FoxLVaccinationsDS
    Friend WithEvents VVaccinationsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VVaccinationsTableAdapter As CapstoneHorseApplication.CPDM_FoxLVaccinationsDSTableAdapters.VVaccinationsTableAdapter
    Friend WithEvents IntVaccinationIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DecVaccinationCostDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DteVaccinationDateDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCommentsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrVaccinationStatusDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
