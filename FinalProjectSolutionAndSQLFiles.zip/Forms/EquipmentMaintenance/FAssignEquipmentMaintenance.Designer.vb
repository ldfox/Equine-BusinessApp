﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FAssignEquipmentMaintenance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpMaintenance = New System.Windows.Forms.GroupBox()
        Me.btnNone = New System.Windows.Forms.Button()
        Me.btnAll = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lstAvailableMaintenance = New System.Windows.Forms.ListBox()
        Me.lblSelected = New System.Windows.Forms.Label()
        Me.lblAvailable = New System.Windows.Forms.Label()
        Me.lstSelectedMaintenance = New System.Windows.Forms.ListBox()
        Me.cmbEquipment = New System.Windows.Forms.ComboBox()
        Me.lblEquipment = New System.Windows.Forms.Label()
        Me.grpMaintenance.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(304, 446)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(244, 43)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'grpMaintenance
        '
        Me.grpMaintenance.Controls.Add(Me.btnNone)
        Me.grpMaintenance.Controls.Add(Me.btnAll)
        Me.grpMaintenance.Controls.Add(Me.btnRemove)
        Me.grpMaintenance.Controls.Add(Me.btnAdd)
        Me.grpMaintenance.Controls.Add(Me.lstAvailableMaintenance)
        Me.grpMaintenance.Controls.Add(Me.lblSelected)
        Me.grpMaintenance.Controls.Add(Me.lblAvailable)
        Me.grpMaintenance.Controls.Add(Me.lstSelectedMaintenance)
        Me.grpMaintenance.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpMaintenance.Location = New System.Drawing.Point(30, 72)
        Me.grpMaintenance.Name = "grpMaintenance"
        Me.grpMaintenance.Size = New System.Drawing.Size(793, 350)
        Me.grpMaintenance.TabIndex = 1
        Me.grpMaintenance.TabStop = False
        Me.grpMaintenance.Text = "Maintenance"
        '
        'btnNone
        '
        Me.btnNone.Location = New System.Drawing.Point(338, 260)
        Me.btnNone.Name = "btnNone"
        Me.btnNone.Size = New System.Drawing.Size(118, 39)
        Me.btnNone.TabIndex = 3
        Me.btnNone.Text = "&None >>"
        Me.btnNone.UseVisualStyleBackColor = True
        '
        'btnAll
        '
        Me.btnAll.Location = New System.Drawing.Point(338, 77)
        Me.btnAll.Name = "btnAll"
        Me.btnAll.Size = New System.Drawing.Size(118, 39)
        Me.btnAll.TabIndex = 0
        Me.btnAll.Text = "<< &All"
        Me.btnAll.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(338, 199)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(118, 39)
        Me.btnRemove.TabIndex = 2
        Me.btnRemove.Text = "&Remove >"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(338, 138)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(118, 39)
        Me.btnAdd.TabIndex = 1
        Me.btnAdd.Text = "< A&dd"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lstAvailableMaintenance
        '
        Me.lstAvailableMaintenance.FormattingEnabled = True
        Me.lstAvailableMaintenance.ItemHeight = 22
        Me.lstAvailableMaintenance.Location = New System.Drawing.Point(485, 53)
        Me.lstAvailableMaintenance.Name = "lstAvailableMaintenance"
        Me.lstAvailableMaintenance.Size = New System.Drawing.Size(278, 246)
        Me.lstAvailableMaintenance.Sorted = True
        Me.lstAvailableMaintenance.TabIndex = 6
        '
        'lblSelected
        '
        Me.lblSelected.AutoSize = True
        Me.lblSelected.Location = New System.Drawing.Point(26, 32)
        Me.lblSelected.Name = "lblSelected"
        Me.lblSelected.Size = New System.Drawing.Size(89, 24)
        Me.lblSelected.TabIndex = 5
        Me.lblSelected.Text = "Selected:"
        '
        'lblAvailable
        '
        Me.lblAvailable.AutoSize = True
        Me.lblAvailable.Location = New System.Drawing.Point(480, 32)
        Me.lblAvailable.Name = "lblAvailable"
        Me.lblAvailable.Size = New System.Drawing.Size(91, 24)
        Me.lblAvailable.TabIndex = 7
        Me.lblAvailable.Text = "Available:"
        '
        'lstSelectedMaintenance
        '
        Me.lstSelectedMaintenance.FormattingEnabled = True
        Me.lstSelectedMaintenance.ItemHeight = 22
        Me.lstSelectedMaintenance.Location = New System.Drawing.Point(30, 53)
        Me.lstSelectedMaintenance.Name = "lstSelectedMaintenance"
        Me.lstSelectedMaintenance.Size = New System.Drawing.Size(278, 246)
        Me.lstSelectedMaintenance.Sorted = True
        Me.lstSelectedMaintenance.TabIndex = 4
        '
        'cmbEquipment
        '
        Me.cmbEquipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbEquipment.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbEquipment.FormattingEnabled = True
        Me.cmbEquipment.Location = New System.Drawing.Point(143, 24)
        Me.cmbEquipment.Name = "cmbEquipment"
        Me.cmbEquipment.Size = New System.Drawing.Size(261, 30)
        Me.cmbEquipment.TabIndex = 0
        '
        'lblEquipment
        '
        Me.lblEquipment.AutoSize = True
        Me.lblEquipment.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEquipment.Location = New System.Drawing.Point(26, 27)
        Me.lblEquipment.Name = "lblEquipment"
        Me.lblEquipment.Size = New System.Drawing.Size(107, 24)
        Me.lblEquipment.TabIndex = 3
        Me.lblEquipment.Text = "Equipment:"
        '
        'FAssignEquipmentMaintenance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(848, 513)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.grpMaintenance)
        Me.Controls.Add(Me.cmbEquipment)
        Me.Controls.Add(Me.lblEquipment)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FAssignEquipmentMaintenance"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Assign Equipment Maintenance"
        Me.grpMaintenance.ResumeLayout(False)
        Me.grpMaintenance.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents grpMaintenance As System.Windows.Forms.GroupBox
    Friend WithEvents btnNone As System.Windows.Forms.Button
    Friend WithEvents btnAll As System.Windows.Forms.Button
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lstAvailableMaintenance As System.Windows.Forms.ListBox
    Friend WithEvents lblSelected As System.Windows.Forms.Label
    Friend WithEvents lblAvailable As System.Windows.Forms.Label
    Friend WithEvents lstSelectedMaintenance As System.Windows.Forms.ListBox
    Friend WithEvents cmbEquipment As System.Windows.Forms.ComboBox
    Friend WithEvents lblEquipment As System.Windows.Forms.Label
End Class
